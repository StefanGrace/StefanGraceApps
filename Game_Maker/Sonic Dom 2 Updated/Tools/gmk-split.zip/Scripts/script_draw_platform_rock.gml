// script_draw_platform_rock
// Stefan Grace
// Created: 2021-01-20
// Modified: 2021-01-20

draw_sprite(sprite_rock_left, 0, x, y);
draw_sprite(sprite_rock, 0, x + 32, y);
draw_sprite(sprite_rock, 0, x + 64, y);
draw_sprite(sprite_rock_right, 0, x + 96, y);