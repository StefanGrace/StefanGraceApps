// script_view
// Stefan Grace
// Created: 2018-01-07
// Modifed: 2021-02-13

if (!object_Sonic.showing_bonuses && !object_Sonic.boss) {
    x = object_Sonic.x;
    if (object_Sonic.boss_done_extra_terrestrial) {
        if (x < object_Sonic.left_bound + 640) {x = object_Sonic.left_bound + 640;}
    }
    if (object_Sonic.crouch){
        if (y < object_Sonic.y + 300) {y += 5;}
    } else if (object_Sonic.look_up) {
        if (y > object_Sonic.y - 300) {y -= 5;}
    } else {
        y = object_Sonic.y;
    }
    if (object_Sonic.zone == 1 && object_Sonic.act == 2) {
        if (!object_Sonic.boss_done_extra_terrestrial) {
            if (y > 1440) {y = 1440;}
        }
    }
}

if (object_Sonic.boss) {
    if (object_Sonic.zone == 1) {
        x = 9760;
        y = object_Dr_Robonic.y;
    } else if (object_Sonic.zone == 2) {
        x = 9008;
        if (object_Sonic.crouch){
            if (y < object_Sonic.y + 300) {y += 5;}
        } else if (object_Sonic.look_up) {
            if (y > object_Sonic.y - 300) {y -= 5;}
        } else {
            y = object_Sonic.y;
        }
    } else if (object_Sonic.zone == 3) {
        x = 6464;
        if (object_Sonic.crouch){
            if (y < object_Sonic.y + 300) {y += 5;}
        } else if (object_Sonic.look_up) {
            if (y > object_Sonic.y - 300) {y -= 5;}
        } else {
            y = object_Sonic.y;
        }
    }
}