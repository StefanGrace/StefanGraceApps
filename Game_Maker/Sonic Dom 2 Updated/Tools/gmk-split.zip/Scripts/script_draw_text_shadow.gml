// script_draw_text_shadow
// Stefan Grace
// Created: 2024-07-11
// Modified: 2024-07-11

/* Draws text with a black drop-shadow behind */

/* arguments
    argument0 - x
    argument1 - y
    argument2 - text
    argument3 - color
    argument4 - shadow size (default = 2)
*/


if (argument4 == 0) {argument4 = 2}


// Draw drop-shadow
draw_set_color(c_black);
draw_text(argument0 + argument4, argument1 + argument4, argument2);

// Draw text
draw_set_color(argument3);
draw_text(argument0, argument1, argument2);