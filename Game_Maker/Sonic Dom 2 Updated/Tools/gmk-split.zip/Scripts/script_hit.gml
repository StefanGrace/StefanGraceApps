// script_hit
// Stefan Grace
// Created: 2018-01-08
// Modifed: 2018-01-11


if (flashing || super_sonic) {
    exit;
} else if (shield) {
    shield = false;
    flashing = true;
    flash_start = time;
} else if (rings > 0) {
    repeat(rings) {
        instance_create(x + (floor(random(512)) - 256), y - floor(random(256)), object_Ring);
    }
    rings = 0;
    flashing = true;
    flash_start = time;
    sound_play(sound_loose_rings);
} else {
    script_execute(script_die);
}

