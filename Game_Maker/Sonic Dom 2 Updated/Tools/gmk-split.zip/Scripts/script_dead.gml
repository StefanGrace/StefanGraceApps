// script_dead
// Stefan Grace
// Created: 2021-02-14
// Modified: 2021-02-14

if (lives > 0) {
    dead = false;
    dead_time = 0;
    dead_sonic_speed = -20;
    dead_sonic_y = 0;
    depth = -20;
    x = bind_x;
    y = bind_y;
    hspeed = 0;
    vspeed = 0;
    rings = 0;
    shield = false;
    super_sonic = false;
    time = bind_time;
    drowning_timer = 0;
    just_got_extra_life = false;
    boss_hit_time = 0;
    flashing = false;
    with (object_TV_Got) {
        if (tv_type == 1) {
            instance_change(object_TV_Ring, false);
        } else if (tv_type == 2) {
            instance_change(object_TV_Shield, false);
        } else if (tv_type == 3) {
            instance_change(object_TV_Super_Sonic, false);
        } else if (tv_type == 4) {
            instance_change(object_TV_Sonic, false);
        }
    }
    with (object_Ring) {instance_change(object_Ring_Got, false);}
    with (object_Ring_Got) {instance_change(object_Ring, false);}
    with (object_Mob_Dead) {instance_change(object_Mob, false);}
    with (object_Destructible_Block_Destroyed) {instance_change(object_Destructible_Block, false);}
    with (object_Rising_Platform) {y = ystart; vspeed = 0;}
    with (object_Moving_Platform) {x = xstart; y = ystart; hspeed = 0; vspeed = 0;}
    with (object_Gate_Open) {instance_change(object_Gate, false);}
    with (object_Gate_Open_Horizontal) {instance_change(object_Gate_Horizontal, false);}
    var i bouncers;
    bouncers[0] = object_Bouncer_Lime;
    bouncers[1] = object_Bouncer_Yellow;
    bouncers[2] = object_Bouncer_Orange;
    bouncers[3] = object_Bouncer_Red;
    bouncers[4] = object_Bouncer_Gone;
    for (i = 0; i < 5; i += 1) { 
        with (bouncers[i]) {
            switch (original_color) {
                case c_green: instance_change(object_Bouncer_Green, false); break;
                case c_yellow: instance_change(object_Bouncer_Yellow, false); break;
                case c_red: instance_change(object_Bouncer_Red, false); break;
            }
        }
        
    }
    if (zone == 1) {
        sound_play(sound_extra_terrestrial);
    } else if (zone == 2) {
        sound_play(sound_martian);
    } else if (zone == 3) {
        sound_play(sound_pinball);
    }
    showing_title = true;
    title_time = time;
    boss = false;
    boss_hit = 0;
    if (zone == 1) {
        with (object_Dr_Robonic) {
            vspeed = 0;
            y = ystart;
        }
    }
    left_bound = 0;
    right_bound = room_width
    top_bound = 0;
    bottom_bound = room_height;
    if (zone == 1 && act == 2) {
        if (boss_done_extra_terrestrial) {
            left_bound = room_width - 1280;
        } else {
            bottom_bound = 1800;
        }
    }
} else {
    game_over = true;
}