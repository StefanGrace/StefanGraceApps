// script_draw_ui
// Stefan Grace
// Created: 2021-03-10
// Modifed: 2024-07-18

/* Draws the UI at a shallower depth than the sonic by using a separate object,
so that foreground objects that appear in front of Sonic don't appear in front of UI */

// Copy variables from Sonic
var rings time minutes seconds time_color rings_color time_bonus ring_bonus zones zone act showing_bonuses showing_title, game_over;
rings = object_Sonic.rings;
time = object_Sonic.time;
minutes = object_Sonic.minutes;
seconds = object_Sonic.seconds;
time_color = object_Sonic.time_color;
rings_color = object_Sonic.rings_color;
time_bonus = object_Sonic.time_bonus;
ring_bonus = object_Sonic.ring_bonus;
zone = object_Sonic.zone;
act = object_Sonic.act;
showing_bonuses = object_Sonic.showing_bonuses;
showing_title = object_Sonic.showing_title;
game_over = object_Sonic.game_over;


// Display (score, time, rings)
draw_set_font(font_display);
draw_set_halign(fa_left);
script_draw_text_shadow(view_xview[0] + 50,view_yview[0] + 10, "Score: ", c_yellow);
script_draw_text_shadow(view_xview[0] + 50,view_yview[0] + 40, "Time: ", time_color);
script_draw_text_shadow(view_xview[0] + 50,view_yview[0] + 70, "Rings: ", rings_color);
draw_set_halign(fa_right);
script_draw_text_shadow(view_xview[0] + 240,view_yview[0] + 10, score, c_white);
script_draw_text_shadow(view_xview[0] + 200,view_yview[0] + 40, string(minutes) + ":" + string(seconds), c_white);
script_draw_text_shadow(view_xview[0] + 200,view_yview[0] + 70, rings, c_white);

// Lives
draw_set_alpha(0.5);
draw_set_color(c_black);
draw_rectangle(view_xview[0] + 50, view_yview[0] + 680, view_xview[0] + 130, view_yview[0] + 712, false);
draw_set_alpha(1);
draw_sprite(sprite_lives,0,view_xview[0] + 50,view_yview[0] + 680);
draw_set_font(font_lives);
draw_set_halign(fa_left);
draw_set_color(c_yellow);
draw_text(view_xview[0] + 85,view_yview[0] + 678, "Sonic");
draw_set_color(c_white);
draw_text(view_xview[0] + 85,view_yview[0] + 694, "x");
draw_set_halign(fa_right);
draw_text(view_xview[0] + 126,view_yview[0] + 694, lives);

// Bonuses
if (showing_bonuses) {
    draw_set_halign(fa_left);
    draw_set_font(font_title);
    script_draw_text_shadow(view_xview[0] + 300, view_yview[0] + 100, "Sonic Has Passed Act " + string(act), c_white, 3);
    draw_set_font(font_display);
    script_draw_text_shadow(view_xview[0] + 300,view_yview[0] + 250, "Score: ", c_yellow);
    script_draw_text_shadow(view_xview[0] + 300,view_yview[0] + 300, "Time Bonus: ", c_yellow);
    script_draw_text_shadow(view_xview[0] + 300,view_yview[0] + 350, "Ring Bonus: ", c_yellow);
    draw_set_halign(fa_right);
    script_draw_text_shadow(view_xview[0] + 550,view_yview[0] + 250, score, c_white);
    script_draw_text_shadow(view_xview[0] + 550,view_yview[0] + 300, time_bonus, c_white);
    script_draw_text_shadow(view_xview[0] + 550,view_yview[0] + 350, ring_bonus, c_white);
}

// Title
if (showing_title && !game_over) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(font_title);
    script_draw_text_shadow(view_xview[0] + 640, view_yview[0] + 360, string(object_Sonic.zones[zone]) + "#Zone Act " + string(act), c_white, 4);
    draw_set_valign(0);
}

// Game Over
if (game_over) {
    draw_set_font(font_game_over);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    script_draw_text_shadow(view_xview[0] + 640, view_yview[0] + 360, "Game Over", c_white, 3);
    draw_set_valign(0);
}