// script_draw
// Stefan Grace
// Created: 2018-01-07
// Modifed: 2024-07-18


// Sonic
if (dead) {
    draw_sprite(sprite_sonic_dead, 0, x, y + dead_sonic_y);
    if (dead_time > 1.5 && lives > 0) {
        draw_set_alpha(1 - ((2 - dead_time) * 2));
        draw_rectangle_color(0, 0, room_width, room_height, c_black, c_black, c_black, c_black, false);
        draw_set_alpha(1);
    }
} else {
    if (shield) {
        draw_set_alpha(0.5);
        draw_ellipse_color(x - 50, y - 50, x + 50, y + 50, $FF8000, $FF1010, false);
        draw_set_alpha(1);
    }
    if (spin || jump || place_meeting (x, y, object_Tunnle) || path_index != -1) {
        draw_sprite_ext(sprite_sonic_spin, floor((time * 30) mod 5), round(x), round(y), facing, 1, 0, c_white, 1);
    } else if (crouch) {
        draw_sprite_ext(sprite_sonic_crouch, 0, round(x), round(y), facing, 1, 0, c_white, 1);
    } else if (flashing) {
        draw_sprite_ext(sprite_sonic_flash, floor((time * 10) mod 2), round(x), round(y), facing, 1, 0, c_white, 1);
    } else if (look_up) {
        draw_sprite_ext(sprite_sonic_look_up, 0, round(x), round(y), facing, 1, 0, c_white, 1);
    } else if (hspeed >= sonic_speed || hspeed <= sonic_speed * -1) {
        draw_sprite_ext(sprite_sonic_running, floor((time * 30) mod 5), round(x), round(y), facing, 1, 0, c_white, 1);
    } else if (hspeed != 0) {
        draw_sprite_ext(sprite_sonic_walking, floor((time * 15) mod 3), round(x), round(y), facing, 1, 0, c_white, 1);
    } else {
        draw_sprite_ext(sprite_sonic, 0, round(x), round(y), facing, 1, 0, c_white, 1);
    }
    if (super_sonic) {
        draw_sprite(sprite_super_sonic, floor((time * 10) mod 2), round(x), round(y));
    }
}

// Fade to Credits
if (fade_to_credits != 0) {
    draw_set_alpha(fade_to_credits);
    draw_rectangle_color(x - 1920, y - 720, x + 1280, y + 720, c_black, c_black, c_black, c_black, false);
    draw_set_alpha(1);
}