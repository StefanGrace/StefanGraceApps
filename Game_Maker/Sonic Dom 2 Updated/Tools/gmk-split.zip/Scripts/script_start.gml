// script_start
// Stefan Grace
// Created: 2018-01-09
// Modified: 2024-07-19


zones[1] = "Extra-Terrestrial";
zones[2] = "Martian";
zones[3] = "Pinball";

zone = global.zone_select + 1;
act = global.act_select + 1;
alarm[0] = 1;
right_bound = room_width;
bottom_bound = room_height;
left_bound = 0;
rings_color = c_red;
time_color = c_yellow;

if (zone != 1 || act != 1) {x = 640;}

if (zone == 1) {
    if (act == 2) {
        room_goto(room_extra_terrestrial_act2);
        y = 837;
        bottom_bound = 1800;
    }
} else if (zone == 2) {
    if (act == 1) {
        room_goto(room_martian_act1);
        y = 3029;
    } else if (act == 2) {
        room_goto(room_martian_act2);
        y = 2101;
    } 
} else if (zone == 3) {
    if (act == 1) {
        room_goto(room_pinball_act1);
        y = 1461;
    } else if (act == 2) {
        room_goto(room_pinball_act2);
        y = 1077;
    }                                                                                 
} 

instance_create(x, y, object_View);
instance_create(0, 0, object_UI);
facing = 1;
lives = 3;
bind_x = x;
bind_y = y;
bind_time = time;
showing_title = true;
title_time = time;
dead_sonic_speed = -20;