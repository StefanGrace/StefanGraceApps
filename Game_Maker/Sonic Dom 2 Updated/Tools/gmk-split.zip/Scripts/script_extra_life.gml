// script_extra_life
// Stefan Grace
// Created: 2018-01-11
// Modifed: 2018-01-11


lives += 1;
just_got_extra_life = true;
extra_life_time = time;