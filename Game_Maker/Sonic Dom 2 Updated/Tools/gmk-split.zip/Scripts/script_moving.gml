// script_moving_v
// Stefan Grace
// Created: 2018-01-22
// Modifed: 2018-01-22
// This script makes platforms move 

if (place_meeting(x, y, other)) {
    x = other.x
    y = other.y
}
