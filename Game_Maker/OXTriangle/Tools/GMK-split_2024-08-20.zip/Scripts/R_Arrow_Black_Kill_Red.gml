if (instance_number(Go_Number_Black)==1)
{
    with other instance_destroy()
    instance_destroy()
}