script_execute(Blue_Kill_Stuned)
script_execute(Stuned_Kill_Blue)

        
    