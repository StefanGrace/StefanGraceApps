if (Kill==1) script_execute(Blue_Kill_Stuned)

        
    