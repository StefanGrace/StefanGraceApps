if (Kill==0)
{
    if (place_snapped(35,35))
    {
        if (place_meeting(x,y,other)) script_execute(Charm_Script,1)
        if (place_meeting(x+17,y,other)) script_execute(Charm_Script,1)
        if (place_meeting(x,y+17,other)) script_execute(Charm_Script,1)
        if (place_meeting(x+17,y+17,other)) script_execute(Charm_Script,1)
    }
    if (place_meeting(x,y,Teleport))
    {
        var teleport_x;
        var teleport_y;
        with(Teleport)
        {
            if (place_meeting(x,y,other))
            {
                var port_color;
                var port_side;
                port_color = color
                port_side = side
                with (Teleport)
                {
                    if (color==port_color and side!=port_side)
                    {
                        teleport_x = x
                        teleport_y = y
                    }
                }
            }
        }
        if (other.x - (other.x mod grid_size) == teleport_x and other.y - (other.y mod grid_size) == teleport_y) 
        {
            script_execute(Charm_Script,1)
        }
    }
}
else script_execute(Blue_Kill_Stuned)