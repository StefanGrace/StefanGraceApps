// Message_Draw_Script
// Stefan Grace
// Created: 2017-07-22
// Modified: 2020-05-11

/* Message Types
0 - Level Start
10 - Double Boxing Horizonal
11 - Double Boxing Vertical
20 - B
21 - @
22 - T
23 - $
24 - Big W
30 - Neutral characters in dimond
40 - Level 16 Instruction
41 - Level 24 Instructions
50 - Level 0 Introduction
*/

draw_set_font(Message_Font)
draw_set_halign(fa_center)
draw_set_valign(fa_center)
draw_set_color($84180B)
draw_sprite(Message_Sprite,0,x,y)
if (global.message_type==0) 
{
    draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_message_level[global.levelnumber],message_line_spacing,sprite_width-5)
    if (global.levelnumber>0)
    {
        draw_text_color(x+145,y+25,global.text_view_alumax,c_blue,c_blue,c_blue,c_blue,100)
        var underline_lenghth;
        underline = ""
        repeat(string_length(global.text_view_alumax)) underline += "_"
        draw_text_color(x+145,y+25,underline,c_blue,c_blue,c_blue,c_blue,100)    
    }
}
if (global.message_type==10) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_double_boxing_entry_horizontal,message_line_spacing,sprite_width-5)
if (global.message_type==11) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_double_boxing_entry_vertical,message_line_spacing,sprite_width-5)
if (global.message_type==20) 
{
    var player_name;
    if (instance_number(Go_Number_Red)>0) player_name = global.Player_Two
    if (instance_number(Go_Number_Black)>0) player_name = global.Player_One
    draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,player_name+", "+global.text_choose_which_character_you_want_to_lose,message_line_spacing,sprite_width-5)
    draw_text_color(x+80,y+25,global.text_help,c_blue,c_blue,c_blue,c_blue,100)
    var underline_lenghth;
    underline = ""
    repeat(string_length(global.text_help)) underline += "_"
    draw_text_color(x+80,y+25,underline,c_blue,c_blue,c_blue,c_blue,100)
}
if (global.message_type==21) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_message_at_swapping,message_line_spacing,sprite_width-5)
if (global.message_type==22) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_message_t_detonate,message_line_spacing,sprite_width-5)
if (global.message_type==23) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_message_dollar_sign_stunning,message_line_spacing,sprite_width-5)
if (global.message_type==30) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_message_neutral_characters_in_diamond,message_line_spacing,sprite_width-5)
if (global.message_type==40) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_16_instruction[global.level16messagenumber],message_line_spacing,sprite_width-5)
if (global.message_type==41) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_24_instruction[Memory_Control.level24messagenumber],message_line_spacing,sprite_width-5)
if (global.message_type==50) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.Player_One+" "+global.text_level_0_intro[0],message_line_spacing,sprite_width-5)
if (global.message_type==51) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.Player_Two+" "+global.text_level_0_intro[1],message_line_spacing,sprite_width-5)
if (global.message_type==52) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_0_intro[2],message_line_spacing,sprite_width-5)
if (global.message_type==53) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_0_intro[3],message_line_spacing,sprite_width-5)
if (global.message_type==54) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_0_intro[4],message_line_spacing,sprite_width-5)
if (global.message_type==55) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_click+' '+global.Player_One+', '+global.Player_Two+" "+global.text_level_0_intro[5],message_line_spacing,sprite_width-5)
if (global.message_type==56) 
{
    var player_name;
    player_name = ""
    if (instance_number(Go_Number_Red)>0) player_name = global.Player_One
    if (instance_number(Go_Number_Black)>0) player_name = global.Player_Two
    draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,player_name+", "+global.text_level_0_intro[6],message_line_spacing,sprite_width-5)
}
if (global.message_type==57) draw_text_ext(x+(sprite_width/2),y+(sprite_height/2)+5,global.text_level_0_intro[7],message_line_spacing,sprite_width-5)
draw_set_halign(0)
draw_set_valign(0)