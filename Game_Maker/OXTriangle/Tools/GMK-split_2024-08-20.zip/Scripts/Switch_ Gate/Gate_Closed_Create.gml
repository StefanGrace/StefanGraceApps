for (i=grid_size; i<=gate_size*2*grid_size; i+=grid_size)
{
    if (gate_type==0) barria_objects[(i-1)/grid_size] = instance_create(x,y+i,Barria_Vertical)
    if (gate_type==1) barria_objects[(i-1)/grid_size] = instance_create(x+i,y,Barria_Horizontal)
    if (gate_type==2) barria_objects[(i-1)/grid_size] = instance_create(x+grid_size,y+i,Barria_Vertical)
    if (gate_type==3) barria_objects[(i-1)/grid_size] = instance_create(x+i,y+grid_size,Barria_Horizontal)
    barria_objects[(i-1)/grid_size].gate = true
}