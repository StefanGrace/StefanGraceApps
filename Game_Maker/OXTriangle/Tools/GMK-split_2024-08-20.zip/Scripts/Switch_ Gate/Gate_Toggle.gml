gate_open = !gate_open
score -= 1
if (gate_open)
{
    Gate_Destroy()
    Gate_Open_Create()
    sound_stop(Gate_Close_Sound)
    sound_stop(Gate_Open_Sound)
    sound_play(Gate_Open_Sound)
}
else
{
    Gate_Destroy()
    Gate_Closed_Create()
    sound_stop(Gate_Open_Sound)
    sound_stop(Gate_Close_Sound)
    sound_play(Gate_Close_Sound)
}