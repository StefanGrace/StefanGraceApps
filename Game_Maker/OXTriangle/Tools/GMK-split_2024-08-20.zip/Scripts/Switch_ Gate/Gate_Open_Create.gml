var index;
index = 0
var i;
for (i=grid_size; i<=gate_size*grid_size; i+=grid_size)
{
        if (gate_type==0) 
        {
            barria_objects[index] = instance_create(x-i,y+grid_size,Barria_Horizontal)
            barria_objects[index+1] = instance_create(x-i,y+grid_size+(grid_size*2*gate_size),Barria_Horizontal)
        }
        else if (gate_type==1) 
        {
            barria_objects[index] = instance_create(x+grid_size,y-i,Barria_Vertical)
            barria_objects[index+1] = instance_create(x+grid_size+(grid_size*2*gate_size),y-i,Barria_Vertical)
        }
        else if (gate_type==2) 
        {
            barria_objects[index] = instance_create(x+i,y+grid_size,Barria_Horizontal)
            barria_objects[index+1] = instance_create(x+i,y+grid_size+(grid_size*2*gate_size),Barria_Horizontal)
        }
        else if (gate_type==3) 
        {
            barria_objects[index] = instance_create(x+grid_size,y+i,Barria_Vertical)
            barria_objects[index+1] = instance_create(x+grid_size+(grid_size*2*gate_size),y+i,Barria_Vertical)
        }
        barria_objects[index].gate = true
        barria_objects[index+1].gate = true
        index += 2
}