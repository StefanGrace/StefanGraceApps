var i;
for (i = 0; i < 36; i += 1)
{
    if (barria_objects[i] != 0) with(barria_objects[i]) instance_destroy()
}