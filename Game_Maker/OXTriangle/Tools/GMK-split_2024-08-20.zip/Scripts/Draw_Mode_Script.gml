// Draw_Mode_Script
// Stefan Grace
// Created: 2016-07-14
// Modifed: 2016-07-14
// This script toggels Draw Mode


if (clicked==0)
{
    if (argument0==1)
    {
        if (global.D_M_Red_on==0)
        {
            global.D_M_Red_on = 1
            clicked = 1
            alarm[0] = 20
        }
        else if (global.D_M_Red_on==1)
        {
            global.D_M_Red_on = 0
            clicked = 1
            alarm[0] = 20
        }
    }
    if (argument0==2)
    {
        if (global.D_M_Black_on==0)
        {
            global.D_M_Black_on = 1
            clicked = 1
            alarm[0] = 20
        }
        else if (global.D_M_Black_on==1)
        {
            global.D_M_Black_on = 0
            clicked = 1
            alarm[0] = 20
        }
    }
}