// Connect_4_Script
// Stefan Grace
// Created: 2016-07-31
// Modified: 2016-08-01
// This script controls the Connect 4 room

// This block of code changes the go number into the player's turn
if (instance_number(Go_Number_Red)>0) with(Go_Number_Red) instance_change(Connect_4_P1_Turn,false)
if (instance_number(Go_Number_Black)>0) with(Go_Number_Black) instance_change(Connect_4_P2_Turn,false)

// This block of code gets rid of the Draw Mode button
if (instance_number(Draw_Mode_Red)>0) with(Draw_Mode_Red) instance_destroy()
if (instance_number(Draw_Mode_Black)>0) with(Draw_Mode_Black) instance_destroy()

// This block of code resets the level if it fills up before the level has been won
if (instance_number(Connect_4_O)+instance_number(Connect_4_X)+instance_number(Connect_4_O_Yellow)+instance_number(Connect_4_X_Yellow)+instance_number(Rock)+instance_number(Dimond))>719
{
    with(Connect_4_X) instance_destroy()
    with(Connect_4_O) instance_destroy()
    with(Connect_4_X_Yellow) instance_destroy()
    with(Connect_4_O_Yellow) instance_destroy()
    with(Red_Vertical_Line) instance_destroy()
    with(Red_Horizontal_Line) instance_destroy()
    with(Red_Diagonal_Line_TL_BR) instance_destroy()
    with(Red_Diagonal_Line_TR_BL) instance_destroy()
    with(Black_Vertical_Line) instance_destroy()
    with(Black_Horizontal_Line) instance_destroy()
    with(Black_Diagonal_Line_TL_BR) instance_destroy()
    with(Black_Diagonal_Line_TR_BL) instance_destroy()
}

// This block of code makes the player who reaches 5 points first win
if (global.Player_One_Lines>4) and (instance_number(Player_One_Winz)==0) instance_create(0,0,Player_One_Winz)
if (global.Player_Two_Lines>4) and (instance_number(Player_Two_Winz)==0) instance_create(0,0,Player_Two_Winz)
