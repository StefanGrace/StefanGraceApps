// Line_Get
// Stefan Grace
// Created: 2016-07-31
// Modified: 2017-07-23
// This script is executed when a player gets 4 in a line on connect 4

/*
argument0
    0 = Player 1
    1 = Player 2
*/


if (argument0==0) global.Player_One_Lines = global.Player_One_Lines+1
if (argument0==1) global.Player_Two_Lines = global.Player_Two_Lines+1
with(Connect_4_X) instance_change(Connect_4_X_Yellow,false)
with(Connect_4_O) instance_change(Connect_4_O_Yellow,false)
if global.level16message2hasshown == 0
{
    global.level16message2hasshown = 1
    global.level16messagenumber = 2
    global.message_type = 40
    instance_create(105,210,Message_Object)
}
