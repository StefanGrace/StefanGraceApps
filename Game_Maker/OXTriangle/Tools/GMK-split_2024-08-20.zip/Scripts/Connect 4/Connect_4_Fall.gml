// Connect_4_Fall
// Stefan Grace
// Created: 2016-07-31
// Modified: 2016-08-01
// This script makes the 'X's and 'O's and fall on Connect 4

if !(place_meeting(x,y+35,Connect_4_X)) and !(place_meeting(x,y+35,Connect_4_O)) and !(place_meeting(x,y+35,Connect_4_X_Yellow)) and !(place_meeting(x,y+35,Connect_4_O_Yellow)) and ((place_meeting(x,y+35,Yellow))) y = y+35