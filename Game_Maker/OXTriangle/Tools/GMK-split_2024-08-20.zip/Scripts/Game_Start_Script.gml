// Game_Start_Script
// Stefan Grace
// Created: 2017-06-20
// Modified: 2022-08-21
// This script is executed when the game starts

// Language
script_execute(English)
if (file_exists(working_directory+"\Settings\Language.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Language.txt")
    global.Language = file_text_read_real(file)
    file_text_close(file)
    if (global.Language==1) script_execute(French)
    if (global.Language==2) script_execute(Spanish)
    if (global.Language==3) script_execute(German)
}

// Player 1 Name
global.Player_One = global.text_player+" 1"
if (file_exists(working_directory+"\Settings\Player_1_Name.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Player_1_Name.txt")
    global.Player_One = file_text_read_string(file)
    file_text_close(file)
}

// Player 2 Name
global.Player_Two = global.text_player+" 2"
if (file_exists(working_directory+"\Settings\Player_2_Name.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Player_2_Name.txt")
    global.Player_Two = file_text_read_string(file)
    file_text_close(file)
}

// Message Apperance
message_background(Message_background)
message_button(Message_button) 
message_button_font(font,18,c_blue,bold)
message_size(636,172)
message_text_font(font,18,c_white,bold)

// Character Text
global.character_text[0] = "O"
global.character_text[1] = "X"
global.character_text[2] = "Triangle"
global.character_text[3] = "A"
global.character_text[4] = "Square"
global.character_text[5] = "K"
global.character_text[6] = "B"
global.character_text[7] = "E"
global.character_text[8] = "S"
global.character_text[9] = "H"
global.character_text[10] = "R"
global.character_text[11] = "M"
global.character_text[12] = "F"
global.character_text[13] = "G"
global.character_text[14] = "C"
global.character_text[15] = "Y"
global.character_text[16] = "Z"
global.character_text[17] = "W"
global.character_text[18] = "J"
global.character_text[19] = "V"
global.character_text[20] = "P"
global.character_text[21] = "T"
global.character_text[22] = "D"
global.character_text[23] = "Q"
global.character_text[24] = "N"
global.character_text[25] = "Gigga G"
global.character_text[26] = "?"
global.character_text[27] = "U"
global.character_text[28] = "L"
global.character_text[29] = "$"
global.character_text[30] = "@"
global.character_text[31] = "Pi"
global.character_text[32] = "I"
global.character_text[33] = "Big W"
global.character_text[34] = "Terra G"
global.character_text[35] = "Purple ?"
global.character_text[100] = "q"

// Music
Last_Music = 0
if (file_exists(working_directory+"\Settings\Music.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Music.txt")
    global.Music_Playing = file_text_read_real(file)
    file_text_close(file)
}

// Date and Time Format Settings
var date_time_val;
if (file_exists(working_directory+"\Settings\Date_Time.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Date_Time.txt")
    date_time_val = file_text_read_real(file)
    file_text_close(file)
    global.Date_Order = date_time_val mod 10
    global.Time_Format = ((date_time_val mod 100) - (date_time_val mod 10))/10
    global.Date_Time_Order = ((date_time_val mod 1000) - (date_time_val mod 100))/100
    global.Year_Format = ((date_time_val mod 10000) - (date_time_val mod 1000))/1000
    global.Month_Format = ((date_time_val mod 100000) - (date_time_val mod 10000))/10000
}

// Show Backgrounds
Last_Music = 0
if (file_exists(working_directory+"\Settings\Show_Backgrounds.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Show_Backgrounds.txt")
    global.show_backgrounds = file_text_read_real(file)
    file_text_close(file)
}

// Show Backgrounds
global.show_backgrounds = true
if (file_exists(working_directory+"\Settings\Show_Backgrounds.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Show_Backgrounds.txt")
    global.show_backgrounds = file_text_read_real(file)
    file_text_close(file)
}

// Cheats
global.cheats = true
if (file_exists(working_directory+"\Settings\Cheats.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Cheats.txt")
    global.cheats = file_text_read_real(file)
    file_text_close(file)
}

// Tablet Mode
global.tablet_mode = false
if (file_exists(working_directory+"\Settings\Tablet_Mode.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Tablet_Mode.txt")
    global.tablet_mode = file_text_read_real(file)
    file_text_close(file)
}

// Fullscreen
if (file_exists(working_directory+"\Settings\Fullscreen.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Fullscreen.txt")
    window_set_fullscreen(file_text_read_real(file))
    file_text_close(file)
}

// Window caption
show_score = false;