var chars;
chars = argument0
var chars_text;
chars_text = ""



var j;
for (j = 0; j < argument1; j += 1)
{
    var char_letter;
    switch (chars[j].character_id)
    {
        case 2: char_letter = "d"; break;
        case 4: char_letter = "s"; break;
        case 25: char_letter = "g"; break;
        case 31: char_letter = "p"; break;
        case 33: char_letter = "w"; break;
        case 34: char_letter = "t"; break;
        case 35: char_letter = "m"; break;
        default: char_letter = global.character_text[chars[j].character_id]; break;
    }
    chars_text += char_letter
    chars_text += string_replace_all(string_format(chars[j].x, 4, 0)," ", "0")    
    chars_text += string_replace_all(string_format(chars[j].y, 4, 0)," ", "0")   
}

return chars_text