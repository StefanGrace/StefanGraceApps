// Base_Clear
// Stefan Grace
// Created: 2016-08-02
// Modified: 2017-07-18
// This script clears the bases

// Level 0
if (global.levelnumber==0)
{
    with(all)
    {
        if (x>769) and (x<805) and (y>664) and (y<700) instance_destroy() 
        if (x>524) and (x<560) and (y>069) and (y<105) instance_destroy()
    }
    instance_create(770,665,Yellow)
    instance_create(525,070,Yellow)
}

// Level 1
if (global.levelnumber==1)
{
    with(all)
    {
        if (x>769) and (x<840) and (y>664) and (y<700) instance_destroy()
        if (x>384) and (x<455) and (y>139) and (y<175) instance_destroy()
    }
    instance_create(770,665,Yellow)
    instance_create(805,665,Yellow)
    instance_create(385,140,Yellow)
    instance_create(420,140,Yellow)
}

// Level 2
if (global.levelnumber==2)
{
    with(all)
    {
        if (x>944) and (x<980) and (y>629) and (y<700) instance_destroy()
        if (x>314) and (x<350) and (y>069) and (y<140) instance_destroy()
    }
    instance_create(945,630,Yellow)
    instance_create(945,665,Yellow)
    instance_create(315,070,Yellow)
    instance_create(315,105,Yellow)
}

// Level 3
if (global.levelnumber==3)
{
    with(all)
    {
        if (x>909) and (x<980) and (y>654) and (y<690) instance_destroy()
        if (x>909) and (x<980) and (y>069) and (y<105) instance_destroy()
    }
    instance_create(910,665,Yellow)
    instance_create(945,665,Yellow)
    instance_create(910,70,Yellow)
    instance_create(345,70,Yellow)
}

// Level 4
if (global.levelnumber==4)
{
    with(all)
    {
        if (x>1224) and (x<1295) and (y>664) and (y<735) instance_destroy()
        if (x>34) and (x<105) and (y>665) and (y<735) instance_destroy()
    }
    instance_create(1225,665,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1225,700,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
}

// Level 5
if (global.levelnumber==5)
{
    with(all)
    {
        if (x>909) and (x<980) and (y>069) and (y<140) instance_destroy()
        if (x>349) and (x<420) and (y>629) and (y<700) instance_destroy()
    }
    instance_create(910,70,Yellow)
    instance_create(945,70,Yellow)
    instance_create(910,105,Yellow)
    instance_create(945,105,Yellow)
    instance_create(350,630,Yellow)
    instance_create(385,630,Yellow)
    instance_create(350,665,Yellow)
    instance_create(350,665,Yellow)
}

// Level 6
if (global.levelnumber==6)
{
    with(all)
    {
        if (x>349) and (x<420) and (y>664) and (y<700) instance_destroy()
        if (x>384) and (x<420) and (y>699) and (y<735) instance_destroy()
        if (x>874) and (x<910) and (y>034) and (y<105) instance_destroy()
        if (x>909) and (x<945) and (y>069) and (y<105) instance_destroy()
    }
    instance_create(350,665,Yellow)
    instance_create(385,665,Yellow)
    instance_create(385,700,Yellow)
    instance_create(875,35,Yellow)
    instance_create(875,70,Yellow)
    instance_create(910,70,Yellow)
}
        
// Level 7
if (global.levelnumber==7)
{
    with(all)
    {
        if (x>34) and (x<105) and (y>314) and (y<420) instance_destroy()
        if (x>1224) and (x<1295) and (y>314) and (y<420) instance_destroy()
    }
    instance_create(35,315,Yellow)
    instance_create(70,315,Yellow)
    instance_create(35,350,Yellow)
    instance_create(70,350,Yellow)
    instance_create(35,385,Yellow)
    instance_create(70,385,Yellow)
    instance_create(1225,315,Yellow)
    instance_create(1260,315,Yellow)
    instance_create(1225,350,Yellow)
    instance_create(1260,350,Yellow)
    instance_create(1225,385,Yellow)
    instance_create(1260,385,Yellow)
}

// Level 8
if (global.levelnumber==8)
{
    with(all)
    {
        if (x>1224) and (x<1295) and (y>594) and (y<700) instance_destroy()
        if (x>34) and (x<105) and (y>594) and (y<700) instance_destroy()
    }
    instance_create(1225,595,Yellow)
    instance_create(1260,595,Yellow)
    instance_create(1225,630,Yellow)
    instance_create(1260,630,Yellow)
    instance_create(1225,665,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(35,595,Yellow)
    instance_create(70,595,Yellow)
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
}

// Level 9
if (global.levelnumber==9)
{
    with(all)
    {
        if (x>1119) and (x<1190) and (y>629) and (y<735) instance_destroy()
        if (x>1084) and (x<1120) and (y>699) and (y<735) instance_destroy()
        if (x>34) and (x<105) and (y>629) and (y<735) instance_destroy()
        if (x>104) and (x<140) and (y>699) and (y<735) instance_destroy()
    }
    instance_create(1120,630,Yellow)
    instance_create(1155,630,Yellow)
    instance_create(1120,665,Yellow)
    instance_create(1155,665,Yellow)
    instance_create(1120,700,Yellow)
    instance_create(1155,700,Yellow)
    instance_create(1085,700,Yellow)
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
    instance_create(105,700,Yellow)
}

// Level 10
if (global.levelnumber==10)
{
    with(all)
    {
        if (x>34) and (x<70) and (y>629) and (y<735) instance_destroy()
        if (x>104) and (x<140) and (y>664) and (y<735) instance_destroy()
        if (x>174) and (x<210) and (y>699) and (y<735) instance_destroy()
        if (x>244) and (x<280) and (y>699) and (y<735) instance_destroy()
        if (x>1259) and (x<1295) and (y>629) and (y<735) instance_destroy()
        if (x>1189) and (x<1225) and (y>664) and (y<735) instance_destroy()
        if (x>1119) and (x<1155) and (y>699) and (y<735) instance_destroy()
        if (x>1049) and (x<1085) and (y>699) and (y<735) instance_destroy()
    }
    instance_create(1260,630,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(1190,665,Yellow)
    instance_create(1190,700,Yellow)
    instance_create(1120,700,Yellow)
    instance_create(1050,700,Yellow)
    instance_create(35,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(105,665,Yellow)
    instance_create(105,700,Yellow)
    instance_create(175,700,Yellow)
    instance_create(245,700,Yellow)
}

// Level 11
if (global.levelnumber==11)
{
    with(all)
    {
        if (x>34) and (x<105) and (y>629) and (y<735) instance_destroy()
        if (x>1224) and (x<1295) and (y>629) and (y<735) instance_destroy()
    }
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
    instance_create(1260,630,Yellow)
    instance_create(1225,630,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1225,665,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(1225,700,Yellow)
}

// Level 12
if (global.levelnumber==12)
{
    with(all)
    {
        if (x>34) and (x<105) and (y>314) and (y<385) instance_destroy()
        if (x>34) and (x<70) and (y>384) and (y<419) instance_destroy()
        if (x>1224) and (x<1295) and (y>314) and (y<385) instance_destroy()
        if (x>1259) and (x<1295) and (y>384) and (y<419) instance_destroy()
    }
    instance_create(1260,315,Yellow)
    instance_create(1225,315,Yellow)
    instance_create(1260,350,Yellow)
    instance_create(1225,350,Yellow)
    instance_create(1260,385,Yellow)
    instance_create(35,315,Yellow)
    instance_create(70,315,Yellow)
    instance_create(35,350,Yellow)
    instance_create(70,350,Yellow)
    instance_create(35,385,Yellow)
}

// Level 13
if (global.levelnumber==13)
{
    with(all)
    {
        if (x>34) and (x<140) and (y>244) and (y<315) instance_destroy()
        if (x>34) and (x<70) and (y>314) and (y<350) instance_destroy()
        if (x>1189) and (x<1295) and (y>244) and (y<315) instance_destroy()
        if (x>1259) and (x<1295) and (y>314) and (y<350) instance_destroy()
    }
    instance_create(1260,245,Yellow)
    instance_create(1225,245,Yellow)
    instance_create(1190,245,Yellow)
    instance_create(1260,280,Yellow)
    instance_create(1225,280,Yellow)
    instance_create(1190,280,Yellow)
    instance_create(1260,315,Yellow)
    instance_create(35,245,Yellow)
    instance_create(70,245,Yellow)
    instance_create(105,245,Yellow)
    instance_create(35,280,Yellow)
    instance_create(70,280,Yellow)
    instance_create(105,280,Yellow)
    instance_create(35,315,Yellow)
}

// Level 14
if (global.levelnumber==14)
{
    with(all)
    {
        if (x>34) and (x<105) and (y>594) and (y<735) instance_destroy()
        if (x>1224) and (x<1295) and (y>594) and (y<735) instance_destroy()
    }
    instance_create(1260,595,Yellow)
    instance_create(1225,595,Yellow)
    instance_create(1260,630,Yellow)
    instance_create(1225,630,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1225,665,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(1225,700,Yellow)
    instance_create(35,595,Yellow)
    instance_create(70,595,Yellow)
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
}

// Level 15
if (global.levelnumber==15)
{
    with(all)
    {
        if (x>34) and (x<140) and (y>629) and (y<700) instance_destroy()
        if (x>34) and (x<105) and (y>699) and (y<735) instance_destroy()
        if (x>1189) and (x<1295) and (y>629) and (y<700) instance_destroy()
        if (x>1224) and (x<1295) and (y>699) and (y<735) instance_destroy()
    }
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(105,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(105,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
    instance_create(1260,630,Yellow)
    instance_create(1225,630,Yellow)
    instance_create(1190,630,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1225,665,Yellow)
    instance_create(1190,665,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(1225,700,Yellow)
}

// Level 17
if (global.levelnumber==17)
{
    with(all)
    {
        if (x>34) and (x<140) and (y>629) and (y<735) instance_destroy()
        if (x>1189) and (x<1295) and (y>629) and (y<735) instance_destroy()
    }
    instance_create(35,630,Yellow)
    instance_create(70,630,Yellow)
    instance_create(105,630,Yellow)
    instance_create(35,665,Yellow)
    instance_create(70,665,Yellow)
    instance_create(105,665,Yellow)
    instance_create(35,700,Yellow)
    instance_create(70,700,Yellow)
    instance_create(105,700,Yellow)
    instance_create(1260,630,Yellow)
    instance_create(1225,630,Yellow)
    instance_create(1190,630,Yellow)
    instance_create(1260,665,Yellow)
    instance_create(1225,665,Yellow)
    instance_create(1190,665,Yellow)
    instance_create(1260,700,Yellow)
    instance_create(1225,700,Yellow)
    instance_create(1190,700,Yellow)
}

// Level 18
if (global.levelnumber==18)
{
    with(all)
    {
        if ((x>=1*grid_size) and (x<2*grid_size)) or ((x>=36*grid_size) and (x<37*grid_size))
        {
            if ((y>=1*grid_size) and (y<2*grid_size)) or ((y>=3*grid_size) and (y<4*grid_size)) or ((y>=5*grid_size) and (y<6*grid_size)) or ((y>=7*grid_size) and (y<8*grid_size)) or ((y>=9*grid_size) and (y<11*grid_size)) instance_destroy()
            if ((y>=12*grid_size) and (y<13*grid_size)) or ((y>=14*grid_size) and (y<15*grid_size)) or ((y>=16*grid_size) and (y<17*grid_size)) or ((y>=18*grid_size) and (y<19*grid_size)) or ((y>=20*grid_size) and (y<21*grid_size)) instance_destroy()
        }
    }
    instance_create(1*grid_size,1*grid_size,Yellow)
    instance_create(3*grid_size,1*grid_size,Yellow)
    instance_create(5*grid_size,1*grid_size,Yellow)
    instance_create(7*grid_size,1*grid_size,Yellow)
    instance_create(9*grid_size,1*grid_size,Yellow)
    instance_create(10*grid_size,1*grid_size,Yellow)
    instance_create(12*grid_size,1*grid_size,Yellow)
    instance_create(14*grid_size,1*grid_size,Yellow)
    instance_create(16*grid_size,1*grid_size,Yellow)
    instance_create(18*grid_size,1*grid_size,Yellow)
    instance_create(20*grid_size,1*grid_size,Yellow)
    instance_create(1*grid_size,36*grid_size,Yellow)
    instance_create(3*grid_size,36*grid_size,Yellow)
    instance_create(5*grid_size,36*grid_size,Yellow)
    instance_create(7*grid_size,36*grid_size,Yellow)
    instance_create(9*grid_size,36*grid_size,Yellow)
    instance_create(10*grid_size,36*grid_size,Yellow)
    instance_create(12*grid_size,36*grid_size,Yellow)
    instance_create(14*grid_size,36*grid_size,Yellow)
    instance_create(16*grid_size,36*grid_size,Yellow)
    instance_create(18*grid_size,36*grid_size,Yellow)
    instance_create(20*grid_size,36*grid_size,Yellow)
}