// Draw_Mode_Check
// Stefan Grace
// Created: 2016-08-02
// Modified: 2017-07-18
// This script resest the bases if draw mode is activated by both players

if (global.D_M_Red_on>0) and (global.D_M_Black_on>0) 
{
    if (global.D_M_Count<3)
    {
        global.D_M_Red_on = 0
        global.D_M_Black_on = 0
        global.D_M_Count += 1
        script_execute(Base_Clear)
        script_execute(Base_Create)
        if (instance_number(Go_Number_Red)>0) script_execute(Red_Unstun)
        if (instance_number(Go_Number_Black)>0) script_execute(Black_Unstun)
    }
    else
    {
        global.D_M_Count = 0
        room_restart()
    }
}
