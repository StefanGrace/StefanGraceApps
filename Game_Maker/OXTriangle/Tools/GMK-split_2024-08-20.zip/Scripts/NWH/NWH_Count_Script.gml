// NWH_Count_Script
// Stefan Grace
// Created: 2016-06-29
// Modified: 2018-11-06

/* arguments

argument0 - Player
    1 - Player 1
    2 - Player 2
*/


var place_fill_red;
var place_fill_black;
var i;
for (i = 0; i < 6; i += 1)
{
    place_fill_red_red[i] = false
    place_fill_black[i] = false
}
with(all)
{
    var tile_x;
    var tile_y;
    tile_x = x - (x mod grid_size)
    tile_y = y - (y mod grid_size)
    if (character_id + character_o > 0)
    {
        if (player == 1 and argument0 == 1)
        {
            if (tile_x == other.x - grid_size)
            {
                if (tile_y == other.y - grid_size) place_fill_red[0] = true
                else if (tile_y == other.y) place_fill_red[1] = true
                else if (tile_y == other.y + grid_size) place_fill_red[2] = true
            }
            else if (tile_x == other.x + grid_size)
            {
                if (tile_y == other.y - grid_size) place_fill_red[3] = true
                else if (tile_y == other.y) place_fill_red[4] = true
                else if (tile_y == other.y + grid_size) place_fill_red[5] = true
            }
        } 
        if (player == 2 and argument0 == 2)
        {
            if (tile_x == other.x - grid_size)
            {
                if (tile_y == other.y - grid_size) place_fill_black[0] = true
                else if (tile_y == other.y) place_fill_black[1] = true
                else if (tile_y == other.y + grid_size) place_fill_black[2] = true
            }
            else if (tile_x == other.x + grid_size)
            {
                if (tile_y == other.y - grid_size) place_fill_black[3] = true
                else if (tile_y == other.y) place_fill_black[4] = true
                else if (tile_y == other.y + grid_size) place_fill_black[5] = true
            }
        } 
    }
}
var places_filled_red;
places_filled_red = 0
var places_filled_black;
places_filled_black = 0
var i;
for (i = 0; i < 6; i += 1)
{
    if (place_fill_red[i]) places_filled_red += 1
    if (place_fill_black[i]) places_filled_black += 1
}
if (places_filled_red >= 6)
{
    if (count < 5) count += 1
}
if (places_filled_black >= 6)
{
    if (count > -5) count -= 1
}