// NWH_Draw
// Stefan Grace
// Created: 2018-11-06
// Modified: 2018-11-06
// This script draws the center of the NWH including the number

draw_sprite(NWH_Sprite,0,x,y)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)
draw_set_font(NWH_Font)
if (count > 0) 
{
    draw_set_color(character_color_red)
}
else if (count < 0) 
{
    draw_set_color(character_color_black)
}
else
{
    draw_set_color(character_color_green)
}
draw_text(x + 17,y + 17,sqrt(sqr(count)))
draw_set_halign(0)
draw_set_valign(0)