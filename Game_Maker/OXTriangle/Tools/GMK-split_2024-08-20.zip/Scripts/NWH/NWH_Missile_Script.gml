// Nuclear War Head Missile Scrip 
// Stefan Grace
// Created: 2016-07-18
// Modified: 2017-11-03
// This script controls the Nuclear War Head Missile 

if (y>-100 and !gone_up) 
{
    y -= 4
    //x += x - ((sqr(NWH_Target.x) / sqrt(NWH_Target.x)) / 500)
    if (x>NWH_Target.x) x -= 2
    if (x<NWH_Target.x) x += 2
    image_angle = 90
}
else if (turned<20)
{
    //image_angle = (((point_direction(x,y,NWH_Target.x,NWH_Target.y) * turned) + (90 * (20 - turned))) / 40) + 180
    turned += 1
}
else
{
    move_towards_point(NWH_Target.x,NWH_Target.y,4)
    gone_up = true
    image_angle = point_direction(x,y,NWH_Target.x,NWH_Target.y)
}



