// NWH_Ring_Draw
// Stefan Grace
// Created: 2017-08-29
// Modified: 2017-08-29
// This script draw the NWH explosion ring

var j;
for(j=0;j<50;j+=0.5)
{
    draw_circle_color(x,y,i+j,c_orange,c_orange,true)
}
i+=5