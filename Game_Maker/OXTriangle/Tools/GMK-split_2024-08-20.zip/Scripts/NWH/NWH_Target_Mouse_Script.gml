// Nuclear War Head Detonate Scrip 
// Stefan Grace
// Created: 2016-07-18
// Modified: 2018-11-07
// This scrip makes the Nuclear War Head Target follow the mouse

if Target_Clicked==0
{
    x=mouse_x-(mouse_x mod grid_size)
    y=mouse_y-(mouse_y mod grid_size)
}
else
{
    if(place_meeting(x,y,NWH_Missile))
    {
        instance_create(x,y,NWH_Ring)
        with(NWH_Missile) instance_destroy()
        if (!(sound_isplaying(M_Sound))) sound_play(M_Sound)
        instance_create(x,y,NWH_Explosion_Center)
        global.game_frozen = 0
        instance_destroy()
    }
}