// Nuclear War Head Detonate Scrip 
// Stefan Grace
// Created: 2016-06-29
// Modified: 2016-06-29
// This scrip makes the Nuclear War Head detonate when the player click on it and then clicks in another place

if(instance_number(NWH_Target)==0) instance_create(mouse_x,mouse_y,NWH_Target)
