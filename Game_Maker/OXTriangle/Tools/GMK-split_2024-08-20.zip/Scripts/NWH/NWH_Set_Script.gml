// Nuclear War Head Set Scrip 
// Stefan Grace
// Created: 2016-07-18
// Modified: 2017-08-26

if(instance_number(NWH_Missile)==0 and instance_number(NWH_Target)>0)
{
    instance_create(x,y,NWH_Missile)
}