if global.Language==0
{
    global.Language=1
    script_execute(French)
    exit
}
else if global.Language==1
{
    global.Language=2
    script_execute(Spanish)
    exit
}
else if global.Language==2
{
    global.Language=3
    script_execute(German)
    exit
}
else if global.Language==3
{
    global.Language=0
    script_execute(English)
    exit
}
