// Big_Explosion_Script
// Stefan Grace
// Created: 2017-08-26
// Modified: 2018-11-08
// This script makes a big explosion the width and height of argument0

if (place_meeting(x,y,Concreet)) 
{
    instance_destroy()
}
else
{   
    var start;
    start = ((argument0 / 2) - 0.5) * -1
    var stop;
    stop = (argument0 / 2) + 0.5
    var i;
    var j;
    for(i = start; i < stop; i += 1)
    {
        for(j = start; j < stop; j += 1)
        {
            if !place_meeting(x + (i * grid_size), y + (j * grid_size), Concreet)
            {
                instance_create(x + (i * grid_size), y + (j * grid_size), NWH_To_Be_Exploded)
            }
        }
    }
}