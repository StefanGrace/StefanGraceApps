// Go_To_Level_Script
// Stefan Grace
// Craeted: 2017-07-23
// Modified: 2018-06-10
// This script goes to the specified level when the thumbnail is clicked

/* Arguments
argument0 - Level Number
*/

/*
if show_question(global.text_load_game)
{
    var fname;
    fname = "Saves\Save_Level_"+string(argument0)
    game_load(fname)
}
*/
//else
{
    global.onlevel = 1
    global.levelnumber = argument0
    if (argument0==-1) room_goto(Test_Level_1)
    if (argument0==-2) room_goto(Test_Level_2)
    if (argument0==-3) room_goto(Test_Level_3)
    if (argument0==-4) room_goto(Test_Level_4)
    if (argument0==-5) room_goto(Test_Level_5)
    if (argument0==-6) room_goto(Test_Level_6)
    if (argument0==-7) room_goto(Test_Level_7)
    if (argument0==-8) room_goto(Test_Level_8)
    if (argument0==-9) room_goto(Test_Level_9)
    if (argument0==-10) room_goto(Test_Level_10)
    if (argument0==0) room_goto(Level_0)
    if (argument0==1) room_goto(Level_1)
    if (argument0==2) room_goto(Level_2)
    if (argument0==3) room_goto(Level_3)
    if (argument0==4) room_goto(Level_4)
    if (argument0==5) room_goto(Level_5)
    if (argument0==6) room_goto(Level_6)
    if (argument0==7) room_goto(Level_7)
    if (argument0==8) room_goto(Level_8)
    if (argument0==9) room_goto(Level_9)
    if (argument0==10) room_goto(Level_10)
    if (argument0==11) room_goto(Level_11)
    if (argument0==12) room_goto(Level_12)
    if (argument0==13) room_goto(Level_13)
    if (argument0==14) room_goto(Level_14)
    if (argument0==15) room_goto(Level_15)
    if (argument0==16) room_goto(Level_16)
    if (argument0==17) room_goto(Level_17)
    if (argument0==18) room_goto(Level_18)
    if (argument0==19) room_goto(Level_19)
    if (argument0==20) room_goto(Level_20)
    if (argument0==21) room_goto(Level_21)
    if (argument0==22) room_goto(Level_22)
    if (argument0==23) room_goto(Level_23)
    if (argument0==24) room_goto(Level_24)
    if (argument0==25) room_goto(Level_25)
    if (argument0==26) room_goto(Level_26)
    if (argument0==27) room_goto(Level_27)
    if (argument0==28) room_goto(Level_28)
}