// Level_0_Intro
// Stefan Grace
// Created: 2019-04-04
// Modified: 2019-04-04

/* arguments

    argument0 - Player
        1 - Player 1
        2 - Player 2
*/


with(Message_Object) instance_destroy()
global.level0messagenumber = 6
global.message_type = 56
if (argument0 == 1)
{   
    if (!global.red_level_0_message_6_hasbeenshown)
    {
        instance_create(875, 560, Message_Object)
        global.red_level_0_message_6_hasbeenshown = true
    }
} 
else 
{
    if (!global.black_level_0_message_6_hasbeenshown)
    {
        instance_create(70, 70, Message_Object)
        global.black_level_0_message_6_hasbeenshown =  true
    }
}

/*
if (instance_number(argument0 == 1))
{
    Move_Message.x = 875
    Move_Message.y = 560
} 
else 
{
    Move_Message.x = 70
    Move_Message.y = 70
}
*/