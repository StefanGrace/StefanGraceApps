// Connect_4_Load
// Stefan Grace
// Created: 2024-07-25
// Modified: 2024-07-27
// This script loads the Connect 4 data from a TXT file

// Read data from file
var filename level_data; 
filename = working_directory + "\Saves\Level_16.txt"
if (file_exists(filename)) 
{
    var file;
    file = file_text_open_read(filename)
    var i;
    for (i = 0; i < 31; i += 1)
    {
        level_data[i] = file_text_read_string(file)
        file_text_readln(file)
    }
    file_text_close(file)
}

// Load player points and turn points form level data
if (string_char_at(level_data[22], 1) == "1")
{
    with (Connect_4_P1_Turn) instance_destroy()
    instance_create(0, 0, Connect_4_P1_Turn)
}
else if (string_char_at(level_data[22], 1) == "2")
{
    with (Connect_4_P2_Turn) instance_destroy()
    instance_create(0, 0, Connect_4_P2_Turn)
}
else
{
    exit
}

global.Player_One_Lines = real(string_char_at(level_data[22], 2))
global.Player_Two_Lines = real(string_char_at(level_data[22], 3))
global.level16messagenumber = real(string_char_at(level_data[22], 5))
global.level16message2hasshown = real(string_char_at(level_data[22], 5))

// Create boulders from level data
var i;
for (i = 0; i < 22; i += 1)
{
    var j;
    for (j = 0; j < 38; j += 1)
    {
        switch (string_char_at(level_data[i], j))
        {
            case "R": instance_create(j * grid_size, i * grid_size, Connect_4_X); break;
            case "B": instance_create(j * grid_size, i * grid_size, Connect_4_O); break;
            case "r": instance_create(j * grid_size, i * grid_size, Connect_4_X_Yellow); break;
            case "b": instance_create(j * grid_size, i * grid_size, Connect_4_O_Yellow); break;
        }
    }
}

// Create lines from level data
var j;
for (j = 23; j < 31; j += 1)
{
    var line;
    switch (j)
    {
        case 23: line = Red_Vertical_Line; break;
        case 24: line = Red_Horizontal_Line; break;
        case 25: line = Red_Diagonal_Line_TL_BR; break;
        case 26: line = Red_Diagonal_Line_TR_BL; break;
        case 27: line = Black_Vertical_Line; break;
        case 28: line = Black_Horizontal_Line; break;
        case 29: line = Black_Diagonal_Line_TL_BR; break;
        case 30: line = Black_Diagonal_Line_TR_BL; break;
    }

    var i;
    for (i = 0; i < string_length(level_data[j]); i += 8)
    {
        var line_x line_y;
        line_x = real(string_copy(level_data[j], i + 1, 4))
        line_y = real(string_copy(level_data[j], i + 5, 4))
        show_debug_message("x: " + string_copy(level_data[j], i + 1, 4));
        show_debug_message("y: " + string_copy(level_data[j], i + 5, 4));
        instance_create(line_x, line_y, line)
    }
}

// Remove player select UI
with(Player_One_Select) instance_destroy()
with(Player_Two_Select) instance_destroy()
with(Player_Select) instance_destroy()
with(Player_Random) instance_destroy()







