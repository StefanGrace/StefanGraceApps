// Teleport_Explosion
// Stefan Grace
// Created: 2017-08-19
// Modified: 2017-12-23
// This scirpt teleports M and J explosions

/* arguments

argument 0 - explosion type
    0 - M
    1 - J
    2 - $

*/

with (Teleport)
{
    if (place_meeting(x,y,other))
    {
        var port_color;
        var port_side;
        port_color = color
        port_side = side
        with (Teleport)
        {
            if (color==port_color and side!=port_side) 
            {
                if (argument0==0) script_execute(M_Detonate)
                if (argument0==1) script_execute(J_Detonate)
                if (argument0==2) script_execute(Dollar_Sign_Stun_Create)
            }
        }
    }
}