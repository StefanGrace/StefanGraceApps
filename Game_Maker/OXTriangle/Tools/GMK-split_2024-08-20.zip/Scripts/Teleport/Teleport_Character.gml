// Teleport_Character
// Stefan Grace
// Created: 2017-10-01
// Modified: 2017-10-01
// This script teleports characters when the ALT key is pressed

var port_color;
var port_side;
port_color = color
port_side = side

with(all)
{
    if (place_meeting(x,y,other) and (type==2 or type==5) and global.gone_port==0)
    {
        global.gone_port = 1
        with(other) alarm [0] = 1
        with(Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                other.x = x
                other.y = y
            }
        }
    }
}