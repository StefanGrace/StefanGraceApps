// Draws the Teleport
if (color==0) draw_sprite(Teleport_Brown,-1,x,y)
if (color==1) draw_sprite(Teleport_Dark_Blue,-1,x,y)
if (color==2) draw_sprite(Teleport_Forest_Green,-1,x,y)
if (color==3) draw_sprite(Teleport_Grey,-1,x,y)
if (color==4) draw_sprite(Teleport_Green,-1,x,y)
if (color==5) draw_sprite(Teleport_Light_Blue,-1,x,y)
if (color==6) draw_sprite(Teleport_Orange,-1,x,y)
if (color==7) draw_sprite(Teleport_Pink,-1,x,y)

// Draws Boulders and Bombs that are in the Teleport
var port_color;
var port_side;
var boulder_bomb_type;
port_color = color
port_side = side
with(Boulder)
{
    if (place_meeting(x,y,other))
    {
        if (time_bomb>0) 
        {
            boulder_bomb_type = 6
        }
        else if (j_bomb>0)
        {
            boulder_bomb_type = 5
        }
        else if (nuclear>0)
        {
            boulder_bomb_type = 4
        }
        else if (concreet_tunnle>0)
        {
            boulder_bomb_type = 3
        }
        else if (dimond_tunnle>0)
        {
            boulder_bomb_type = 2
        }
        else if (rock_tunnle>0)
        {
            boulder_bomb_type = 1
        }
        else 
        {
            boulder_bomb_type = 0
        }
        with(Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                if (boulder_bomb_type==0) draw_sprite(Boulder_Sprite,0,x,y)
                if (boulder_bomb_type==1) draw_sprite(Tunnling_Bomb_Sprite,0,x,y)
                if (boulder_bomb_type==2) draw_sprite(Dimond_Bomb_Sprite,0,x,y)
                if (boulder_bomb_type==3) draw_sprite(Concreet_Bomb_Sprite,0,x,y)
                if (boulder_bomb_type==4) draw_sprite(Nuclear_Bomb_Sprite,0,x,y)
                if (boulder_bomb_type==5) draw_sprite(J_Bomb_Sprite,0,x,y)
                if (boulder_bomb_type==6) draw_sprite(Time_Bomb_Sprite,0,x,y)
            }
        }
    }
}