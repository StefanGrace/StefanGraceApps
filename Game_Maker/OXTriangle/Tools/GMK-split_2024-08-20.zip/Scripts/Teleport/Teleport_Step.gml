var port_color;
var port_side;
port_color = color
port_side = side
with (Boulder) 
{
    if (place_meeting(x,y,other) and global.gone_port==0)
    {
        global.gone_port = 1
        with (other) alarm[0] = 1
        with (Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                other.x = x
                other.y = y
            }
        }
    } 
}
with (R_Arrow) 
{
    if (place_meeting(x,y,other) and global.gone_port==0)
    {
        global.gone_port = 1
        with (other) alarm[0] = 1
        with (Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                other.x = x
                other.y = y
            }
        }
    }
}
with (Explosion) 
{
    if (place_meeting(x,y,other) and global.gone_port==0)
    {
        global.gone_port = 1
        with (other) alarm[0] = 1
        with (Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                instance_create(x,y,Explosion)
            }
        }
    }
}
with (Red_Blue_G) 
{
    if (g_type!=3) if (place_meeting(x,y,other) and global.gone_port==0)
    {
        global.gone_port = 1
        with (other) alarm[0] = 1
        with (Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                instance_create(x,y,Explosion)
            }
        }
    }
}
with (Black_Blue_G) 
{
    if (g_type!=3) if (place_meeting(x,y,other) and global.gone_port==0)
    {
        global.gone_port = 1
        with (other) alarm[0] = 1
        with (Teleport)
        {
            if (color==port_color and side!=port_side)
            {
                instance_create(x,y,Explosion)
            }
        }
    }
}