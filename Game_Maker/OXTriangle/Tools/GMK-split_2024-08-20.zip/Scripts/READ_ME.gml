/* READ_ME

THIS SCRIPT IS JUST COMMENT AND CONTAINS NO ACTUAL CODE

Stefan Grace

READ_ME last updated: 2020-02-24

In-game cheats:
To get to the test levels, press the delete key on the 1st level select menu
To destory any character, boulder or bomb, right click on it
To turn Rock, Dimond, Concreet or Steel into yellow, middle click on it
To increase the go number by 1, left click on it or press num pad +
To decrease the go number by 1, right click on it or press num pad -
To increase the go number by 10, press num pad 1
To set the go number to 0, middle click on it or press 0

Variables:
The built-in 'score' variable is the current go number (the number of goes that are currently left)
The built-in 'lives' variable is the total go number for the level
 
Places where characters are referred to (places that need to be updated every time you add a new character, "*" at start means it hasn't updated done yet):
---SCRIPTS---
Character_Click_Black
Character_Click_Red
Red_Stun
Black_Stun
Red_Unstun
Black_Unstun
Character_Move_Double_Boxing
Place_Meeting_Detect
Neutral_Character_Script
Boulder_Fall
Charm_Script
---OBJECTS---
All Stuned Character - Step Event
R_Arrow - Collison Events

Character IDs:
0 - O
1 - X
2 - Triangle
3 - A
4 - Square
5 - K
6 - B
7 - E
8 - S
9 - H
10 - R
11 - M
12 - F
13 - G
14 - C
15 - Y
16 - Z
17 - W
18 - J
19 - V
20 - P
21 - T
22 - D
23 - Q
24 - N
25 - Gigga G
26 - ?
27 - U
28 - L
29 - $
30 - @
31 - Pi
32 - I
33 - Big W
34 - Terra G
35 - Purple ?

Any questions, 
email: stefangrace@hotmail.co.nz
*/