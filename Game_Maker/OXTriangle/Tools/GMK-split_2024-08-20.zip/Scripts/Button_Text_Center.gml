// Button_Text_Center
// Stefan Grace
// Created: 2016-07-14
// Modified: 2024-07-24
// This script centers text on buttons

/* THIS SCRIPT IS NOW REDUNDANT */

/*
var repeat_times;
Button_Name_Center = Button_Name
if (argument0==0) repeat_times = 13-(string_length(Button_Name))
if (argument0==1) repeat_times = 20-(string_length(Button_Name))
if (argument0==2) repeat_times = 8-(string_length(Button_Name))
repeat(repeat_times) Button_Name_Center = " "+Button_Name_Center
*/