// Player_Two_Select_Script
// Stefan Grace
// Created: 2016-07-19
// Modified: 2019-04-04
// This script is executed when Player 2 is selected to start the level 

script_execute(Black_Unstun)
script_execute(Player_Select_Script)
instance_create(0,0,Go_Number_Black)
instance_create(1120,0,Draw_Mode_Black)
if (global.levelnumber == 0) script_execute(Level_0_Intro, 2)
