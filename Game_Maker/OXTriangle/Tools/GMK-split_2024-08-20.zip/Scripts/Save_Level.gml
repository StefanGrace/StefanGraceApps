// Save_Level
// Stefan Grace
// Created: 2023-08-07
// Modified: 2024-07-27
// This script saves the level data to a TXT file

// Uses the Connect_4_Save script if on Level 16
if (global.levelnumber == 16)
{
    Connect_4_Save()
    exit
}

// Generate level data text with a line for each row
var level_text;
var i;
for (i = 0; i < room_height; i += grid_size)
{
    level_text[i / grid_size] = "";
    var j;
    for (j = 0; j < room_width - 1; j += grid_size)
    {
        var tile_letter;
        tile_letter = "E"
        with(Yellow)
        {
            if (x == j and y == i) {tile_letter = "Y"}
        }
        with(Rock)
        {
            if (x == j and y == i) {tile_letter = "R"}
        }
        with(Dimond)
        {
            if (x == j and y == i) {tile_letter = "D"}
        }
        with(Concreet)
        {
            if (x == j and y == i) {tile_letter = "C"}
        }
        with(Mud)
        {
            if (x == j and y == i) {tile_letter = "M"}
        }
        with(Steel)
        {
            if (x == j and y == i) {tile_letter = "S"}
        }
        with(Double_Boxing)
        {
            if (x == j and y == i) {tile_letter = "B"}
        }
        level_text[i / grid_size] += tile_letter
    }
}

// Save character states
var red_chars;
var black_chars;
var green_chars;
var red_chars_text;
var black_chars_text;
var green_chars_text;
var i;
i = 0
with (Red_Character)
{
    red_chars[i] = id
    i += 1
}
red_chars_text = ""
var j;
for (j = 0; j < i; j += 1)
{
    var char_letter;
    switch (red_chars[j].character_id)
    {
        case 2: char_letter = "d"; break;
        case 4: char_letter = "s"; break;
        case 25: char_letter = "g"; break;
        case 31: char_letter = "p"; break;
        case 33: char_letter = "w"; break;
        case 34: char_letter = "t"; break;
        case 35: char_letter = "m"; break;
        default: char_letter = global.character_text[red_chars[j].character_id]; break;
    }
    red_chars_text += char_letter
    red_chars_text += string_replace_all(string_format(red_chars[j].x, 4, 0)," ", "0")    
    red_chars_text += string_replace_all(string_format(red_chars[j].y, 4, 0)," ", "0")   
}
i = 0;
with (Black_Character)
{
    black_chars[i] = id
    i += 1
}
black_chars_text = ""
var j;
for (j = 0; j < i; j += 1)
{
    var char_letter;
    switch (black_chars[j].character_id)
    {
        case 2: char_letter = "d"; break;
        case 4: char_letter = "s"; break;
        case 25: char_letter = "g"; break;
        case 31: char_letter = "p"; break;
        case 33: char_letter = "w"; break;
        case 34: char_letter = "t"; break;
        case 35: char_letter = "m"; break;
        default: char_letter = global.character_text[black_chars[j].character_id]; break;
    }
    black_chars_text += char_letter
    black_chars_text += string_replace_all(string_format(black_chars[j].x, 4, 0)," ", "0")    
    black_chars_text += string_replace_all(string_format(black_chars[j].y, 4, 0)," ", "0")   
}
i = 0;
with (Green_Character)
{
    green_chars[i] = id
    i += 1
}
green_chars_text = ""
var j;
for (j = 0; j < i; j += 1)
{
    var char_letter;
    switch (green_chars[j].character_id)
    {
        case 2: char_letter = "d"; break;
        case 4: char_letter = "s"; break;
        case 25: char_letter = "g"; break;
        case 31: char_letter = "p"; break;
        case 33: char_letter = "w"; break;
        case 34: char_letter = "t"; break;
        case 35: char_letter = "m"; break;
        default: char_letter = global.character_text[green_chars[j].character_id]; break;
    }
    green_chars_text += char_letter
    green_chars_text += string_replace_all(string_format(green_chars[j].x, 4, 0)," ", "0")    
    green_chars_text += string_replace_all(string_format(green_chars[j].y, 4, 0)," ", "0")   
}

// Pick file name
var file_path, lvl_num_text;
lvl_num_text = string_replace_all(string_format(global.levelnumber, 2, 0), " ", "0")
file_path = working_directory + "\Saves\Level_" + lvl_num_text + ".txt"

// Check that file is not read-only
if (file_attributes(file_path, fa_readonly)) {exit}

// Blank the file first    
var file;
file = file_text_open_write(file_path)
file_text_write_string(file, "")
file_text_close(file)

// Write level data text to file    
file = file_text_open_append(file_path)
var i;
for (i = 0; i < 22; i += 1) 
{
   file_text_write_string(file, level_text[i])
   file_text_writeln(file)
}
file_text_write_string(file, red_chars_text)
file_text_writeln(file)
file_text_write_string(file, black_chars_text)
file_text_writeln(file)
file_text_write_string(file, green_chars_text)
file_text_close(file)
