with (Player_Change_Black) instance_destroy()
with (Player_Change_Red) instance_destroy()
alarm[0] = 120
script_execute(Character_Click_Black)
script_execute(Character_Click_Red)
script_execute(Red_Stun)
script_execute(Black_Stun)
script_execute(Delete_Save)
with (Message_Object) instance_destroy()
with (X_Message) instance_destroy()
with (Move_Message) instance_destroy()
with (Tablet_UI_Parent) instance_destroy()
alarm[1] = 2