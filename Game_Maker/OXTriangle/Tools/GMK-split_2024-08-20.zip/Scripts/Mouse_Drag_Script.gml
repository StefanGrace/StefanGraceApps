// Mouse_Drag_Script
// Stefan Grace
// Created: 2017-07-22
// Modified: 2020-03-01
// This script makes it so you can drag objects around with the mouse

/* arguments
argument0 = item to move
    1 = Message
    2 = Tablet UI
*/

if mouse_x > x and mouse_x < x+sprite_width and mouse_y > y and mouse_y < y+sprite_height
{
    mouse_clicked = 1
}

if mouse_button == mb_left and mouse_clicked == 1
{
    x = mouse_x - (sprite_width/2)
    y = mouse_y - (sprite_height/2)
}

if mouse_button != mb_left
{
    mouse_clicked = 0
}

// Make it so you can move the message with the IJKL keys insted of mouse
if (argument0 < 1)
{
    var key_speed joy_speed;
    key_speed = 3
    joy_speed = 10
    if (keyboard_check(ord("I"))) y -= key_speed
    if (keyboard_check(ord("J"))) x -= key_speed
    if (keyboard_check(ord("K"))) y += key_speed
    if (keyboard_check(ord("L"))) x += key_speed
    if (abs(joystick_zpos(0)) > 0.1) x += joystick_zpos(0) * joy_speed
    if (abs(joystick_rpos(0)) > 0.1) y += joystick_rpos(0) * joy_speed
}

x = round(x)
y = round(y)