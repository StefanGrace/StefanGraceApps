// Button_Text
// Stefan Grace
// Created: 2016-06-24
// Modifed: 2020-02-28
// This script draws the text on buttons and makes the text and buttons change color

/* 
argument0
    0 = Normal Button
    1 = Play Button
    2 = Character Button
    3 = Small Button
    4 = OSK Button
*/

var x_plus, y_plus;

draw_set_font(Button_Font)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)
y_plus = round(sprite_height / 2)
x_plus = round(sprite_width / 2)


if (mouse_x >= x and mouse_y > y and mouse_x < x + sprite_width and mouse_y < y + sprite_height) // if mouse in inside button
or (place_meeting(x, y, Hand))
{
    if (mouse_button || joystick_check_button(0, 2))  
    {  
        if (argument0==0) 
        {
            draw_sprite(Pressed_Button,0,x,y)
        }
        else if (argument0==1) 
        {
            draw_sprite(Play_Pressed,0,x,y)
            draw_set_font(Play_Button_Font)
        }
        else if (argument0==2) 
        {
            draw_sprite(Character_Pressed,0,x,y)
        }
        else if (argument0==3)
        {
            draw_set_font(Small_Button_Font)
            draw_sprite(Small_Pressed,0,x,y)
        }
        else if (argument0==4)
        {
            draw_set_font(Small_Button_Font)
            draw_sprite(OSK_Pressed,0,x,y)
        }
        draw_set_color(c_blue)
    }
    else
    {
        if (argument0==0) 
        {
            draw_sprite(Hot_Button,0,x,y)
        }
        else if (argument0==1) 
        {
            draw_sprite(Play_Hot,0,x,y)
            draw_set_font(Play_Button_Font)
        }
        else if (argument0==2) 
        {
            draw_sprite(Character_Hot,0,x,y)
        }
        else if (argument0==3)
        {
            draw_set_font(Small_Button_Font)
            draw_sprite(Small_Hot,0,x,y)
        }
        else if (argument0==4)
        {
            draw_set_font(Small_Button_Font)
            draw_sprite(OSK_Hot,0,x,y)
        }
        draw_set_color(c_blue)
    }
}
else
{
    if (argument0==0) 
    {
        draw_sprite(Normal_Button,0,x,y)
    }
    else if (argument0==1) 
    {
        draw_sprite(Play_Normal,0,x,y)
         draw_set_font(Play_Button_Font)
    }
    else if (argument0==2) 
    {
        draw_sprite(Character_Normal,0,x,y)
    }
    else if (argument0==3) 
    {
        draw_set_font(Small_Button_Font)
        draw_sprite(Small_Normal,0,x,y)
    }
    else if (argument0==4) 
    {
        draw_set_font(Small_Button_Font)
        draw_sprite(OSK_Normal,0,x,y)
    }
    draw_set_color(c_black)
    
}

draw_text(x + x_plus, y + y_plus, Button_Name)

draw_set_valign(0)
draw_set_halign(0)