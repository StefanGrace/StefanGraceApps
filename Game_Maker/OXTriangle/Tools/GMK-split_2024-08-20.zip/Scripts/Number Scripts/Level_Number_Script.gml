// Level_Number_Script
// Stefan Grace
// Created: 2016-07-02
// Modified: 2024-07-24
// This script draws the green level number in the bottom right corner

draw_set_halign(fa_center)
draw_set_valign(fa_middle)
draw_set_color(c_lime)
draw_set_font(Go_Number)

draw_sprite(Level_Number_Sprite, 0, x, y)
draw_text(x + (sprite_width / 2), y + (sprite_height / 2), global.levelnumber)

draw_set_halign(0)
draw_set_valign(0)