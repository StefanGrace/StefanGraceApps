// Anger_Number_Script
// Stefan Grace
// Created: I don't know
// Modified: 2016-07-18
// This script displays the number on an anger

/*
argument0 = Anger Color
    0 = Red
    1 = Orange
    2 = Blue
    3 = Purple
*/

// This block of code sets the font
draw_set_font(Go_Number)
draw_set_color(c_black)

// This block of code displays the correct color anger
if (argument0==0) draw_sprite(Red_Anger_Sprite,-1,x,y)
if (argument0==1) draw_sprite(Orange_Anger_Sprite,-1,x,y)
if (argument0==2) draw_sprite(Blue_Anger_Sprite,-1,x,y)
if (argument0==3) draw_sprite(Purple_Anger_Sprite,-1,x,y)

// This block of code displays the number in the correct place
if (((!(Number==1)) and (Number<10)) or (place_meeting(x,y,Anger_01))) draw_text(x+10,y+2,Number)
if (Number>=10) draw_text(x+3,y+2,Number)