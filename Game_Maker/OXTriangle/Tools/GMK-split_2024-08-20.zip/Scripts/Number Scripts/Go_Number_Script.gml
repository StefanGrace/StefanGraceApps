// Go_Number_Script
// Stefan Grace
// Created: I don't know
// Modified: 2024-07-24
// This script displays the go number

/*
argument0 = Player Number
    1 = Player 1
    2 = Player 2
*/

if (score < 100) 
{ 
    draw_set_font(Go_Number)
}
else
{
    draw_set_font(Go_Number_Small)
}


if (argument0 == 1)
{
    draw_sprite(Go_Number_Red_Sprite,0,x,y)
    draw_set_color(c_red)
}
else if (argument0 == 2)
{
    draw_sprite(Go_Number_Black_Sprite,0,x,y)
    draw_set_color(c_black)
}

draw_set_halign(fa_center)
draw_set_valign(fa_middle)
draw_text(x + (sprite_width / 2), y + (sprite_height / 2), score)
draw_set_halign(0)
draw_set_valign(0)