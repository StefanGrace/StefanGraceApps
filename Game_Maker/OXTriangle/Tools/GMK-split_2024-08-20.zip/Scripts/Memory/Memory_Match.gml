// Memory_Match
// Stefan Grace
// Created: 2017-09-22
// Modified: 2017-09-24

// Checks if both tiles that have been clciked are the same type, 
// then if so changes them into matched tiles, 
// if not changes them back to unfliped and changes the player turn
if (tile_type[tile_clicked_id]==tile_type[last_tile_clicked])
{
    tile_matched[tile_clicked_id] = 1
    tile_matched[last_tile_clicked] = 1
    player_matches[player_turn] += 1
    tile_clicked[tile_clicked_id] = 0
    tile_clicked[last_tile_clicked] = 0
}
else
{
    if(player_turn==1) 
    {    
        player_turn = 2
    }
    else 
    {
        player_turn = 1
    }
    flip_animation[tile_clicked_id] -= 0.2
    flip_animation[last_tile_clicked] -= 0.2
}
tile_clicked_sum = 0
alarm_0_set = 0