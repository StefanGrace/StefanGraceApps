if (player_turn==0) exit

if (key_stage < 2)
{
    selected_col = argument0
    key_stage = 2
}
else
{
    Memory_Click(1, selected_col, argument0)
    key_stage = 0
}