// Memory_Draw
// Stefan Grace
// Created: 2017-09-20
// Modified: 2024-07-25
// This script draws out the tiles and scores on the memory level

var i;
var j;

// Draws out the tiles
for (i = 0; i<10; i += 1)
{
    for (j = 0; j<10; j += 1)
    {
        if (tile_matched[i+(j*10)]>0) // If the tile has been matched
        {
            draw_sprite(Yellow_Sprite,0,(i+14)*grid_size,(j+6)*grid_size) 
        }
        if (tile_matched[i+(j*10)]==0 and tile_clicked[i+(j*10)]==0) // If the tile has not been matched or clicked
        {
            draw_sprite_ext(Rock_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1)
        }
        if (tile_clicked[i+(j*10)]>0) // If the tile has been clciked but not matched
        {
            draw_sprite_ext(Yellow_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) 
            /* G               */ if (tile_type[i+(j*10)]==0) draw_sprite_ext(G_R_3hit,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // G
            /* Red Anger       */ if (tile_type[i+(j*10)]==1) draw_sprite_ext(Red_Anger_Sprite,animation mod 90,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Red Anger
            /* Tunnling Bomb   */ if (tile_type[i+(j*10)]==2) draw_sprite_ext(Tunnling_Bomb_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Tunnling Bomb
            /* Arrow           */ if (tile_type[i+(j*10)]==3) draw_sprite_ext(Right_Arrow_Sprite,animation mod 30,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Arrow
            /* Dimond          */ if (tile_type[i+(j*10)]==4) draw_sprite_ext(Dimond_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Dimond
            /* Go Number Black */ if (tile_type[i+(j*10)]==5) draw_sprite_ext(Go_Number_Black_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Go Number Black
            /* Alumax          */ if (tile_type[i+(j*10)]==6) draw_sprite_ext(Alumax_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Alumax
            /* R Arrow         */ if (tile_type[i+(j*10)]==7) draw_sprite_ext(R_Arrow_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17))+17,((j+6)*grid_size)+17,flip_animation[i+(j*10)],1,180,c_white,1) // R Arrow
            /* Boulder         */ if (tile_type[i+(j*10)]==8) draw_sprite_ext(Boulder_Sprite,0,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Boulder
            /* Teleport        */ if (tile_type[i+(j*10)]==9) draw_sprite_ext(Teleport_Dark_Blue,animation mod 20,((i+14)*grid_size)+(17-(flip_animation[i+(j*10)]*17)),(j+6)*grid_size,flip_animation[i+(j*10)],1,0,c_white,1) // Teleport
            if (tile_type[i+(j*10)]==1 or tile_type[i+(j*10)]==5) // If the tile has a number on it
            {
                draw_set_halign(fa_center)
                draw_set_valign(fa_center)
                draw_set_font(Go_Number)
                draw_set_color(c_black)
                draw_text(((i+14)*grid_size)+17,((j+6)*grid_size)+17,tile_type[i+(j*10)])
                draw_set_halign(0)
                draw_set_valign(0)                
            }
        }
    }
}
animation += 1

// Draws out the scores
if (instance_number(Player_Select)==0)
{
    draw_sprite(Player_Select_Sprite,0,455,0)
    draw_sprite(Connect_4_P1_Sprite,0,350,0)
    draw_sprite(Connect_4_P2_Sprite,0,805,0)
    draw_set_font(Player_Select_Font)
    draw_set_color(c_black)
    draw_set_halign(fa_center)
    draw_set_valign(fa_middle)
    draw_text(room_width/2,17,global.text_matches)
    draw_set_font(Go_Number)
    draw_set_color(c_red)
    draw_text(350+106,17,global.Player_One+": "+string(player_matches[1]))
    draw_set_font(Go_Number)
    draw_set_color(c_black)
    draw_text(805+106,17,global.Player_Two+": "+string(player_matches[2]))
    draw_set_halign(0)
    draw_set_halign(0)
}

// Draws out the keyboard numbers
if (key_stage > 0)
{
    if (player_turn == 1)
    {
        draw_set_color(c_red)
    }
    else
    {
        draw_set_color(c_black)
    }
    draw_set_font(Go_Number)
    draw_set_halign(fa_center)
    draw_set_valign(fa_middle)
    var i;
    var num;
    if (key_stage == 1)
    {
        for (i = 0; i < 10; i += 1)
        {
            if (player_turn == 1) 
            {
                draw_sprite(Go_Number_Red_Sprite, 0, (i+14)*grid_size, 5*grid_size)
            } 
            else 
            {
                draw_sprite(Go_Number_Black_Sprite, 0, (i+14)*grid_size, 5*grid_size)
            }
            if (i < 9) {num = i + 1;} else {num = 0;} 
            draw_text(((i+14)*grid_size)+17, (5*grid_size)+17, string(num))
        }
    }
    else 
    {
        var selected_col_num;
        if (selected_col > 0) {selected_col_num = selected_col - 1;} else {selected_col_num = 9} 
        if (player_turn == 1) 
        {
            draw_sprite(Go_Number_Red_Sprite, 0, (selected_col_num+14)*grid_size, 5*grid_size)
        } 
        else 
        {
            draw_sprite(Go_Number_Black_Sprite, 0, (selected_col_num+14)*grid_size, 5*grid_size)
        }

        for (i = 0; i < 10; i += 1)
        {
            if (player_turn == 1) 
            {
                draw_sprite(Go_Number_Red_Sprite, 0, 13*grid_size, (i+6)*grid_size)
            } 
            else 
            {
                draw_sprite(Go_Number_Black_Sprite, 0, 13*grid_size, (i+6)*grid_size)
            }
            if (i < 9) {num = i + 1;} else {num = 0} 
            draw_text((13*grid_size)+17, ((i+6)*grid_size)+17, string(num))
        }
    }
    draw_set_halign(0)
    draw_set_valign(0)
}
