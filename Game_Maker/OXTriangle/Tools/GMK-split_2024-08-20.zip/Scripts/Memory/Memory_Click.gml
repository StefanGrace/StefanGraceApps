// Memory_Click
// Stefan Grace
// Created: 2017-09-20
// Modified: 2023-01-14
// This script draws turns over the tiles where they are clicked

// Stops the user from clicking a tile before the game has started
if (player_turn==0) exit


if (argument0 == 0) // If the script has been initiated with the mouse
{
    // Stops the user from clicking outside of the memory tiles
    if (mouse_x<14*grid_size)
    or (mouse_x>24*grid_size)
    or (mouse_y<6*grid_size)
    or (mouse_y>16*grid_size)
    {
        exit
    }

    // Stops the user from clicking a tile when 2 tiles have already been clicked
    if (tile_clicked_sum>=1) exit
    var a;
    var b;
    var c;
    var i;

    // Converts mouse_x to horizonal tile index
    a = mouse_x - (mouse_x mod grid_size)
    a /= grid_size
    a -= 14

    // Converts mouse_y to vertical tile index
    b = mouse_y - (mouse_y mod grid_size)
    b /= grid_size
    b -= 6
}
else // If the script has been initiated with the keyboard
{
    if (argument1 == 0) {a = 9;} else {a = argument1 - 1;}
    if (argument2 == 0) {b = 9;} else {b = argument2 - 1;}
}

// Converts the horizonal and vertical tile indexes into a tile id
c = a+(b*10)

// Stops the user from clicking a tile that is alreay matched
if (tile_matched[c]>0) exit

// Stops the user from clicking a tile that is alreay clicked
if (tile_clicked[c]>0) exit

// Makes the message come up when the user clicks a tile for the first time
if (!message_has_shown)
{
    level24messagenumber = 1
    message_has_shown = true
    if (instance_number(Message_Object) == 0) 
    {
        global.message_type = 41
        instance_create(945, 315, Message_Object)
    }
}

// Sets last_tile_clicked to the id of the tile that was last clciked
for(i = 0; i<100; i += 1)
{
    if (tile_clicked[i]>0) last_tile_clicked = i
}

// Starts the tile flip animation when the tile has been clicked
flip_animation[c] -= 0.2

// Sets tile_clicked_id to c
tile_clicked_id = c

// Counts how many tiles have been clicked
for(i = 0; i<100; i += 1)
{   
    tile_clicked_sum += tile_clicked[i]
}


        