// Memory_Script
// Stefan Grace
// Created: 2017-09-22
// Modified: 2017-09-24
// This script is executed every step on the Memory level (Level 24)

var i;
var tile_matched_sum;

// Changes the go number into the player's turn
if (instance_number(Go_Number_Red)>0) 
{
    with(Go_Number_Red) instance_change(Connect_4_P1_Turn,false)
    player_turn = 1
}
if (instance_number(Go_Number_Black)>0) 
{
    with(Go_Number_Black) instance_change(Connect_4_P2_Turn,false)
    player_turn = 2
}

// Gets rid of the Draw Mode button
if (instance_number(Draw_Mode_Red)>0) with(Draw_Mode_Red) instance_destroy()
if (instance_number(Draw_Mode_Black)>0) with(Draw_Mode_Black) instance_destroy()

// Changes the Player's turn
if (player_turn==1) with(Connect_4_P2_Turn) instance_change(Connect_4_P1_Turn,false)
if (player_turn==2) with(Connect_4_P1_Turn) instance_change(Connect_4_P2_Turn,false)

// Makes the player that has the heighest matches win when all tiles have been matched
for (i = 0; i<100; i += 1)
{
    tile_matched_sum += tile_matched[i]
}
if (tile_matched_sum>=100)
{
    if (player_matches[1]>player_matches[2]) and (instance_number(Player_One_Winz)==0) instance_create(0,0,Player_One_Winz)
    if (player_matches[1]<player_matches[2]) and (instance_number(Player_Two_Winz)==0) instance_create(0,0,Player_Two_Winz)
    if (player_matches[1]==player_matches[2]) 
    {
        for (i = 0; i<100; i += 1)
        {
            tile_matched[i] = 0
            tile_clicked[i] = 0
        }
        script_execute(Memory_Start)
    }
}

// If 2 tiles have been clicked wait 1 second, then if they are both the same type change them into matched 
if (tile_clicked_sum>=1 and alarm_0_set==0) 
{
    alarm[0] = 30
    alarm_0_set = 1
    with(Message_Object) instance_destroy()
}

// Controls the flip animation
for(i = 0; i<100; i += 1)
{   
    if (flip_animation[i]<1)
    {
        if (flip_has_hit_0[i]==0)
        {
            if(flip_animation[i]>0.2) 
            {
                flip_animation[i] -= 0.2 
            }
            else 
            {
                flip_has_hit_0[i] = 1
                if (tile_clicked[i]==0) tile_clicked[i] = 1 else tile_clicked[i] = 0
            }
        }
        else
        {
            flip_animation[i] += 0.2 
        }
    }
    else
    {
        flip_has_hit_0[i] = 0
    }
}
