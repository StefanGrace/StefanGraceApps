// Memory_Start
// Stefan Grace
// Created: 2017-09-20
// Modified: 2017-09-24
// This script is executed at the start of the Memory level (Level 24)

var i;
var j;
var k;
var tile_id;
var tile_id_sum;
var tiles;

// Sets up the message variables
global.message_type = 41
level24messagenumber = 0

// Makes an order array of the numbers 0 to 99
for(i = 0; i<100; i += 1)
{
    tile_id[i] = i
}

// Makes a shuffeld array of the numbers 0 to 99
while (tile_id_sum!=-100)
{
    tile_id_sum = 0
    j = random(100)
    j = j-(j mod 1)
    if (tile_id[j]>=0) 
    {
        tiles[k] = tile_id[j]
        tile_id[j] = -1
        k += 1
    } 
    for(i = 0; i<100; i += 1)
    {   
        tile_id_sum += tile_id[i]
    }
}

// Makes an array of 100 tiles (10 of each type)
for(i = 0; i<100; i += 1)
{
    tile_type[i] = tiles[i] mod 10   
}

// Sets the flip animation to 1 for each tile
for(i = 0; i<100; i+= 1)
{
    flip_animation[i] = 1
}