// Question_Mark_Change
// Stefan Grace
// Created: 2017-12-24
// Modified: 2020-02-14

/*
arguments
    argument0 - Character ID    
*/


with(Character)
{
    if (character_id==26 or purple>0)
    {
        if (state==3)
        {
            if (character_id==31) with(Concreet) if(place_meeting(x,y,other)) {instance_destroy(); instance_create(x,y,Yellow)} // to get rid of the concreet if a puple pi turns into somthing else
            character_id = argument0
            if (player==1)
            {
                if (argument0==0) instance_change(Red_Blue_O,false)
                if (argument0==1) instance_change(Red_Blue_X,false)
                if (argument0==2) instance_change(Red_Blue_Triangle,false)
                if (argument0==3) instance_change(Red_Blue_A,false)
                if (argument0==4) instance_change(Red_Blue_Square,false)
                if (argument0==5) instance_change(Red_Blue_K,false)
                if (argument0==6) instance_change(Red_Blue_B,false)
                if (argument0==7) instance_change(Red_Blue_E,false)
                if (argument0==8) instance_change(Red_Blue_S,false)
                if (argument0==9) instance_change(Red_Blue_H,false)
                if (argument0==10) instance_change(Red_Blue_R,false)
                if (argument0==11) instance_change(Red_Blue_M,false)
                if (argument0==12) instance_change(Red_Blue_F,false)
                if (argument0==13) {g_hit = 4; g_type = 0; move_snap(grid_size,grid_size); instance_change(Red_Blue_G,false); instance_create(x,y,Explosion)}
                if (argument0==14) instance_change(Red_Blue_C,false)
                if (argument0==15) instance_change(Red_Blue_Y,false)
                if (argument0==16) instance_change(Red_Blue_Z,false)
                if (argument0==17) instance_change(Red_Blue_W,false)
                if (argument0==18) instance_change(Red_Blue_J,false)
                if (argument0==19) instance_change(Red_Blue_V,false)
                if (argument0==20) instance_change(Red_Blue_P,false)
                if (argument0==21) instance_change(Red_Blue_T,false)
                if (argument0==22) instance_change(Red_Blue_D,false)
                if (argument0==23) instance_change(Red_Blue_Q,false)
                if (argument0==24) instance_change(Red_Blue_N,false)
                if (argument0==26) instance_change(Red_Blue_Question_Mark,false)
                if (argument0==27) instance_change(Red_Blue_U,false)
                if (argument0==28) instance_change(Red_Blue_L,false)
                if (argument0==29) instance_change(Red_Blue_Dollar_Sign,false)
                if (argument0==30) instance_change(Red_Blue_At,false)
                if (argument0==31) {instance_change(Red_Blue_Pi,false); script_execute(Purple_Pi_Create)}
                if (argument0==32) instance_change(Red_Blue_I,false)
                if (argument0==33) {g_hit = 1; g_type = 3; character_id = 13; instance_change(Red_Blue_G,false); move_snap(grid_size,grid_size)}
            }
            else if (player==2)
            {
                if (argument0==0) instance_change(Black_Blue_O,false)
                if (argument0==1) instance_change(Black_Blue_X,false)
                if (argument0==2) instance_change(Black_Blue_Triangle,false)
                if (argument0==3) instance_change(Black_Blue_A,false)
                if (argument0==4) instance_change(Black_Blue_Square,false)
                if (argument0==5) instance_change(Black_Blue_K,false)
                if (argument0==6) instance_change(Black_Blue_B,false)
                if (argument0==7) instance_change(Black_Blue_E,false)
                if (argument0==8) instance_change(Black_Blue_S,false)
                if (argument0==9) instance_change(Black_Blue_H,false)
                if (argument0==10) instance_change(Black_Blue_R,false)
                if (argument0==11) instance_change(Black_Blue_M,false)
                if (argument0==12) instance_change(Black_Blue_F,false)
                if (argument0==13) {g_hit = 4; g_type = 0; move_snap(grid_size,grid_size); instance_change(Black_Blue_G,false); instance_create(x,y,Explosion)}
                if (argument0==14) instance_change(Black_Blue_C,false)
                if (argument0==15) instance_change(Black_Blue_Y,false)
                if (argument0==16) instance_change(Black_Blue_Z,false)
                if (argument0==17) instance_change(Black_Blue_W,false)
                if (argument0==18) instance_change(Black_Blue_J,false)
                if (argument0==19) instance_change(Black_Blue_V,false)
                if (argument0==20) instance_change(Black_Blue_P,false)
                if (argument0==21) instance_change(Black_Blue_T,false)
                if (argument0==22) instance_change(Black_Blue_D,false)
                if (argument0==23) instance_change(Black_Blue_Q,false)
                if (argument0==24) instance_change(Black_Blue_N,false)
                if (argument0==26) instance_change(Black_Blue_Question_Mark,false)
                if (argument0==27) instance_change(Black_Blue_U,false)
                if (argument0==28) instance_change(Black_Blue_L,false)
                if (argument0==29) instance_change(Black_Blue_Dollar_Sign,false)
                if (argument0==30) instance_change(Black_Blue_At,false)
                if (argument0==31) {instance_change(Black_Blue_Pi,false); script_execute(Purple_Pi_Create)}
                if (argument0==32) instance_change(Black_Blue_I,false)
                if (argument0==33) {g_hit = 1; g_type = 3; character_id = 13; instance_change(Black_Blue_G,false); move_snap(grid_size,grid_size)}
            }
            score -= 1
            script_execute(Question_Mark_Display_Remove)
            with(Cancel) instance_destroy()
        }
    }
}
