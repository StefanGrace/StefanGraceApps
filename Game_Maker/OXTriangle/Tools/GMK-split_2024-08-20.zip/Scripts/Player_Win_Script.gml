// Player_Win_Script
// Stefan Grace
// Created: 2016-07-18
// Modified: 2016-08-07
// This scirpt checks if either player has any 'O's left

if ((instance_number(Player_One_Winz)==0) and (instance_number(Black_Stuned_O)==0) and (instance_number(Black_O)==0) and (instance_number(Black_Blue_O)==0)) instance_create(0,0,Player_One_Winz)
if ((instance_number(Player_Two_Winz)==0) and (instance_number(Red_Stuned_O)==0) and (instance_number(Red_O)==0) and (instance_number(Red_Blue_O)==0)) instance_create(0,0,Player_Two_Winz)


/* UNUSED LINES OF CODE
// This scirpt checks if either player has any survival characters left
and (instance_number(Black_Stuned_Square)==0) and (instance_number(Black_Square)==0) and (instance_number(Black_Blue_Square)==0) and (instance_number(Black_Stuned_Triangle)==0) and (instance_number(Black_Triangle)==0) and (instance_number(Black_Blue_Triangle)==0) and (instance_number(Black_Stuned_E)==0) and (instance_number(Black_E)==0) and (instance_number(Black_Blue_E)==0) and (instance_number(Black_Stuned_R)==0) and (instance_number(Black_R)==0) and (instance_number(Black_Blue_R)==0)
and (instance_number(Red_Stuned_Square)==0) and (instance_number(Red_Square)==0) and (instance_number(Red_Blue_Square)==0) and (instance_number(Red_Stuned_Triangle)==0) and (instance_number(Red_Triangle)==0) and (instance_number(Red_Blue_Triangle)==0) and (instance_number(Red_Stuned_E)==0) and (instance_number(Red_E)==0) and (instance_number(Red_Blue_E)==0) and (instance_number(Red_Stuned_R)==0) and (instance_number(Red_R)==0) and (instance_number(Red_Blue_R)==0)
*/