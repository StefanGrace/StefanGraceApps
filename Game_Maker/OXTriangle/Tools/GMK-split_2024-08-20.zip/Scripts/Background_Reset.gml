// Background_Reset
// Stefan Grace
// Created: 2016-07-18
// Modified: 2017-07-20
// This scrip resets the background when the player's turn is up

if (global.levelnumber<10) background_index[0] = Nature_Background
if (global.levelnumber>9) and (global.levelnumber<20) background_index[0] = Underwater_Background
if (global.levelnumber>19) and (global.levelnumber<30) background_index[0] = Bush_Background