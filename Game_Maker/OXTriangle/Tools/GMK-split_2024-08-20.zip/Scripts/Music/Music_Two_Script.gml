OXTriangle_Music = sound_add("Music/Mellowtron.mp3",3,false)
Last_Music = 2