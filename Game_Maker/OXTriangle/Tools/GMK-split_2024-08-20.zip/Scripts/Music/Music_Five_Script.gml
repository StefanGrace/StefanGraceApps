OXTriangle_Music = sound_add("Music/Walk_Home_Solar.mp3",3,false)
Last_Music = 5