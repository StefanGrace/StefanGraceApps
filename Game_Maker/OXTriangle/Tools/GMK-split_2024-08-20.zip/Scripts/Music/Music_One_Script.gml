OXTriangle_Music = sound_add("Music/Bit_Quest.mp3",3,false)
Last_Music = 1