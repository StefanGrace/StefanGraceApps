// Music_Script
// Stefan Grace
// Created: 2016-07-03
// Modified: 2016-07-03
// This script plays the music

if ((global.Music_Playing==1) and (!(sound_isplaying(OXTriangle_Music))))
{
    if (Last_Music==0)
    {
        random_number = random(5)
        if (random_number<1) script_execute(Music_One_Script)
        else if (random_number<2) script_execute(Music_Two_Script)
        else if (random_number<3) script_execute(Music_Three_Script)
        else if (random_number<4) script_execute(Music_Four_Script)
        else script_execute(Music_Five_Script)
    }
    else if (Last_Music==1) 
    {
        random_number = random(4)
        if (random_number<1) script_execute(Music_Two_Script)
        else if (random_number<2) script_execute(Music_Three_Script)
        else if (random_number<3) script_execute(Music_Four_Script)
        else script_execute(Music_Five_Script)
    }
    else if (Last_Music==2)
    {
        random_number = random(4)
        if (random_number<1) script_execute(Music_One_Script)
        else if (random_number<2) script_execute(Music_Three_Script)
        else if (random_number<3) script_execute(Music_Four_Script)
        else script_execute(Music_Five_Script)
    }
    else if (Last_Music==3)
    {
        random_number = random(4)
        if (random_number<1) script_execute(Music_One_Script)
        else if (random_number<2) script_execute(Music_Two_Script)
        else if (random_number<3) script_execute(Music_Four_Script)
        else script_execute(Music_Five_Script)
    }
    else if (Last_Music==4)
    {
        random_number = random(4)
        if (random_number<1) script_execute(Music_One_Script)
        else if (random_number<2) script_execute(Music_Two_Script)
        else if (random_number<3) script_execute(Music_Three_Script)
        else script_execute(Music_Five_Script)
    }
    else if (Last_Music==5)
    {
        random_number = random(4)
        if (random_number<1) script_execute(Music_One_Script)
        else if (random_number<2) script_execute(Music_Two_Script)
        else if (random_number<3) script_execute(Music_Three_Script)
        else script_execute(Music_Four_Script)
    }   
    sound_play(OXTriangle_Music)
}