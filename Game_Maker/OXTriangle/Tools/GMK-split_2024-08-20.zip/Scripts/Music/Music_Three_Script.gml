OXTriangle_Music = sound_add("Music/Move_Forward.mp3",3,false)
Last_Music = 3