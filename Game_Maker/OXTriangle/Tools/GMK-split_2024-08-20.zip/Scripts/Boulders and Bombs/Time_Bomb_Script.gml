// Time_Bomb_Script
// Stefan Grace
// Created: 2017-09-03
// Modified: 2018-11-08
// This script controls Time Bombs

if (time_bomb==0) exit

// Makes the countdown decrease by 1 each turn if the time bomb has been set
if (set==0) exit
if (score==0)
{
    score_has_gone_above_0 = 0
    {
        if (score_has_reached_0==0)
        {
            countdown -= 1
            score_has_reached_0 = 2
        }
    }
}
if (score>0 and score_has_gone_above_0==0 and score_has_reached_0>0) 
{
    score_has_gone_above_0 = 1
    score_has_reached_0 -= 1
}

// Makes the bomb explode when the countdown would reach -1
if (countdown<0)
{
    instance_create(x+17,y+17,Explosion_M_Object)
    if (!(sound_isplaying(M_Sound))) sound_play(M_Sound)
    instance_create(x,y,Time_Bomb_Explosion_Center)
    instance_destroy()
}
