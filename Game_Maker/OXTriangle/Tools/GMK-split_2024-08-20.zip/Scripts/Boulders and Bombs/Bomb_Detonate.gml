// Bomb_Detonate
// Stefan Grace
// Created: 2017-10-14
// Modified: 2017-10-14
// This script make a Nuclear Bomb or J Bomb Detonate if it is not in a Teleport or if it gets stuck in a Teleport

if (nuclear==1) and (falling>0) 
{
    if (place_meeting(x,y,Teleport)) 
    {
        alarm[0] = 15
        teleport_y = y
    }
    else 
    {
        script_execute(M_Detonate)
    }
}
if (j_bomb==1) and (falling>0) 
{
    if (place_meeting(x,y,Teleport)) 
    {
        alarm[1] = 15
        teleport_y = y
    }
    else 
    {
        script_execute(J_Detonate)
    }
}
