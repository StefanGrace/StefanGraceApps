// Time_Bomb_Set
// Stefan Grace
// Created: 2017-10-01
// Modified: 2017-10-01
// This script is executed when the time bomb gets clicked on

// Makes a character set the bomb
if (time_bomb>0 and set==0)
{
    with(all)
    {
        if (player==1 and instance_number(Go_Number_Red)>0)
        or (player==2 and instance_number(Go_Number_Black)>0)
        {
            if place_meeting(x+grid_size,y,other)
            or place_meeting(x-grid_size,y,other) 
            or place_meeting(x,y+grid_size,other)
            or place_meeting(x,y-grid_size,other)
            {
                with(other) set = 1
                score -= 1
            } 
        }
    }
}

