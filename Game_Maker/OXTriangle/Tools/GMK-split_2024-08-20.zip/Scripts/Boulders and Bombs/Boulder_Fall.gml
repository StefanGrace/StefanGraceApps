// Boulder_Fall
// Stefan Grace
// Created: 2017-07-31
// Modified: 2024-07-29
// This script make bouders and bombs fall and get pushed

// Mud
if (place_meeting(x,y,Mud))
{
    bomb_fall = 0
    global.game_frozen = 0 
    falling = 0
    fall_step = 0
    catapulted = 0
    exit
}

// Push
repeat(36)
{
    // Black Blue
    if (place_meeting(x,y,Black_Blue) and !place_meeting(x,y,Black_Blue_Y))
    // Red Blue
    or (place_meeting(x,y,Red_Blue) and !place_meeting(x,y,Red_Blue_Y)) 
    // Boulder
    or place_meeting(x,y,Boulder)
    {
        if (left_pressed) {x -= grid_size;}
        if (right_pressed) {x += grid_size;}
    }
}

// Stops the bomb/ boulder falling when there is an object in the way
if place_meeting(x,y+grid_size,Boulder)
or place_meeting(x,y+grid_size,Double_Boxing)
or place_meeting(x,y+grid_size,Up_Arrow)
or place_meeting(x,y+grid_size,Vertical_Arrow)
or place_meeting(x,y,Left_Arrow)
or place_meeting(x,y,Right_Arrow)
or place_meeting(x,y,Horizontal_Arrow)
or place_meeting(x,y,Up_Arrow)
or place_meeting(x,y+grid_size,Barria_Horizontal)
or place_meeting(x,y+grid_size,Black_Blue_Y)
or place_meeting(x,y+grid_size,Red_Blue_Y)
or place_meeting(x,y+grid_size,Black_Y)
or place_meeting(x,y+grid_size,Red_Y)
or place_meeting(x,y+grid_size,Black_Stuned_Y)
or place_meeting(x,y+grid_size,Red_Stuned_Y)
or place_meeting(x,y+grid_size,Green_Y)
{
    script_execute(Bomb_Detonate)
    bomb_fall = 0
    global.game_frozen = 0 
    falling = 0
    fall_step = 0
    catapulted = 0
    exit
}

// Stops the bomb/ boulder falling when there is a G in the way and takes 1 hit off the G
if place_meeting(x,y+grid_size,Red_Stuned_G)
or place_meeting(x,y+grid_size,Red_G)
or place_meeting(x,y+grid_size,Black_Stuned_G)
or place_meeting(x,y+grid_size,Black_G)
or place_meeting(x,y+grid_size,Red_Blue_G)
or place_meeting(x,y+grid_size,Black_Blue_G)
or place_meeting(x,y+grid_size,Green_G)

{
    if (falling>0) 
    {
        with (Red_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
        with (Black_Stuned_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
        with (Black_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
        with (Red_Blue_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
        with (Black_Blue_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
        with (Green_G) if (place_meeting(x,y-grid_size,other) and place_meeting(x,y,Yellow)) g_hit -= 1
    }
    script_execute(Bomb_Detonate)
    bomb_fall = 0
    global.game_frozen = 0 
    falling = 0
    fall_step = 0
    catapulted = 0
    exit
}

// Fall
if (!place_meeting(x,y+grid_size,Character) or falling>0 or catapulted>0)
{
    if (place_meeting(x,y+grid_size,Yellow) or (bomb_fall>0 and ((place_meeting(x,y+grid_size,Rock) and rock_tunnle>0) or (place_meeting(x,y+grid_size,Dimond) and dimond_tunnle>0) or (place_meeting(x,y+grid_size,Concreet) and concreet_tunnle>0))))
    {
        if (fall_step==0) 
        {        
            global.game_frozen = 1
            falling = 1
            if (!(sound_isplaying(Boulder_Sound) or global.boulder_sound_playing)) 
            {
                sound_play(Boulder_Sound) 
                global.boulder_sound_playing = true
                alarm[2] = 60
            }
            if (place_meeting(x,y+grid_size,Yellow)) bomb_fall += 1 else bomb_fall -= 1
            y += grid_size
        }
        fall_step += 1
        if (fall_step==3) fall_step = 0
    }
    else
    {
        script_execute(Bomb_Detonate)
        global.game_frozen = 0 
        falling = 0
        catapulted = 0
    }
}