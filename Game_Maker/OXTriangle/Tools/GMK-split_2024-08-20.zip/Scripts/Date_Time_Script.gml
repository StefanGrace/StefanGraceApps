//Date & Time
//Stefan Grace
//Created 2016-05-16
//Modifed 2016-07-30
//This Scrip assembles the currect date and time


//This block of code makes the elements have leading zeros if they are less than ten
if (current_month<10) global.current_month_leading_zero=string("0")+string(current_month) else global.current_month_leading_zero = current_month
if (current_day<10) global.current_day_leading_zero=string("0")+string(current_day) else global.current_day_leading_zero = current_day 
if (current_hour<10) global.current_hour_leading_zero=string("0")+string(current_hour) else global.current_hour_leading_zero = current_hour 
if (current_minute<10) global.current_minute_leading_zero=string("0")+string(current_minute) else global.current_minute_leading_zero = current_minute
if (current_second<10) global.current_second_leading_zero=string("0")+string(current_second) else global.current_second_leading_zero = current_second 

//This block of code makes the year be 2 digit if the setting is enabeld
if (global.Year_Format==0) global.current_year_digits=current_year else global.current_year_digits=(current_year mod 100)
if (global.current_year_digits<10) global.current_year_digits = string(global.current_year_digits)+string("0")

//This block of code makes the months be displays as words insted of numbers if the option is enabled
if (global.Month_Format==1) global.current_month_leading_zero = global.Months[current_month]

//This block of code makes the time be 12 hour is the setting is enabeld
if (global.Time_Format==1)
{
    if (current_hour<12) global.AmPm="AM" else global.AmPm="PM"
    if (current_hour==0) global.current_hour_twelve=12
    if (current_hour>0 and current_hour<12) global.current_hour_twelve=current_hour
    if (current_hour>12) global.current_hour_twelve=current_hour-12
}

//This block of code assembels the elements of the date and time
if (global.Date_Order==0) global.date_text = string(global.current_year_digits)+"-"+string(global.current_month_leading_zero)+"-"+string(global.current_day_leading_zero)
if (global.Date_Order==1) global.date_text = string(global.current_month_leading_zero)+"/"+string(global.current_day_leading_zero)+"/"+string(global.current_year_digits)
if (global.Date_Order==2) global.date_text = string(global.current_day_leading_zero)+"/"+string(global.current_month_leading_zero)+"/"+string(global.current_year_digits)
if (global.Time_Format==0) global.time_text = string(global.current_hour_leading_zero)+":"+string(global.current_minute_leading_zero)+":"+string(global.current_second_leading_zero)
if (global.Time_Format==1) global.time_text = string(global.current_hour_twelve)+":"+string(global.current_minute_leading_zero)+string(" ")+string(global.AmPm)
if (global.Date_Time_Order==0) global.date_time_text = string(global.date_text)+string(" ")+string(global.time_text)
if (global.Date_Time_Order==1) global.date_time_text = string(global.time_text)+string(" ")+string(global.date_text)
