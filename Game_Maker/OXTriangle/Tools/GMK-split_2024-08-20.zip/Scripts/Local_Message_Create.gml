// Local_Message_Create
// Stefan Grace
// Craeted: 2017-07-22
// Modified: 2017-07-22
// This script creates the B and Double Boxing messages in the correct place

/* Top Left     */ if (x<room_width/2) and (y<room_height/2) instance_create(x+grid_size,y,Message_Object)
/* Top Right    */ if (x>=room_width/2) and (y<room_height/2) instance_create(x-(sprite_get_width(Message_Sprite)+grid_size),y,Message_Object)
/* Bottom Left  */ if (x<room_width/2) and (y>=room_height/2) instance_create(x+grid_size,y-sprite_get_height(Message_Sprite),Message_Object) 
/* Bottom Right */ if (x>=room_width/2) and (y>=room_height/2) instance_create(x-(sprite_get_width(Message_Sprite)+grid_size),y-sprite_get_height(Message_Sprite),Message_Object)