// Background_Script
// Stefan Grace
// Created: 2017-12-23
// Modified: 2024-07-22
// This script sets the background for the level

/* arguments
    argument0
        0 - Level start
        1 - Player change
*/

if (global.show_backgrounds) 
{
    var bg_image;
    if (global.levelnumber < 10)
    {
        bg_image = "Backgrounds\0_Waterfall.jpg"
    }
    else if (global.levelnumber < 20)
    {
        bg_image = "Backgrounds\1_Mountain.jpg"
    }
    else if (global.levelnumber < 30)
    {
        bg_image = "Backgrounds\2_Bush.jpg"
    }
    
    if (file_exists(bg_image))
    {
        background_replace(Background, bg_image, 1, 0, 0)
        sprite_replace(Background_Sprite, bg_image, 0, 0, 1, 0, 0, 0, 0)
        background_index[0] = Background
        if (argument0==0) instance_create(0, 0, Background_Object)
    }
    else 
    {
        background_index[0] = -1
        background_color = $000000
        instance_create(0, 0, Wood_Object)
    }
}
else
{
    background_index[0] = -1
    background_color = $000000
    instance_create(0, 0, Wood_Object)
}




