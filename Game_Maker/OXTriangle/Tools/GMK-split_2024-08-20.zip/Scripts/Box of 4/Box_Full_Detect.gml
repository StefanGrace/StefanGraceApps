if (repeat_num==0) boxfull_topleft = 1
if (repeat_num==1) boxfull_topright = 1
if (repeat_num==2) boxfull_bottomleft = 1
if (repeat_num==3) boxfull_bottomright = 1