// Box_Four_Detect
// Stefan Grace
// Created: 2016-07-07
// Modified: 2016-07-22
// This script detects if the box a character is moving into is full

/*
argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
    
grid_align
    0 = Top Left
    1 = Top Right
    2 = Bottom Left
    3 = Bottom Right
*/

// This block of code detects where the character is in the box
if (place_snapped(35,35)) grid_align = 0 
else if ((x mod 35) > 10) and ((y mod 35) < 10) grid_align = 1
else if ((x mod 35) < 10) and ((y mod 35) > 10) grid_align = 2
else grid_align = 3

// This block of code detects if the box a character is moving into is full
repeat_num = 0
while (repeat_num<4)
{
    // grid_align==0, argument0==0
    if (repeat_num==0) and (grid_align==0) and (argument0==0) script_execute(Place_Meeting_Detect,-35,0)
    if (repeat_num==1) and (grid_align==0) and (argument0==0) script_execute(Place_Meeting_Detect,-17,0)
    if (repeat_num==2) and (grid_align==0) and (argument0==0) script_execute(Place_Meeting_Detect,-35,17)
    if (repeat_num==3) and (grid_align==0) and (argument0==0) script_execute(Place_Meeting_Detect,-17,17)
    // grid_align==1
    if (repeat_num==0) and (grid_align==1) and (argument0==0) script_execute(Place_Meeting_Detect,-52,0)
    if (repeat_num==1) and (grid_align==1) and (argument0==0) script_execute(Place_Meeting_Detect,-35,0)
    if (repeat_num==2) and (grid_align==1) and (argument0==0) script_execute(Place_Meeting_Detect,-52,17)
    if (repeat_num==3) and (grid_align==1) and (argument0==0) script_execute(Place_Meeting_Detect,-35,17)
    // grid_align==2
    if (repeat_num==0) and (grid_align==2) and (argument0==0) script_execute(Place_Meeting_Detect,-35,-17)
    if (repeat_num==1) and (grid_align==2) and (argument0==0) script_execute(Place_Meeting_Detect,-17,-17)
    if (repeat_num==2) and (grid_align==2) and (argument0==0) script_execute(Place_Meeting_Detect,-35,0)
    if (repeat_num==3) and (grid_align==2) and (argument0==0) script_execute(Place_Meeting_Detect,-17,0)
    // grid_align==3
    if (repeat_num==0) and (grid_align==3) and (argument0==0) script_execute(Place_Meeting_Detect,-52,-17)
    if (repeat_num==1) and (grid_align==3) and (argument0==0) script_execute(Place_Meeting_Detect,-35,-17)
    if (repeat_num==2) and (grid_align==3) and (argument0==0) script_execute(Place_Meeting_Detect,-52,0)
    if (repeat_num==3) and (grid_align==3) and (argument0==0) script_execute(Place_Meeting_Detect,-35,0)
    // agrid_align==0, rgument0==1
    if (repeat_num==0) and (grid_align==0) and (argument0==1) script_execute(Place_Meeting_Detect,0,-35)
    if (repeat_num==1) and (grid_align==0) and (argument0==1) script_execute(Place_Meeting_Detect,17,-35)
    if (repeat_num==2) and (grid_align==0) and (argument0==1) script_execute(Place_Meeting_Detect,0,-17)
    if (repeat_num==3) and (grid_align==0) and (argument0==1) script_execute(Place_Meeting_Detect,17,-17)
    // grid_align==1
    if (repeat_num==0) and (grid_align==1) and (argument0==1) script_execute(Place_Meeting_Detect,-17,-35)
    if (repeat_num==1) and (grid_align==1) and (argument0==1) script_execute(Place_Meeting_Detect,0,-35)
    if (repeat_num==2) and (grid_align==1) and (argument0==1) script_execute(Place_Meeting_Detect,-17,-17)
    if (repeat_num==3) and (grid_align==1) and (argument0==1) script_execute(Place_Meeting_Detect,0,-17)
    // agrid_align==2
    if (repeat_num==0) and (grid_align==2) and (argument0==1) script_execute(Place_Meeting_Detect,0,-52)
    if (repeat_num==1) and (grid_align==2) and (argument0==1) script_execute(Place_Meeting_Detect,17,-52)
    if (repeat_num==2) and (grid_align==2) and (argument0==1) script_execute(Place_Meeting_Detect,0,-35)
    if (repeat_num==3) and (grid_align==2) and (argument0==1) script_execute(Place_Meeting_Detect,17,-35)
    // grid_align==3
    if (repeat_num==0) and (grid_align==3) and (argument0==1) script_execute(Place_Meeting_Detect,-17,-17)
    if (repeat_num==1) and (grid_align==3) and (argument0==1) script_execute(Place_Meeting_Detect,0,-17)
    if (repeat_num==2) and (grid_align==3) and (argument0==1) script_execute(Place_Meeting_Detect,-17,-35)
    if (repeat_num==3) and (grid_align==3) and (argument0==1) script_execute(Place_Meeting_Detect,0,-35)
    // grid_align==0, argument0==2
    if (repeat_num==0) and (grid_align==0) and (argument0==2) script_execute(Place_Meeting_Detect,35,0)
    if (repeat_num==1) and (grid_align==0) and (argument0==2) script_execute(Place_Meeting_Detect,52,0)
    if (repeat_num==2) and (grid_align==0) and (argument0==2) script_execute(Place_Meeting_Detect,35,17)
    if (repeat_num==3) and (grid_align==0) and (argument0==2) script_execute(Place_Meeting_Detect,52,17)
     // grid_align==1
    if (repeat_num==0) and (grid_align==1) and (argument0==2) script_execute(Place_Meeting_Detect,18,0)
    if (repeat_num==1) and (grid_align==1) and (argument0==2) script_execute(Place_Meeting_Detect,35,0)
    if (repeat_num==2) and (grid_align==1) and (argument0==2) script_execute(Place_Meeting_Detect,18,17)
    if (repeat_num==3) and (grid_align==1) and (argument0==2) script_execute(Place_Meeting_Detect,35,17)
    // grid_align==2
    if (repeat_num==0) and (grid_align==2) and (argument0==2) script_execute(Place_Meeting_Detect,35,-17)
    if (repeat_num==1) and (grid_align==2) and (argument0==2) script_execute(Place_Meeting_Detect,52,-17)
    if (repeat_num==2) and (grid_align==2) and (argument0==2) script_execute(Place_Meeting_Detect,35,0)
    if (repeat_num==3) and (grid_align==2) and (argument0==2) script_execute(Place_Meeting_Detect,52,0)
    // grid_align==3
    if (repeat_num==0) and (grid_align==3) and (argument0==2) script_execute(Place_Meeting_Detect,18,-17)
    if (repeat_num==1) and (grid_align==3) and (argument0==2) script_execute(Place_Meeting_Detect,35,-17)
    if (repeat_num==2) and (grid_align==3) and (argument0==2) script_execute(Place_Meeting_Detect,18,0)
    if (repeat_num==3) and (grid_align==3) and (argument0==2) script_execute(Place_Meeting_Detect,35,0)
    // grid_align==0, argument0==3
    if (repeat_num==0) and (grid_align==0) and (argument0==3) script_execute(Place_Meeting_Detect,0,35)
    if (repeat_num==1) and (grid_align==0) and (argument0==3) script_execute(Place_Meeting_Detect,0,52)
    if (repeat_num==2) and (grid_align==0) and (argument0==3) script_execute(Place_Meeting_Detect,17,35)
    if (repeat_num==3) and (grid_align==0) and (argument0==3) script_execute(Place_Meeting_Detect,17,52)
    // grid_align==1
    if (repeat_num==0) and (grid_align==1) and (argument0==3) script_execute(Place_Meeting_Detect,-17,35)
    if (repeat_num==1) and (grid_align==1) and (argument0==3) script_execute(Place_Meeting_Detect,0,35)
    if (repeat_num==2) and (grid_align==1) and (argument0==3) script_execute(Place_Meeting_Detect,-17,52)
    if (repeat_num==3) and (grid_align==1) and (argument0==3) script_execute(Place_Meeting_Detect,0,52)
    // grid_align==2
    if (repeat_num==0) and (grid_align==2) and (argument0==3) script_execute(Place_Meeting_Detect,0,17)
    if (repeat_num==1) and (grid_align==2) and (argument0==3) script_execute(Place_Meeting_Detect,0,35)
    if (repeat_num==2) and (grid_align==2) and (argument0==3) script_execute(Place_Meeting_Detect,17,17)
    if (repeat_num==3) and (grid_align==2) and (argument0==3) script_execute(Place_Meeting_Detect,17,35)
    // grid_align==3
    if (repeat_num==0) and (grid_align==3) and (argument0==3) script_execute(Place_Meeting_Detect,-17,17)
    if (repeat_num==1) and (grid_align==3) and (argument0==3) script_execute(Place_Meeting_Detect,0,17)
    if (repeat_num==2) and (grid_align==3) and (argument0==3) script_execute(Place_Meeting_Detect,-17,35)
    if (repeat_num==3) and (grid_align==3) and (argument0==3) script_execute(Place_Meeting_Detect,0,35)
    repeat_num = repeat_num+1
}