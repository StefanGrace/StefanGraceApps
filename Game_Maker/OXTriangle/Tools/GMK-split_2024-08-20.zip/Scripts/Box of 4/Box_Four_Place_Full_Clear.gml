boxfull_topleft = 0
boxfull_topright = 0
boxfull_bottomleft = 0
boxfull_bottomright = 0