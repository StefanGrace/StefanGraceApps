// Character_Click_Red_Script
// Stefan Grace
// Created: 2020-02-21
// Modified: 2020-02-22
// This scrip is executed when a red character is clicked on

if (instance_number(Level_Cover)+global.t_detonating > 0) exit

script_execute(Character_Click_Red)
script_execute(Character_Turn_Blue_Red)