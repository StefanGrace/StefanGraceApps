// W_Heal_Cure_Stun
// Stefan Grace
// Created: 2018-11-01
// Modified: 2018-11-04

with(Move_Message) instance_destroy()
global.w_casting = true
global.message_type = 23
script_execute(Local_Message_Create)
