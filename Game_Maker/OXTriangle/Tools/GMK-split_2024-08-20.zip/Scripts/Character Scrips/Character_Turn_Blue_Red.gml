// Character_Turn_Blue_Red
// Stefan Grace
// Created: 2020-02-21
// Modified: 2020-03-03
// This script turns red characters into red blue characters when they are clicked on

if (global.at_swapping+global.w_casting+global.Red_B_Killing_Left+global.Red_B_Killing_Up+global.Red_B_Killing_Right+global.Red_B_Killing_Down == 0)
{
    switch(character_id)
    {
        case 0:
            instance_change(Red_Blue_O, false)
            break
        case 1:
            instance_change(Red_Blue_X, false)
            break
        case 2:
            instance_change(Red_Blue_Triangle, false)
            break
        case 3:
            instance_change(Red_Blue_A, false)
            break
        case 4:
            instance_change(Red_Blue_Square, false)
            break
        case 5:
            instance_change(Red_Blue_K, false)
            break
        case 6:
            instance_change(Red_Blue_B, false)
            break
        case 7:
            instance_change(Red_Blue_E, false)
            break
        case 8:
            instance_change(Red_Blue_S, false)
            break
        case 9:
            instance_change(Red_Blue_H, false)
            break
        case 10:
            instance_change(Red_Blue_R, false)
            break
        case 11:
            instance_change(Red_Blue_M, false)
            break
        case 12:
            instance_change(Red_Blue_F, false)
            break
        case 13:
            instance_change(Red_Blue_G, false)
            break
        case 14:
            instance_change(Red_Blue_C, false)
            break
        case 15:
            instance_change(Red_Blue_Y, false)
            break
        case 16:
            instance_change(Red_Blue_Z, false)
            break
        case 17:
            instance_change(Red_Blue_W, false)
            break
        case 18:
            instance_change(Red_Blue_J, false)
            break
        case 19:
            instance_change(Red_Blue_V, false)
            break
        case 20:
            instance_change(Red_Blue_P, false)
            break
        case 21:
            instance_change(Red_Blue_T, false)
            break
        case 22:
            instance_change(Red_Blue_D, false)
            break
        case 23:
            instance_change(Red_Blue_Q, false)
            break
        case 24:
            instance_change(Red_Blue_N, false)
            break
        case 26:
            instance_change(Red_Blue_Question_Mark, false)
            break
        case 27:
            instance_change(Red_Blue_U, false)
            break
        case 28:
            instance_change(Red_Blue_L, false)
            break
        case 29:
            instance_change(Red_Blue_Dollar_Sign, false)
            break
        case 30:
            instance_change(Red_Blue_At, false)
            break
        case 31:
            instance_change(Red_Blue_Pi, false)
            break
        case 32:
            instance_change(Red_Blue_I, false)
            break
        case 100:
            instance_change(Red_Blue_Lowercase_Q, false)
    }
    
}
