// Z_Stun
// Stefan Grace
// Created: 2017-12-13
// Modified: 2017-12-13

/* arguments
    argument0 - Player to be stuned
    1 - Player 1
    2 - Player 2
*/


if (S_Stuned>0) exit

with(all)
{
    if (player==argument0 and character_id!=17) S_Stuned = 1
}

score -= 1

instance_destroy()