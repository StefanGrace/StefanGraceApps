character_id = 100
move_snap(grid_size,grid_size)
repeat(4)
{
    script_execute(Auto_Stack_Detect_Black)
    script_execute(Auto_Stack_Detect_Red)
}