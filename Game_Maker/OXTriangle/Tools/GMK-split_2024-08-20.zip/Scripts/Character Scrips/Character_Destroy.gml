// Character_Destroy
// Stefan Grace
// Created: 2016-07-16
// Modified: 2020-02-13
// This script is executed when a selected (blue) character is killed

if (((Kill==1) or (RockTunnle==1) or (DimondTunnle==1)) and !v_diagonal_not_anger) score = 0 // This line of code sets the moves to 0 if the character is killed after going through an anger