// Q_Port
// Stefan Grace
// Created: 2017-12-21
// Modified: 2020-02-28
// This script makes Q's spawn q's at both sides of a teleport


if (score<4) exit

var spawned_q;
spawned_q = Q_Spawn()

var temp_x;
var temp_y;
var port_side;
var port_color;
temp_x = x
temp_y = y

if (place_meeting(x,y,Teleport)) with(Teleport) if (place_meeting(x,y,other))
{
    port_side = side
    port_color = color
    with(Teleport) if (side!=port_side and color==port_color)
    {
        Red_Blue_Q.x = x
        Red_Blue_Q.y = y
        Black_Blue_Q.x = x
        Black_Blue_Q.y = y
        with(Red_Blue_Q) spawned_q += Q_Spawn()
        with(Black_Blue_Q) spawned_q += Q_Spawn()
        Red_Blue_Q.x = temp_x
        Red_Blue_Q.y = temp_y
        Black_Blue_Q.x = temp_x
        Black_Blue_Q.y = temp_y
    }
}

if (spawned_q > 0) score -= 4