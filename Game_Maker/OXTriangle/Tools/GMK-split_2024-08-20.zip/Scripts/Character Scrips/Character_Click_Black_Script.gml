// Character_Click_Black_Script
// Stefan Grace
// Created: 2020-02-21
// Modified: 2020-02-22
// This scrip is executed when a black character is clicked on

if (instance_number(Level_Cover)+global.t_detonating > 0) exit

script_execute(Character_Click_Black)
script_execute(Character_Turn_Blue_Black)