// T_Set
// Stefan Grace
// Created: 2017-12-22
// Modified: 2017-12-22
// This script sets the T up ready to be detonated when CTRL key is pressed


if (score<2) exit

var t_line;
t_line = 0
var i;
if (player==1)
{
    for (i = -36; i < 37; i += 1)
    {
        // x
        if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size)),Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size))+17,Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size))+17,Red_T)) t_line += 1
        // y
        if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size),Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+17+(i*grid_size),Red_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+17+(i*grid_size),Red_T)) t_line += 1
    }
}
if (player==2)
{
    for (i = -36; i < 37; i += 1)
    {
        // x
        if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size)),Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size))+17,Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size))+17,Black_T)) t_line += 1
        // y
        if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size),Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+17+(i*grid_size),Black_T)) t_line += 1
        if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+17+(i*grid_size),Black_T)) t_line += 1
    }
}

if (t_line==0)
{
    show_message(global.text_message_t_noline)
    exit
}

global.t_detonating = 1
global.message_type = 22
script_execute(Local_Message_Create)