// L_Long
// Stefan Grace
// Created: 2018-11-05
// Modified: 2024-07-28
// This script makes L do it's long thing

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
*/


if (keyboard_check(vk_control)) || global.tablet_function_button_active || joystick_check_button(0, 1)
{
    long = true
    var i;
    var hit_anger;
    hit_anger = false
    score = 50
    for(i = 0; i < 37 and !hit_anger; i += 1)
    {
        Character_Move(argument0)
        if (place_meeting(x,y,Red_Anger))
        or (place_meeting(x,y,Orange_Anger))
        or (place_meeting(x,y,Blue_Anger))
        or (place_meeting(x,y,Purple_Anger))
        {
            hit_anger = true
        }
    } 
    if (!hit_anger) score = 0
}
else 
{
    long = false
    Character_Move(argument0, 1)
}