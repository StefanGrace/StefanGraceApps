// Character_Draw
// Stefan Grace
// Created: 2017-08-08
// Modified: 2020-02-23
// This script draws out the small characters

/* variables

    type
        0 - Red Stuned
        1 - Red
        2 - Red Blue
        3 - Black Stuned
        4 - Black
        5 - Black Blue
        6 - Green
*/

// Sets things up
draw_set_font(Character_Font)
draw_set_halign(fa_center)
draw_set_valign(fa_center)

// Decides what color the character should be
var color;
if (type==0) 
{
    if (mouse_x>=x and mouse_x<x+17 and mouse_y>y and mouse_y<y+17 and instance_number(Level_Cover)==0)
    and (B_Detect() or Dollar_Sign_Range_Detect())
    {
        color = character_color_blue   
    }
    else if (purple==0) 
    {
        color = character_color_red
    }
    else
    { 
        color = character_color_purple
    }
}
if (type==1) 
{
    if (mouse_x>=x and mouse_x<x+17 and mouse_y>y and mouse_y<y+17 and instance_number(Level_Cover)==0 
    and global.Red_B_Killing_Left+global.Red_B_Killing_Up+global.Red_B_Killing_Right+global.Red_B_Killing_Down == 0)
    {
        color = character_color_blue   
    }
    else if (purple==0)
    {
        color = character_color_red
    }
    else
    {         
        color = character_color_purple                                        
    }                                                                                        
}                                                                                                                                                
if (type==2 or type==5) color = character_color_blue
if (type==3) 
{
    if (mouse_x>=x and mouse_x<x+17 and mouse_y>y and mouse_y<y+17 and instance_number(Level_Cover)==0)
    and (B_Detect() or Dollar_Sign_Range_Detect())
    {
        color = character_color_blue   
    }
    else if (purple==0)
    {
        color = character_color_black
    }
    else
    { 
        color = character_color_dark_blue
    }
}
if (type==4) 
{
    if (mouse_x>=x and mouse_x<x+17 and mouse_y>y and mouse_y<y+17 and instance_number(Level_Cover)==0
    and global.Black_B_Killing_Left+global.Black_B_Killing_Up+global.Black_B_Killing_Right+global.Black_B_Killing_Down == 0)
    {
        color = character_color_blue  
    }
    else if (purple==0)
    {
        color = character_color_black
    }
    else
    { 
        color = character_color_dark_blue
    }
}
if (type==6) 
{
    color = character_color_green
}

// Make the character look yellow if it is an an enviroment of the same color
if (color==character_color_black and place_meeting(x,y,Steel))
or (color==character_color_red and place_meeting(x,y,Red_Anger))
or (color==character_color_blue and place_meeting(x,y,Blue_Anger))
or (color==character_color_green and place_meeting(x,y,Dimond))
or (color==character_color_purple and place_meeting(x,y,Purple_Anger))
{
    color = character_color_yellow
}

// Makes an icy looking box apear round the character when it is stunded
if (S_Stuned>0) draw_sprite(Ice,0,x,y) 

// Decides what the character should look like
draw_set_color(color) 
if (character_id==2)
{
    if (color==character_color_black) draw_sprite(Black_Triangle_Sprite,0,x,y)
    else if (color==character_color_red) draw_sprite(Red_Triangle_Sprite,0,x,y)
    else if (color==character_color_blue) draw_sprite(Blue_Triangle,0,x,y)
    else if (color==character_color_green) draw_sprite(Green_Triangle_Sprite,0,x,y)
    else if (color==character_color_yellow) draw_sprite(Yellow_Triangle,0,x,y)    
    else if (color==character_color_dark_blue) draw_sprite(Dark_Blue_Triangle,0,x,y) 
    else if (color==character_color_purple) draw_sprite(Purple_Triangle,0,x,y)     
}
else if (character_id==4)
{
    if (color==character_color_black) draw_sprite(Black_Square_Sprite,0,x,y)
    else if (color==character_color_red) draw_sprite(Red_Square_Sprite,0,x,y)
    else if (color==character_color_blue) draw_sprite(Blue_Square,0,x,y)
    else if (color==character_color_green) draw_sprite(Green_Square_Sprite,0,x,y)
    else if (color==character_color_yellow) draw_sprite(Yellow_Square,0,x,y)    
    else if (color==character_color_dark_blue) draw_sprite(Dark_Blue_Square,0,x,y) 
    else if (color==character_color_purple) draw_sprite(Purple_Square,0,x,y) 
}
else
{
    draw_text(x+9,y+9,global.character_text[character_id])
}

// Puts things back 
draw_set_halign(0)
draw_set_valign(0)
draw_set_color(0)