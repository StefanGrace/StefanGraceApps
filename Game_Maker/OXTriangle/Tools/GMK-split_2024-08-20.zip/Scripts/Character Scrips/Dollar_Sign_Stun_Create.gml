// Dollar_Sign_Create
// Stefan Grace
// Created: 2017-12-23
// Modified: 2018-10-31

/* arguments
    argument0 - player
        1 - Player 1
        2 - Player 2
*/

if (character_id == 17) exit

script_execute(Teleport_Explosion,2)

var i;
var j;
for (i = -2; i < 3; i += 1)
{
    for (j = -2; j < 3; j += 1)
    {
        instance_create((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size))-(j*grid_size),Dollar_Sign_Stun)
    }
}

with(all)
{
    if (character_id!=17 and player==argument0)
    {
        if (place_meeting(x,y,Dollar_Sign_Stun)) S_Stuned = 1
    }
}

Dollar_Sign_Stun.alarm[0] = 3
score -= 1
global.dollar_sign_stunning = 0
with(Message_Object) instance_destroy()