// Double_Boxing_Turn_Yellow
// Stefan Grace
// Created: 2016-08-15
// Modified: 2016-08-15
// This script makes Double Boxing turn yellow when a character moves into it and turn dimond when a character moves out of it

/* aruguments

argument0 = X Jump

argument1 = Y Jump
*/

var Double_Boxing_X;
var Double_Boxing_Y;

Double_Boxing_X = x
Double_Boxing_Y = y

// This block of code makes Double Boxing Rock and Double Boxing Dimond turn yellow when a character moves into it
with(Double_Boxing_Rock)
{
    if ((Double_Boxing_X==x) or (Double_Boxing_X==x-1)) and ((Double_Boxing_Y==y) or (Double_Boxing_Y==y-1)) instance_change(Double_Boxing_Yellow,false)

}
with(Double_Boxing_Dimond)
{
    if ((Double_Boxing_X==x) or (Double_Boxing_X==x-1)) and ((Double_Boxing_Y==y) or (Double_Boxing_Y==y-1)) instance_change(Double_Boxing_Yellow,false)

}

// This block of code makes Double Boxing turn into Dimond when a character moves out of it
with(Double_Boxing_Yellow)
{
    if ((x==(Double_Boxing_X-argument0)) or (x-1==(Double_Boxing_X-argument0))) and ((y==(Double_Boxing_Y-argument1)) or (y-1==(Double_Boxing_Y-argument1))) instance_change(Double_Boxing_Dimond,false)
}
