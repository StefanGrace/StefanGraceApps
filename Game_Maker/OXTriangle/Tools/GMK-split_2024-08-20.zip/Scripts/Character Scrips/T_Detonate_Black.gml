// T_Detonate_Black
// Stefan Grace
// Created: 2017-12-22
// Modified: 2020-02-22
// This script makes the T detonate after the other T has been clicked

if (instance_number(Level_Cover)+global.Black_B_Killing_Left+global.Black_B_Killing_Up+global.Black_B_Killing_Right+global.Black_B_Killing_Down > 0) exit

if (global.t_detonating==0)
{
    script_execute(Character_Click_Black)
    if (global.at_swapping==0 and !global.w_casting) instance_change(Black_Blue_T,false)
    exit
}

// Detects which direction the blue T is in
var t_left;
var t_up;
var t_right;
var t_down;
t_left = 0
t_up = 0
t_right = 0
t_down = 0
for (i = 2; i < 37; i += 1)
{
    // left
    if (place_meeting((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Black_Blue_T)) t_left += 1
    if (place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,(y-(y mod grid_size)),Black_Blue_T)) t_left += 1
    if (place_meeting((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size))+17,Black_Blue_T)) t_left += 1
    if (place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,(y-(y mod grid_size))+17,Black_Blue_T)) t_left += 1
    // up
    if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Black_Blue_T)) t_up += 1
    if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))-(i*grid_size),Black_Blue_T)) t_up += 1
    if (place_meeting((x-(x mod grid_size)),((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T)) t_up += 1
    if (place_meeting((x-(x mod grid_size))+17,((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T)) t_up += 1
    // right
    if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Black_Blue_T)) t_right += 1
    if (place_meeting(((x-(x mod grid_size))+(i*grid_size))+17,(y-(y mod grid_size)),Black_Blue_T)) t_right += 1
    if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size))+17,Black_Blue_T)) t_right += 1
    if (place_meeting(((x-(x mod grid_size))+(i*grid_size))+17,(y-(y mod grid_size))+17,Black_Blue_T)) t_right += 1
    // down
    if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) t_down += 1
    if (place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) t_down += 1
    if (place_meeting((x-(x mod grid_size)),((y-(y mod grid_size))+(i*grid_size))+17,Black_Blue_T)) t_down += 1
    if (place_meeting((x-(x mod grid_size))+17,((y-(y mod grid_size))+(i*grid_size))+17,Black_Blue_T)) t_down += 1
}

// Makes T explosions get blocked by concreet
var stopped_exploding;
var blocked_by_concreet;
stopped_exploding = 0
blocked_by_concreet = 0
for (i = 1; i < 37; i += 1)
{
    if (t_left>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))-(i*grid_size),((y-(y mod grid_size)))+17,Black_Blue_T))
        and (!place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,((y-(y mod grid_size)))+17,Black_Blue_T))
        {
            if (place_meeting((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Concreet)) blocked_by_concreet = 1
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_up>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size)))+17,((y-(y mod grid_size))-(i*grid_size)),Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size))),((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size)))+17,((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T)) 
        {
            if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Concreet)) blocked_by_concreet = 1
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_right>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size))+17,Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size))+17,Black_Blue_T))
        {
            if (place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Concreet)) blocked_by_concreet = 1
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_down>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size)+17,Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size)+17,Black_Blue_T)) 
        {
            if (place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Concreet)) blocked_by_concreet = 1
        }
        else
        {
            stopped_exploding = 1
        }
    }
}
if (blocked_by_concreet>0)
{
    global.t_detonating = 0
    with(Message_Object) instance_destroy()
    show_message(global.text_message_t_concreet)
    exit
}


// Makes the explosion happen and stop when it gets to the blue T
var stopped_exploding;
stopped_exploding = 0
for (i = 1; i < 37; i += 1)
{
    if (t_left>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))-(i*grid_size),((y-(y mod grid_size)))+17,Black_Blue_T))
        and (!place_meeting(((x-(x mod grid_size))-(i*grid_size))+17,((y-(y mod grid_size)))+17,Black_Blue_T))
        {
            instance_create((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Explosion)
            instance_create((x-(x mod grid_size))-(i*grid_size),(y-(y mod grid_size)),Explosion_T_Horizontal_Object)
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_up>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size)))+17,((y-(y mod grid_size))-(i*grid_size)),Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size))),((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T)) 
        and (!place_meeting(((x-(x mod grid_size)))+17,((y-(y mod grid_size))-(i*grid_size))+17,Black_Blue_T))
        {
            instance_create((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Explosion)
            instance_create((x-(x mod grid_size)),(y-(y mod grid_size))-(i*grid_size),Explosion_T_Vertical_Object)
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_right>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size)),Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size))+17,Black_Blue_T))
        and (!place_meeting((x-(x mod grid_size))+(i*grid_size)+17,(y-(y mod grid_size))+17,Black_Blue_T))
        {
            instance_create((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Explosion)
            instance_create((x-(x mod grid_size))+(i*grid_size),(y-(y mod grid_size)),Explosion_T_Horizontal_Object)
        }
        else
        {
            stopped_exploding = 1
        }
    }
    if (t_down>0 and stopped_exploding==0)
    {
        if (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size),Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size)+17,Black_Blue_T)) 
        and (!place_meeting((x-(x mod grid_size))+17,(y-(y mod grid_size))+(i*grid_size)+17,Black_Blue_T))
        {
            instance_create((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Explosion)
            instance_create((x-(x mod grid_size)),(y-(y mod grid_size))+(i*grid_size),Explosion_T_Vertical_Object)
        }
        else
        {
            stopped_exploding = 1
        }
    }
}

global.t_detonating = 0
with(Message_Object) instance_destroy()
score -= 2