// Character_Move
// Stefan Grace
// Created: 2016-07-08
// Modified: 2020-02-24
// This script makes any character move in the chosen direction

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
    4 = Top Left (V)
    5 = Top Right (V)
    6 = Bottom Left (V)
    7 = Bottom Right (V)

argument1 = Rock Tunnel
    0 = No
    1 = Yes

argument2 = Dimond Tunnel
    0 = No
    1 = Yes
    
argument3 = B
    0 = No
    1 = Yes
*/


// Game Frozen
//if (global.game_frozen>0) exit

// Stops a character from moving while the ? select screen of menu is showing
if (instance_number(Level_Cover) > 0) exit

// Stop a character from moving while the a boulder or bomb is falling
var boulder_falling;
with (Boulder)
{
    if (falling) boulder_falling = true
}
if (boulder_falling) exit

// Stop the player pressing 2 arrow keys at once
if (Key_Mash_Detect(argument0)) exit

// S Stuned
if (S_Stuned>0) 
{
    show_message (global.text_s_stun)
    exit
}

// Barria
if (character_id!=27 or score<2)
{
    if (argument0==0) and (place_meeting(x,y,Barria_Vertical)) exit
    if (argument0==1) and (place_meeting(x,y,Barria_Horizontal)) exit
    if (argument0==2) and (place_meeting(x+35,y,Barria_Vertical)) exit
    if (argument0==3) and (place_meeting(x,y+35,Barria_Horizontal)) exit
}
else 
{
    if (argument0==0) and (place_meeting(x,y,Barria_Vertical)) score -= 1
    if (argument0==1) and (place_meeting(x,y,Barria_Horizontal)) score -= 1
    if (argument0==2) and (place_meeting(x+35,y,Barria_Vertical)) score -= 1
    if (argument0==3) and (place_meeting(x,y+35,Barria_Horizontal)) score -= 1
}

// Mud
if (place_meeting(x,y,Mud) and character_id!=32) exit // can't move out of mud if it's NOT an I

// Arrow
if (argument0==0) and ((place_meeting(x-35,y,Right_Arrow)) or (place_meeting(x-35,y,Horizontal_Arrow))) exit
if (argument0==1) and ((place_meeting(x,y-35,Down_Arrow)) or (place_meeting(x,y-35,Vertical_Arrow))) exit
if (argument0==2) and ((place_meeting(x+35,y,Left_Arrow)) or (place_meeting(x+35,y,Horizontal_Arrow))) exit
if (argument0==3) and ((place_meeting(x,y+35,Up_Arrow)) or (place_meeting(x,y+35,Vertical_Arrow))) exit
if (!(argument0==0)) and (place_meeting(x,y,Left_Arrow)) exit 
if (!(argument0==1)) and (place_meeting(x,y,Up_Arrow)) exit 
if (!(argument0==2)) and (place_meeting(x,y,Right_Arrow)) exit 
if (!(argument0==3)) and (place_meeting(x,y,Down_Arrow)) exit 
if ((argument0==0) or (argument0==2)) and (place_meeting(x,y,Vertical_Arrow)) exit
if ((argument0==1) or (argument0==3)) and (place_meeting(x,y,Horizontal_Arrow)) exit

// Sets X_Jump and Y_Jump
var X_Jump;
var Y_Jump;
X_Jump = 0
Y_Jump = 0
if (argument0==0) X_Jump = -35
if (argument0==1) Y_Jump = -35
if (argument0==2) X_Jump = 35
if (argument0==3) Y_Jump = 35
if (argument0==4) {X_Jump = -35; Y_Jump = -35} 
if (argument0==5) {X_Jump = 35; Y_Jump = -35} 
if (argument0==6) {X_Jump = -35; Y_Jump = 35} 
if (argument0==7) {X_Jump = 35; Y_Jump = 35} 


// Green G
if (place_meeting(x+X_Jump,y+Y_Jump,Green_G)) exit

// Big W
var big_w_block;
if (player==1) 
{
    with(Red_G) if (place_meeting(x-X_Jump,y-Y_Jump,other) and g_type==3) big_w_block = 1
    with(Red_Stuned_G) if (place_meeting(x-X_Jump,y-Y_Jump,other) and g_type==3) big_w_block = 1
}
if (player==2) 
{
    with(Black_G) if (place_meeting(x-X_Jump,y-Y_Jump,other) and g_type==3) big_w_block = 1
    with(Black_Stuned_G) if (place_meeting(x-X_Jump,y-Y_Jump,other) and g_type==3) big_w_block = 1
}
if (big_w_block>0) exit

// Double Boxing
if (Double_Boxing_Entry_Message_Shown==1)
{
    X_Jump = 0
    Y_Jump = 0
    if (Original_Dir==0) X_Jump = -35
    if (Original_Dir==1) Y_Jump = -35
    if (Original_Dir==2) X_Jump = 35
    if (Original_Dir==3) Y_Jump = 35 
}
if ((place_meeting(x+X_Jump,y+Y_Jump,Double_Boxing)) or (place_meeting(x,y,Double_Boxing)) and argument0 < 4)
{
    if (!(place_meeting(x,y,Double_Boxing))) // Returns true if the character is NOT inside Double Boxing
    {
        if (Double_Boxing_Entry_Message_Shown==0) // Returns true if the Double Boxing Entry Message has NOT been shown
        {
            Double_Boxing_Entry_Message_Shown = 1
            Original_Dir = argument0
            Original_Rock_Tunnle = argument1
            Original_Dimond_Tunnle = argument2
            if ((argument0 mod 2)==0) global.message_type = 10 else global.message_type = 11
            script_execute(Local_Message_Create)
            exit
        }
        if (Double_Boxing_Entry_Message_Shown==1) // Returns true if the Double Boxing Message has been shown
        {
            var X_Jump_Double_Boxing;
            var Y_Jump_Double_Boxing;
            var X_Side_Double_Boxing;
            var Y_Side_Double_Boxing;
            X_Jump_Double_Boxing = 0
            Y_Jump_Double_Boxing = 0
            X_Side_Double_Boxing = 0
            Y_Side_Double_Boxing = 0
            
            if ((x mod 35)<10) Y_Jump_Double_Boxing = Y_Jump else Y_Jump_Double_Boxing = (Y_Jump div 2)
            if (!((argument0 mod 2)==(Original_Dir mod 2))) // Makes it so nothing happens if the wrong arrows are pressed
            {
                Double_Boxing_Entry_Message_Shown = 0
                with(Message_Object) instance_destroy()
            }
            else exit
            if (Original_Dir==0)
            {
                if ((x mod 35)>10) X_Jump_Double_Boxing = X_Jump else X_Jump_Double_Boxing = (X_Jump div 2) 
                if (argument0==1)
                {
                    if ((y mod 35)>10) X_Side_Double_Boxing = -17
                    script_execute(Character_Jump_Double_Boxing,X_Jump_Double_Boxing,X_Side_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                } 
                if (argument0==3)
                {
                    if ((y mod 35)<10) X_Side_Double_Boxing = 17
                    script_execute(Character_Jump_Double_Boxing,X_Jump_Double_Boxing,X_Side_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                }
            } 
            if (Original_Dir==1)
            {
                if ((y mod 35)>10) Y_Jump_Double_Boxing = Y_Jump else Y_Jump_Double_Boxing = (Y_Jump div 2) 
                if (argument0==0)
                {
                    if ((x mod 35)>10) Y_Side_Double_Boxing = -17
                    script_execute(Character_Jump_Double_Boxing,Y_Side_Double_Boxing,Y_Jump_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                } 
                if (argument0==2)
                {
                    if ((x mod 35)<10) Y_Side_Double_Boxing = 17
                    script_execute(Character_Jump_Double_Boxing,Y_Side_Double_Boxing,Y_Jump_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                }
            } 
            if (Original_Dir==2)
            {
                if ((x mod 35)<10) X_Jump_Double_Boxing = X_Jump else X_Jump_Double_Boxing = (X_Jump div 2) 
                if (argument0==1)
                {
                    if ((y mod 35)>10) X_Side_Double_Boxing = -17
                    script_execute(Character_Jump_Double_Boxing,X_Jump_Double_Boxing,X_Side_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                } 
                if (argument0==3)
                {
                    if ((y mod 35)<10) X_Side_Double_Boxing = 17
                    script_execute(Character_Jump_Double_Boxing,X_Jump_Double_Boxing,X_Side_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                }
            } 
            if (Original_Dir==3)
            {
                if ((y mod 35)<10) Y_Jump_Double_Boxing = Y_Jump else Y_Jump_Double_Boxing = (Y_Jump div 2) 
                if (argument0==0)
                {
                    if ((x mod 35)>10) Y_Side_Double_Boxing = -17
                    script_execute(Character_Jump_Double_Boxing,Y_Side_Double_Boxing,Y_Jump_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                } 
                if (argument0==2)
                {
                    if ((x mod 35)<10) Y_Side_Double_Boxing = 17
                    script_execute(Character_Jump_Double_Boxing,Y_Side_Double_Boxing,Y_Jump_Double_Boxing,Original_Rock_Tunnle,Original_Dimond_Tunnle)
                    exit
                }
            } 
        }
        
    }
    if (place_meeting(x,y,Double_Boxing)) // Returns true if the character is inside Double Boxing
    {
        var X_Jump_Double_Boxing;
        var Y_Jump_Double_Boxing;
        X_Jump_Double_Boxing = X_Jump div 2
        Y_Jump_Double_Boxing = Y_Jump div 2
        if (place_meeting(x+X_Jump_Double_Boxing,y+Y_Jump_Double_Boxing,Double_Boxing)) // Returns true if the character is moving from Double Boxing into Double Boxing
        {
            script_execute(Character_Jump_Double_Boxing,X_Jump_Double_Boxing,Y_Jump_Double_Boxing,argument1,argument2)
            exit
        }
        else 
        {
            var Double_Boxing_X;
            var Double_Boxing_Y;
            Double_Boxing_X = x
            Double_Boxing_Y = y
            with(Double_Boxing_Yellow)
            {
                if ((Double_Boxing_X==x) or (Double_Boxing_X==x-1)) and ((Double_Boxing_Y==y) or (Double_Boxing_Y==y-1)) instance_change(Double_Boxing_Dimond,false) 
            }
            if ((x mod 35)>10) x = x-1
            if ((y mod 35)>10) y = y-1
        }
    }
}


// Box of 4
script_execute(Box_Four_Detect,argument0)
if (boxfull_topleft==1) and (boxfull_topright==1) and (boxfull_bottomleft==1) and (boxfull_bottomright==1)
{
    if (argument3==0)
    {
        if (!long) show_message (global.text_box_four_message)
        script_execute(Box_Four_Place_Full_Clear)
        exit
    }
    // B
    if (argument3==1)
    {
        var b_player;
        b_player = player
        var own_characters;
        own_characters = 0
        with(Character)
        {
            if (player == b_player)
            {
                var i;
                for (i = 0; i < 17; i += 17)
                {
                    var j;
                    for (j = 0; j < 17; j += 17)
                    {
                        if (x - (x mod grid_size) - X_Jump == other.x + i and y - (y mod grid_size) - Y_Jump == other.y + j) own_characters += 1 
                    }
                }
            }
        }
        if (own_characters > 3) 
        {
            show_message (global.text_box_four_message)
            script_execute(Box_Four_Place_Full_Clear)
            exit
        }
        if (argument0==0) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Left = 1
        if (argument0==1) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Up = 1
        if (argument0==2) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Right = 1 
        if (argument0==3) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Down = 1 
        if (argument0==0) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Left = 1
        if (argument0==1) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Up = 1
        if (argument0==2) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Right = 1 
        if (argument0==3) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Down = 1
        global.message_type = 20
        script_execute(Local_Message_Create)
        script_execute(Box_Four_Place_Full_Clear)
        exit
    }
}
script_execute(Box_Four_Place_Full_Clear) 

// Teleport
if (place_meeting(x+X_Jump,y+Y_Jump,Teleport))
{
    /* Counts the number of characters in both sides of the teleport, adds them together
    and if that number is greater than 3, any character other than B is unable to enter */
    var black_characters_in_port;
    black_characters_in_port = 0
    var red_characters_in_port;
    red_characters_in_port = 0
    with (Teleport)
    {
        if (place_meeting(x-X_Jump,y-Y_Jump,other))
        {
            with (Black_Character)
            {
                if (place_meeting(x,y,other)) black_characters_in_port += 1
            }
            with (Red_Character)
            {
                if (place_meeting(x,y,other)) red_characters_in_port += 1
            }
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    with (Black_Character)
                    {
                        if (place_meeting(x,y,other)) black_characters_in_port += 1
                    }
                     with (Red_Character)
                    {
                        if (place_meeting(x,y,other)) red_characters_in_port += 1
                    }
                }
            }
        }
    }
    if (argument0 == 0)
    {
        if (black_characters_in_port + red_characters_in_port > 3)
        {
            show_message(global.text_teleport_full)
            exit
        }
    }
    else
    {
        if (player == 1 and red_characters_in_port > 3)
        or (player == 2 and black_characters_in_port > 3)
        {
            show_message(global.text_teleport_full)
            exit
        }
        else if (black_characters_in_port + red_characters_in_port > 3)
        {
            if (argument0==0) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Left = 1
            if (argument0==1) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Up = 1
            if (argument0==2) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Right = 1 
            if (argument0==3) and (instance_number(Go_Number_Red)==1) global.Red_B_Killing_Down = 1 
            if (argument0==0) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Left = 1
            if (argument0==1) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Up = 1
            if (argument0==2) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Right = 1 
            if (argument0==3) and (instance_number(Go_Number_Black)==1) global.Black_B_Killing_Down = 1
            global.message_type = 20
            script_execute(Local_Message_Create)
            exit
        }
    }
}
if (place_meeting(x+X_Jump,y+Y_Jump,Teleport))
{
    /* Stops any character from entering a teleport when there is a Big W in the other side */
    var big_w_in_port;
    big_w_in_port = false
    with (Teleport)
    {
        if (place_meeting(x-X_Jump,y-Y_Jump,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    if (instance_number(Go_Number_Black) > 0)
                    {
                        with (Black_G)
                        {
                            if (g_type == 3 and place_meeting(x,y,other)) big_w_in_port = true
                        }
                    }
                    else
                    {
                        with (Red_G)
                        {
                            if (g_type == 3 and place_meeting(x,y,other)) big_w_in_port = true
                        }
                    }
                }
            }
        }
    }
    if (big_w_in_port) exit
}

// Boulder
if (character_id!=15)
{
    if (argument0==0) or (argument0==2)
    {
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*2,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*3,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*4,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*4,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*5,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump,y+Y_Jump,Mud)) exit
    }
    if (argument0==1) or (argument0==3)
    {
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) exit
    }
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Left_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Right_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump*2,y,Barria_Vertical)) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump,y,Barria_Vertical)) exit
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Left_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Right_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Up_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Down_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Vertical_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
}
else if (place_meeting(x,y-grid_size,Boulder) and argument0==1)
{
    with(Boulder)
    {
        if (place_meeting(x,y+grid_size,other)) instance_destroy()
    }
}

// Anger Colors
if (place_meeting(x+X_Jump,y+Y_Jump,Red_Anger))
{
    score = 1+1
    background_index[0] = -1
    background_color = c_red
    Kill = 1
    RockTunnle = 0
    DimondTunnle = 0
    script_execute(Red_Stun)
    script_execute(Black_Stun)
    global.anger = 1
}
if (place_meeting(x+X_Jump,y+Y_Jump,Orange_Anger))
{
    score = 1+1
    background_index[0] = -1
    background_color = $4080FF
    Kill = 0
    RockTunnle = 1
    DimondTunnle = 0
    script_execute(Red_Stun)
    script_execute(Black_Stun)
    global.anger = 1
}
if (place_meeting(x+X_Jump,y+Y_Jump,Blue_Anger))
{
    score = 1+1
    background_index[0] = -1
    background_color = $FFFF00
    Kill = 0
    RockTunnle = 0
    DimondTunnle = 1
    script_execute(Red_Stun)
    script_execute(Black_Stun)
    global.anger = 1
}
if (place_meeting(x+X_Jump,y+Y_Jump,Purple_Anger))
{
    score = 1+1
    background_index[0] = -1
    background_color = $FF00FF
    Kill = 1
    RockTunnle = 1
    DimondTunnle = 1
    script_execute(Red_Stun)
    script_execute(Black_Stun)
    global.anger = 1
}

// Anger Numbers
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_00)) score = 0+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_02)) score = 2+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_03)) score = 3+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_04)) score = 4+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_05)) score = 5+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_06)) score = 6+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_07)) score = 7+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_08)) score = 8+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_09)) score = 9+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_10)) score = 10+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_11)) score = 11+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_12)) score = 12+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_13)) score = 13+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_14)) score = 14+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_15)) score = 15+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_16)) score = 16+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_17)) score = 17+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_18)) score = 18+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_19)) score = 19+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_20)) score = 20+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_21)) score = 21+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_22)) score = 22+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_23)) score = 23+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_24)) score = 24+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_25)) score = 25+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_26)) score = 26+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_27)) score = 27+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_28)) score = 28+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_29)) score = 29+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_30)) score = 30+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_31)) score = 31+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_32)) score = 32+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_33)) score = 33+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_34)) score = 34+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_35)) score = 35+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_36)) score = 36+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_37)) score = 37+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_38)) score = 38+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_39)) score = 39+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_40)) score = 40+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_41)) score = 41+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_42)) score = 42+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_43)) score = 43+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_44)) score = 44+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_45)) score = 45+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_46)) score = 46+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_47)) score = 47+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_48)) score = 48+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_49)) score = 49+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_50)) score = 50+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_51)) score = 51+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_52)) score = 52+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_53)) score = 53+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_54)) score = 54+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_55)) score = 55+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_56)) score = 56+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_57)) score = 57+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_58)) score = 58+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_59)) score = 59+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_60)) score = 60+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_61)) score = 61+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_62)) score = 62+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_63)) score = 63+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_64)) score = 64+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_65)) score = 65+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_66)) score = 66+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_67)) score = 67+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_68)) score = 68+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_69)) score = 69+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_70)) score = 70+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_71)) score = 71+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_72)) score = 72+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_73)) score = 73+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_74)) score = 74+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_75)) score = 75+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_76)) score = 76+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_77)) score = 77+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_78)) score = 78+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_79)) score = 79+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_80)) score = 80+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_81)) score = 81+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_82)) score = 82+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_83)) score = 83+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_84)) score = 84+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_85)) score = 85+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_86)) score = 86+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_87)) score = 87+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_88)) score = 88+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_89)) score = 89+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_90)) score = 90+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_91)) score = 91+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_92)) score = 92+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_93)) score = 93+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_94)) score = 94+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_95)) score = 95+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_96)) score = 96+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_97)) score = 97+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_98)) score = 98+1
if (place_meeting(x+X_Jump,y+Y_Jump,Anger_99)) score = 99+1

// V 
if (argument0>3)
{
    if (place_meeting(x,y,Double_Boxing)) exit // Stops V from leaving Double Boxing diagoannly
    if (Kill == 0) alarm[1] = 2
    if (Kill + RockTunnle + DimondTunnle == 0) v_diagonal_not_anger = true
    Kill = 1
    var character_in_range;
    character_in_range = false
    var v_player;
    v_player = player
    with(all) // Makes it so V can only move if there is something to kill
    {
        if (character_id + character_o > 0)
        {
            if (player!=v_player)
            {
                var tile_x;
                var tile_y;
                tile_x = x - (x mod grid_size)
                tile_y = y - (y mod grid_size)
                var i;
                for (i = 0; i <= 17; i += 17) 
                {
                    var j;
                    for (j = 0; j <= 17; j += 17) 
                    {
                        if place_meeting((tile_x-X_Jump)+i,(tile_y-Y_Jump)+j,other)
                        {
                            character_in_range = true
                        }  
                    }
                }                   
            }
        }   
    }
    with(Teleport) // Allows V to move diagonally into a teleport if there is an opponent's character in the other side
    {
        if (place_meeting(x-X_Jump,y-Y_Jump,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    with (all)
                    {
                        if (character_id + character_o > 0)
                        {
                            if (place_meeting(x,y,other) and player!=v_player)
                            {
                                character_in_range = true
                            }
                        }
                    }
                }
            }
        }
    }
    if (!character_in_range) 
    {
        show_message (global.text_v_diagonal)
        exit
    }
    var characters_in_tile;
    characters_in_tile = 0
    with(all) // Stops V for getting into a box of 4
    {
        if (character_id + character_o > 0 and character_id != 13) 
        {
            var tile_x;
            var tile_y;
            tile_x = x - (x mod grid_size)
            tile_y = y - (y mod grid_size)
            var i;
            for (i = 0; i <= 17; i += 17) 
            {    
                var j;
                for (j = 0; j <= 17; j += 17) 
                {
                    if place_meeting((tile_x-X_Jump)+i,(tile_y-Y_Jump)+j,other)
                    {
                        characters_in_tile += 1;
                    }  
                }
            }  
        }
    }
    if (characters_in_tile > 3) 
    {
        show_message (global.text_box_four_message)
        exit
    }
}
    
// U
if (character_id==27)
{
    if place_meeting(x+X_Jump,y+Y_Jump,Black_Pi) or place_meeting(x+X_Jump,y+Y_Jump,Black_Stuned_Pi)
    or place_meeting(x+X_Jump,y+Y_Jump,Red_Pi) or place_meeting(x+X_Jump,y+Y_Jump,Red_Stuned_Pi) or place_meeting(x+X_Jump,y+Y_Jump,Green_Pi)
    {
        exit
    }
    if (place_meeting(x+X_Jump,y+Y_Jump,Yellow) and (!place_meeting(x,y,Yellow)))
    {
        Kill = 1
        alarm[1] = 2
        script_execute(Character_Jump,X_Jump,Y_Jump)
        exit
    }
    if (place_meeting(x+X_Jump,y+Y_Jump,Rock) and RockTunnle==0)
    or (place_meeting(x+X_Jump,y+Y_Jump,Dimond) and DimondTunnle==0)
    or place_meeting(x+X_Jump,y+Y_Jump,Concreet) or place_meeting(x+X_Jump,y+Y_Jump,Steel)
    {
        if (place_meeting(x,y,Yellow))
        {
            if (score>=2)
            {
                score -= 1
                script_execute(Character_Jump,X_Jump,Y_Jump)
            }
            exit
        }
        else
        {
            script_execute(Character_Jump,X_Jump,Y_Jump)
            exit
        }
    }
}

// Yellow
if (place_meeting(x+X_Jump,y+Y_Jump,Yellow))
{
    if (character_id == 32) with (Mud) if (place_meeting(x-X_Jump,y-Y_Jump,other)) instance_destroy()
    script_execute(Character_Jump,X_Jump,Y_Jump)
    exit
}

// Rock
if ((argument1==1) or (RockTunnle==1)) and (place_meeting(x+X_Jump,y+Y_Jump,Rock))
{
    with (Rock) if (place_meeting(x-X_Jump,y-Y_Jump,other)) instance_change(Yellow,false)
    script_execute(Character_Jump,X_Jump,Y_Jump)
    exit
}

// Dimond
if ((argument2==1) or (DimondTunnle==1)) and (place_meeting(x+X_Jump,y+Y_Jump,Dimond))
{
    with (Dimond) if (place_meeting(x-X_Jump,y-Y_Jump,other)) instance_change(Yellow,false)
    script_execute(Character_Jump,X_Jump,Y_Jump)
    exit
}