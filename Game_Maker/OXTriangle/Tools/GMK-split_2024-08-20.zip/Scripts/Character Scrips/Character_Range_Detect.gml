// Character_Range_Detect
// Stefan Grace
// Created: 2018-11-04
// Modified: 2018-11-04
// This script returns weather there is a blue character within range

/* arguments
argument0 = character
    0 - W
    1 - $
    2 - Big W
*/

var character_in_range;
w_in_range = false;
var x_jump;
var y_jump;
var i;
var j;
for (j = 0; j < 4; j+= 1)
{
    switch(j)
    {
        case 0:
            x_jump = 1 * grid_size
            y_jump = 0 * grid_size
            break
        case 1:
            x_jump = 0 * grid_size
            y_jump = 1 * grid_size
            break
        case 2:
            x_jump = -1 * grid_size
            y_jump = 0 * grid_size
            break
        case 3:
            x_jump = 0 * grid_size
            y_jump = -1 * grid_size
            break
    }
    for (i = 1; i <= 5; i += 1)
    {
        if (!place_meeting(x + (x_jump * i), y + (y_jump * i), Yellow))
        {
            i = 6
        }
        var x_offset;
        var y_offset;
        if (x mod grid_size == 0)
        {
            x_offset = 0
        }
        else
        {
            x_offset = -17
        }
        if (y mod grid_size == 0)
        {
            y_offset = 0
        }
        else 
        {
            y_offset = -17
        }
        if (argument0 == 0) // W
        {
            // W in Top Left of Tile
            if (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Red_Blue_W))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Black_Blue_W))
            // W in Top Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Red_Blue_W))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Black_Blue_W))
            // W in Bottom Left of Tile
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_W))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_W))
            // W in Bottom Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_W))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_W))
            {
                character_in_range = true;
            }
        } 
        else if (argument0 == 1) // $
        {
            // $ in Top Left of Tile
            if (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Red_Blue_Dollar_Sign))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Black_Blue_Dollar_Sign))
            // $ in Top Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Red_Blue_Dollar_Sign))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Black_Blue_Dollar_Sign))
            // $ in Bottom Left of Tile
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_Dollar_Sign))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_Dollar_Sign))
            // $ in Bottom Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_Dollar_Sign))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_Dollar_Sign))
            {
                character_in_range = true;
            }/*
            with(Teleport)
            {
                if (place_meeting(x-X_Jump,y-Y_Jump,other))
                {
                    var port_color;
                    var port_side;
                    port_color = color
                    port_side = side
                    with (Teleport)
                    {
                        if (color==port_color and side!=port_side)
                        {
                            if (place_meeting(x, y, Red_Blue_Dollar_Sign) or place_meeting(x, y, Red_Blue_Dollar_Sign)) character_in_range = true;

                        }
                    }
                }
            }*/

        }
        else if (argument0 == 2) // Big W
        {
            // Big W in Top Left of Tile
            if (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Red_Blue_G))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + y_offset, Black_Blue_G))
            // Big W in Top Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Red_Blue_G))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + y_offset, Black_Blue_G))
            // Big W in Bottom Left of Tile
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_G))
            or (place_meeting(x + (x_jump * i) + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_G))
            // Big W in Bottom Right of Tile
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Red_Blue_G))
            or (place_meeting(x + (x_jump * i) + 17 + x_offset, y + (y_jump * i) + 17 + y_offset, Black_Blue_G))
            {
                character_in_range = true;
            }
        }

    }
}
return character_in_range;