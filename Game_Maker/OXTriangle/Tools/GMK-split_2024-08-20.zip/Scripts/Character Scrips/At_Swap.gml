// At_Swap
// Stefan Grace
// Created: 2017-12-19
// Modified: 2017-12-23

if (S_Stuned>0) exit
global.at_swapping = 1
global.message_type = 21
script_execute(Local_Message_Create)
