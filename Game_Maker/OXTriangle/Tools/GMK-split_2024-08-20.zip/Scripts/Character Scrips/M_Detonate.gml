// M_Detonate
// Stefan Grace
// Created: 2016-08-23
// Modified: 2017-12-23
// This script is executed when an M or Nuclear Bomb detonates


if (S_Stuned>0) exit

var Explosion_X;
var Explosion_Y;
Explosion_X = x-(x mod 35)
Explosion_Y = y-(y mod 35)
if (character_id==11) score -= 1
if (!(sound_isplaying(M_Sound))) sound_play(M_Sound)
script_execute(Teleport_Explosion,0)
instance_create(Explosion_X-35,Explosion_Y-35,Explosion)
instance_create(Explosion_X,Explosion_Y-35,Explosion)
instance_create(Explosion_X+35,Explosion_Y-35,Explosion)
instance_create(Explosion_X-35,Explosion_Y,Explosion)
instance_create(Explosion_X,Explosion_Y,Explosion)
instance_create(Explosion_X+35,Explosion_Y,Explosion)
instance_create(Explosion_X-35,Explosion_Y+35,Explosion)
instance_create(Explosion_X,Explosion_Y+35,Explosion)
instance_create(Explosion_X+35,Explosion_Y+35,Explosion)
instance_create(Explosion_X+17,Explosion_Y+17,Explosion_M_Object)

/* UNUSED LINES OF CODE
if (global.game_frozen>0) exit
*/