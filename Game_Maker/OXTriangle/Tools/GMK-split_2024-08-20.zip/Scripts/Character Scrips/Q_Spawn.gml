// Q_Spawn
// Stefan Grace
// Created: 2017-12-21
// Modified: 2020-02-28
// This script makes Q's spawn 4 q's


if (S_Stuned>0) exit

var leftfull;
var topfull;
var rightfull;
var bottomfull;

leftfull = 0
topfull = 0
rightfull = 0
bottomfull = 0

script_execute(Box_Four_Detect,0)
if (boxfull_topleft==1) and (boxfull_topright==1) and (boxfull_bottomleft==1) and (boxfull_bottomright==1) leftfull = 1
script_execute(Box_Four_Place_Full_Clear)

script_execute(Box_Four_Detect,1)
if (boxfull_topleft==1) and (boxfull_topright==1) and (boxfull_bottomleft==1) and (boxfull_bottomright==1) topfull = 1
script_execute(Box_Four_Place_Full_Clear)

script_execute(Box_Four_Detect,2)
if (boxfull_topleft==1) and (boxfull_topright==1) and (boxfull_bottomleft==1) and (boxfull_bottomright==1) rightfull = 1
script_execute(Box_Four_Place_Full_Clear)

script_execute(Box_Four_Detect,3)
if (boxfull_topleft==1) and (boxfull_topright==1) and (boxfull_bottomleft==1) and (boxfull_bottomright==1) bottomfull = 1
script_execute(Box_Four_Place_Full_Clear)

var spawned_q;
spawned_q = 0

if (player==1)
{
    if (Kill+RockTunnle+DimondTunnle==0) // if the Q has just been through an anger
    {
        if(place_meeting(x-grid_size,y,Yellow) and (!place_meeting(x-grid_size,y,Red_G)) and leftfull==0) {instance_create(x-grid_size,y,Red_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y-grid_size,Yellow) and (!place_meeting(x,y-grid_size,Red_G)) and topfull==0) {instance_create(x,y-grid_size,Red_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x+grid_size,y,Yellow) and (!place_meeting(x+grid_size,y,Red_G)) and rightfull==0) {instance_create(x+grid_size,y,Red_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y+grid_size,Yellow) and (!place_meeting(x,y+grid_size,Red_G)) and bottomfull==0) {instance_create(x,y+grid_size,Red_Lowercase_Q); spawned_q += 1}
    }
    else 
    {
        if(place_meeting(x-grid_size,y,Yellow) and (!place_meeting(x-grid_size,y,Red_G)) and leftfull==0) {instance_create(x-grid_size,y,Red_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y-grid_size,Yellow) and (!place_meeting(x,y-grid_size,Red_G)) and topfull==0) {instance_create(x,y-grid_size,Red_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x+grid_size,y,Yellow) and (!place_meeting(x+grid_size,y,Red_G)) and rightfull==0) {instance_create(x+grid_size,y,Red_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y+grid_size,Yellow) and (!place_meeting(x,y+grid_size,Red_G)) and bottomfull==0) {instance_create(x,y+grid_size,Red_Stuned_Lowercase_Q); spawned_q += 1}
    }
}
else if (player==2)
{
    if (Kill+RockTunnle+DimondTunnle==0) // if the Q has just been through an anger
    {
        if(place_meeting(x-grid_size,y,Yellow) and (!place_meeting(x-grid_size,y,Red_G)) and leftfull==0) {instance_create(x-grid_size,y,Black_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y-grid_size,Yellow) and (!place_meeting(x,y-grid_size,Red_G)) and topfull==0) {instance_create(x,y-grid_size,Black_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x+grid_size,y,Yellow) and (!place_meeting(x+grid_size,y,Red_G)) and rightfull==0) {instance_create(x+grid_size,y,Black_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y+grid_size,Yellow) and (!place_meeting(x,y+grid_size,Red_G)) and bottomfull==0) {instance_create(x,y+grid_size,Black_Lowercase_Q); spawned_q += 1}
    }
    else 
    {
        if(place_meeting(x-grid_size,y,Yellow) and (!place_meeting(x-grid_size,y,Red_G)) and leftfull==0) {instance_create(x-grid_size,y,Black_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y-grid_size,Yellow) and (!place_meeting(x,y-grid_size,Red_G)) and topfull==0) {instance_create(x,y-grid_size,Black_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x+grid_size,y,Yellow) and (!place_meeting(x+grid_size,y,Red_G)) and rightfull==0) {instance_create(x+grid_size,y,Black_Stuned_Lowercase_Q); spawned_q += 1}
        if(place_meeting(x,y+grid_size,Yellow) and (!place_meeting(x,y+grid_size,Red_G)) and bottomfull==0) {instance_create(x,y+grid_size,Black_Stuned_Lowercase_Q); spawned_q += 1}
    }
}

return spawned_q