// J_Detonate
// Stefan Grace
// Created: 2017-08-10
// Modified: 2020-02-15
// This script is executed when a J or J Bomb detonates

if (S_Stuned>0) exit

var explosion_x;
var explosion_y;
explosion_x = x-(x mod 35)
explosion_y = y-(y mod 35)
if (character_id==18) score -= 1
if (!(sound_isplaying(J_Sound))) sound_play(J_Sound)
script_execute(Teleport_Explosion,1)
var x_amount;
var y_amount;
var amount;
var i;
amount = grid_size
x_amount = -1*grid_size
y_amount = 0
repeat(2) // This repeat loop makes the horizontal line
{
    for(i=0; i<36; i+=1)
    {
        x_amount += amount
        if (x_amount + explosion_x < grid_size or x_amount + explosion_x > 36 * grid_size) break // Stops J explosion from blowing up off the edge horizontaly
        instance_create(explosion_x+x_amount,explosion_y,Explosion)
        instance_create(explosion_x+x_amount,explosion_y,Explosion_J_Horizontal_Object)
        with (Concreet) if (place_meeting(x+(0-amount),y,Explosion_J_Horizontal_Object)) i = 36
    }
    amount = -1*grid_size
    x_amount = 0
}
amount = grid_size
repeat(2) // This repeat loop makes the vertical line
{
    for(i=0; i<36; i+=1)
    {
        y_amount += amount
        if (y_amount + explosion_y < grid_size or y_amount + explosion_y > 20 * grid_size) break // Stops J explosion from blowing up off the edge verticaly
        instance_create(explosion_x,explosion_y+y_amount,Explosion)
        instance_create(explosion_x,explosion_y+y_amount,Explosion_J_Vertical_Object)
        with (Concreet) if (place_meeting(x,y+(0-amount),Explosion_J_Vertical_Object)) i = 36
    }
    amount = -1*grid_size
    y_amount = 0
}
instance_create(explosion_x,explosion_y+y_amount,Explosion_J_Vertical_Object)
