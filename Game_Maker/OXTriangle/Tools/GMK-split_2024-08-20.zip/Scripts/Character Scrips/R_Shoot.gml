// R_Shoot
// Stefan Grace
// Created: 2016-07-21
// Modified: 2024-07-28
// This script makes the R fire an arrow when the control key is held down

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
*/


var something_to_shoot;
var i;
var k;
var x_skip;
var y_skip;
var material_in_the_way;

if (global.game_frozen>0) exit
if keyboard_check(vk_control) || global.tablet_function_button_active || joystick_check_button(0, 1)
{
    if (S_Stuned>0)
    {
        show_message(global.text_r_stun)
        exit
    }
    if (argument0==0) 
    {
        x_skip = grid_size
        y_skip = 0
    }
    else if (argument0==1)
    {
        x_skip = 0
        y_skip = grid_size
    }
    else if (argument0==2)
    {
        x_skip = grid_size * -1
        y_skip = 0
    }
    else 
    {
        x_skip = 0
        y_skip = grid_size * -1
    }
    if (instance_number(Go_Number_Black)>0)
    {
        with(all) 
        {
            if (player==1)
            {
                for (i = 1; i<=5; i += 1)
                {
                    if (x - (x mod grid_size) == (other.x - (other.x mod grid_size)) - (x_skip * i) and y - (y mod grid_size) == (other.y - (other.y mod grid_size)) - (y_skip * i))
                    {
                        for (j = 0; j<=i; j +=1)
                        {
                             if (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Rock)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Dimond)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Concreet)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Double_Boxing)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Mud))
                             {
                                material_in_the_way = true;
                             }
                        }
                        if (!material_in_the_way) something_to_shoot = true;
                    }
                }
            }
        }
    } 
    else
    {
        with(all) 
        {
            if (player==2)
            {
                for (i = 1; i<=5; i += 1)
                {
                    if (x - (x mod grid_size) == (other.x - (other.x mod grid_size)) - (x_skip * i) and y - (y mod grid_size) == (other.y - (other.y mod grid_size)) - (y_skip * i))
                    {
                        for (j = 0; j<=i; j +=1)
                        {
                             if (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Rock)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Dimond)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Concreet)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Double_Boxing)) 
                             or (place_meeting((x - (x mod grid_size)) + (j * x_skip), (y - (y mod grid_size)) + (j * y_skip), Mud))
                             {
                                material_in_the_way = true;
                             }
                        }
                        if (!material_in_the_way) something_to_shoot = true;
                    }
                }
            }
        }
    }
    if (!something_to_shoot) exit
    global.R_Arrow_Point = argument0
    instance_create(x+(17 - x mod 35),y+(17 - y mod 35),R_Arrow)
    instance_create(x+(17 - x mod 35),y+(17 - y mod 35),R_Arrow_Mask)
    sound_play(R_Sound)
    score -= 1
}
else script_execute(Character_Move,argument0)