// Character_Type
// Stefan Grace
// Created: 2017-09-02
// Modified: 2017-09-02
// This script sets the player and state of a character based on the type

/* arguments

    argument0 - type
        0 - Red Stuned
        1 - Red
        2 - Red Blue
        3 - Black Stuned
        4 - Black
        5 - Black Blue
        6 - Green
*/

/* variables

    type
        0 - Red Stuned
        1 - Red
        2 - Red Blue                
        3 - Black Stuned
        4 - Black
        5 - Black Blue
        6 - Green
        
    player 
        1 - Player 1 (Red)
        2 - Player 2 (Black)
        3 - Neutral (Green)
        
    state
        1 - Stuned
        2 - None
        3 - Blue
*/

// type
type = argument0

// player
if (argument0<=2) player = 1
if (argument0>=3 and argument0<=5) player = 2
if (argument0==6) player = 3

// state
if (argument0==0 or argument0==3) state = 1
if (argument0==1 or argument0==4) state = 2
if (argument0==2 or argument0==5) state = 3
        