if (place_snapped(35,y)) x += 17
else 
{
    x -= 17
    y += 17
}