// Key_Mash_Detect
// Stefan Grace
// Created: 2020-02-24
// Modified: 2020-02-24
// This script detects if 2 arrow keys are being pressed at the same time

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
*/

switch(argument0)
{
    case 0: 
        if (keyboard_check(vk_up) or keyboard_check(vk_right) or keyboard_check(vk_down)) return true
        break
    case 1: 
        if (keyboard_check(vk_left) or keyboard_check(vk_right) or keyboard_check(vk_down)) return true
        break
    case 2: 
        if (keyboard_check(vk_up) or keyboard_check(vk_left) or keyboard_check(vk_down)) return true
        break
    case 3: 
        if (keyboard_check(vk_up) or keyboard_check(vk_right) or keyboard_check(vk_left)) return true
        break
}
if (keyboard_check(vk_left) or keyboard_check(vk_up) or keyboard_check(vk_right) or keyboard_check(vk_down))
and (keyboard_check(ord("A")) or keyboard_check(ord("W")) or keyboard_check(ord("D")) or keyboard_check(ord("S")))
{
    return true
}

return false
