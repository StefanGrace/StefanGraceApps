// Character_Click_Black
// Stefan Grace
// Created: 2016-07-05
// Modified: 2020-02-21
// This scrip makes any other selected charater become unselected when Player 2 clicks on a character

if (instance_number(Level_Cover) > 0) exit

if (global.levelnumber == 0)
{
    if (global.level0messagenumber >= 6 and !global.black_level_0_message_7_hasbeenshown)
    {
        with (Message_Object) instance_destroy()
        global.level0messagenumber = 7
        global.message_type = 57
        instance_create(70, 70, Message_Object)
        global.black_level_0_message_7_hasbeenshown = true
    }
}

if (global.dollar_sign_stunning != 0) // Cancel the $ stun if the player click on another one of their own characters
{
    global.dollar_sign_stunning = 0 
    with (Message_Object) instance_destroy()
}

if (global.big_w_life_draining) // Cancel the Big W life drian if the player click on another one of their own characters
{
    global.big_w_life_draining = false;
    with (Message_Object) instance_destroy()
}

if (global.big_w_life_giving) // Cancel the Big W life give if the player click on another one of their own characters
{
    global.big_w_life_giving = false;
    with (Message_Object) instance_destroy()
}

if (global.w_casting)
{
    if (S_Stuned > 0 and W_Range_Detect()) 
    {    
        S_Stuned = 0 
        score -= 1
    }
    else if (character_id == 13 and g_hit < Get_Max_Hits(g_type) and W_Range_Detect())
    {
        g_hit += 1
        score -= 1 
    }
    exit
}

if (global.Black_B_Killing_Left+global.Black_B_Killing_Up+global.Black_B_Killing_Right+global.Black_B_Killing_Down) exit

if (global.at_swapping == 0)
{
    
    with(Black_Blue_O) instance_change(Black_O,false)
    with(Black_Blue_X) instance_change(Black_X,false)
    with(Black_Blue_Triangle) instance_change(Black_Triangle,false)
    with(Black_Blue_A) instance_change(Black_A,false)
    with(Black_Blue_Square) instance_change(Black_Square,false)
    with(Black_Blue_K) instance_change(Black_K,false)
    with(Black_Blue_B) instance_change(Black_B,false)
    with(Black_Blue_E) instance_change(Black_E,false)
    with(Black_Blue_S) instance_change(Black_S,false)
    with(Black_Blue_H) instance_change(Black_H,false)
    with(Black_Blue_R) instance_change(Black_R,false)
    with(Black_Blue_M) instance_change(Black_M,false)
    with(Black_Blue_F) instance_change(Black_F,false)
    with(Black_Blue_G) instance_change(Black_G,false)
    with(Black_Blue_C) instance_change(Black_C,false)
    with(Black_Blue_Y) instance_change(Black_Y,false)
    with(Black_Blue_Z) instance_change(Black_Z,false)
    with(Black_Blue_W) instance_change(Black_W,false)
    with(Black_Blue_J) instance_change(Black_J,false)
    with(Black_Blue_V) instance_change(Black_V,false)
    with(Black_Blue_P) instance_change(Black_P,false)
    with(Black_Blue_T) instance_change(Black_T,false)
    with(Black_Blue_D) instance_change(Black_D,false)
    with(Black_Blue_Q) instance_change(Black_Q,false)
    with(Black_Blue_N) instance_change(Black_N,false)
    with(Black_Blue_Question_Mark) instance_change(Black_Question_Mark,false)
    with(Black_Blue_U) instance_change(Black_U,false)
    with(Black_Blue_L) instance_change(Black_L,false)
    with(Black_Blue_Dollar_Sign) instance_change(Black_Dollar_Sign,false)
    with(Black_Blue_At) instance_change(Black_At,false)
    with(Black_Blue_Pi) instance_change(Black_Pi,false)
    with(Black_Blue_I) instance_change(Black_I,false)
    with(Black_Blue_Lowercase_Q) instance_change(Black_Lowercase_Q,false)
}
else 
{ 
    if (character_id == 13 and (g_type == 1 or g_type == 2)) 
    {
        show_message(global.text_at_not_swap_big_g)
        exit
    }
    var x_temp;
    var y_temp;
    x_temp = x
    y_temp = y
    if (character_id==31) with(Concreet) if (place_meeting(x,y,other)) instance_change(Yellow,false)
    x = Black_Blue_At.x
    y = Black_Blue_At.y
    Black_Blue_At.x = x_temp
    Black_Blue_At.y = y_temp
    move_snap(grid_size,grid_size)
    if (character_id==13) {g_hit += 1; instance_create(x,y,Explosion)}
    if (character_id==31) with(Yellow) if (place_meeting(x,y,other)) instance_change(Concreet,false)
    score -= 2
    with(Message_Object) instance_destroy()
    Level_Number_Object.alarm[0] = 1 
}

