if (!(place_meeting(x,y,Red_Anger) or place_meeting(x,y,Orange_Anger) or place_meeting(x,y,Blue_Anger) or place_meeting(x,y,Purple_Anger) or place_meeting(x,y,Teleport)))
{
    if (character_id==22) with(Yellow) if (place_meeting(x,y,other)) instance_change(Dimond,false)
    if (character_id==32) with(Yellow) if (place_meeting(x,y,other)) instance_create(x-(x mod grid_size),y-(y mod grid_size),Mud)
}
x += argument0
y += argument1
move_snap(35,35)
score -= 1