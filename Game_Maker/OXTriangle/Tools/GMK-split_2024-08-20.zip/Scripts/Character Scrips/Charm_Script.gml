// Charm_Script
// Stefan Grace
// Created: 2017-08-04
// Modified: 2017-12-21
// This scipt makes F's charm characters

/* arguments

argument0
    0 - Blue_Charm_Stuned
    1 - Stuned_Charm_Blue
*/

// Black
if (instance_number(Go_Number_Black)>0 and argument0==0) or (instance_number(Go_Number_Red)>0 and argument0==1) 
{
    if (argument0==1) script_execute(Auto_Stack)
    if (character_id==0) instance_change(Black_O,true)
    if (character_id==1) instance_change(Black_X,true)
    if (character_id==2) instance_change(Black_Triangle,true)
    if (character_id==3) instance_change(Black_A,true)
    if (character_id==4) instance_change(Black_Square,true)
    if (character_id==5) instance_change(Black_K,true)
    if (character_id==6) instance_change(Black_B,true)
    if (character_id==7) instance_change(Black_E,true)
    if (character_id==8) instance_change(Black_S,true)
    if (character_id==9) instance_change(Black_H,true)
    if (character_id==10) instance_change(Black_R,true)
    if (character_id==11) instance_change(Black_M,true)
    if (character_id==12) instance_change(Black_F,true)
    if (character_id==14) instance_change(Black_C,true)
    if (character_id==15) instance_change(Black_Y,true)
    if (character_id==16) instance_change(Black_Z,true)
    if (character_id==17) instance_change(Black_W,true)
    if (character_id==18) instance_change(Black_J,true)
    if (character_id==19) instance_change(Black_V,true)
    if (character_id==20) instance_change(Black_P,true)
    if (character_id==21) instance_change(Black_T,true)
    if (character_id==22) instance_change(Black_D,true)
    if (character_id==23) instance_change(Black_Q,true)
    if (character_id==24) instance_change(Black_N,true)
    if (character_id==26) instance_change(Black_Question_Mark,true)
    if (character_id==27) instance_change(Black_U,true)
    if (character_id==28) instance_change(Black_L,true)
    if (character_id==29) instance_change(Black_Dollar_Sign,true)
    if (character_id==30) instance_change(Black_At,true)
    if (character_id==32) instance_change(Black_I,true)
    if (character_id==100) instance_change(Black_Lowercase_Q,true)
    if (global.anger>0) script_execute(Black_Stun)
}

// Red
if (instance_number(Go_Number_Red)>0 and argument0==0) or (instance_number(Go_Number_Black)>0 and argument0==1)
{
    if (argument0==1) script_execute(Auto_Stack)
    if (character_id==0) instance_change(Red_O,true)
    if (character_id==1) instance_change(Red_X,true)
    if (character_id==2) instance_change(Red_Triangle,true)
    if (character_id==3) instance_change(Red_A,true)
    if (character_id==4) instance_change(Red_Square,true)
    if (character_id==5) instance_change(Red_K,true)
    if (character_id==6) instance_change(Red_B,true)
    if (character_id==7) instance_change(Red_E,true)
    if (character_id==8) instance_change(Red_S,true)
    if (character_id==9) instance_change(Red_H,true)
    if (character_id==10) instance_change(Red_R,true)
    if (character_id==11) instance_change(Red_M,true)
    if (character_id==12) instance_change(Red_F,true)
    if (character_id==14) instance_change(Red_C,true)
    if (character_id==15) instance_change(Red_Y,true)
    if (character_id==16) instance_change(Red_Z,true)
    if (character_id==17) instance_change(Red_W,true)
    if (character_id==18) instance_change(Red_J,true)
    if (character_id==19) instance_change(Red_V,true)
    if (character_id==20) instance_change(Red_P,true)
    if (character_id==21) instance_change(Red_T,true)
    if (character_id==22) instance_change(Red_D,true)
    if (character_id==23) instance_change(Red_Q,true)
    if (character_id==24) instance_change(Red_N,true)
    if (character_id==26) instance_change(Red_Question_Mark,true)
    if (character_id==27) instance_change(Red_U,true)
    if (character_id==28) instance_change(Red_L,true)
    if (character_id==29) instance_change(Red_Dollar_Sign,true)
    if (character_id==30) instance_change(Red_At,true)
    if (character_id==32) instance_change(Red_I,true)
    if (character_id==100) instance_change(Red_Lowercase_Q,true)
    if (global.anger>0) script_execute(Red_Stun)
}
