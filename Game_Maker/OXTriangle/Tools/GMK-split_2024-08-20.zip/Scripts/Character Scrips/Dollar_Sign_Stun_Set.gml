// Dollar_Sign_Set
// Stefan Grace
// Created: 2017-12-23
// Modified: 2017-12-23

if (S_Stuned>0) exit 
global.dollar_sign_stunning = 1
global.message_type = 23
script_execute(Local_Message_Create)
