// Character_Jump_Double_Boxing
// Stefan Grace
// Created: 2016-08-10
// Modified: 2017-12-14
// This script moves characters in Double Boxing

/* aruguments

argument0 = X Jump

argument1 = Y Jump

argument2 = Rock Tunnle
    0 = No
    1 = Yes

argument3 = Dimond Tunnle
    0 = No
    1 = Yes
*/


// D and I
if (!(place_meeting(x,y,Red_Anger) or place_meeting(x,y,Orange_Anger) or place_meeting(x,y,Blue_Anger) or place_meeting(x,y,Purple_Anger) or place_meeting(x,y,Teleport)))
{
    if (character_id==22) with(Yellow) if (place_meeting(x,y,other)) instance_change(Dimond,false)
    if (character_id==32) with(Yellow) if (place_meeting(x,y,other)) instance_create(x-(x mod grid_size),y-(y mod grid_size),Mud)
}

// Yellow
if (place_meeting(x+argument0,y+argument1,Double_Boxing_Yellow))
{
    script_execute(Character_Move_Double_Boxing,argument0,argument1)
    exit
}

// Rock
if ((argument2>0) or (RockTunnle==1)) and (place_meeting(x+argument0,y+argument1,Double_Boxing_Rock))
{
    script_execute(Character_Move_Double_Boxing,argument0,argument1)
    exit
}

// Dimond
if ((argument3>0) or (DimondTunnle==1)) and (place_meeting(x+argument0,y+argument1,Double_Boxing_Dimond))
{
    script_execute(Character_Move_Double_Boxing,argument0,argument1)
    exit
}