// Auto_Stack_Detect_Black
// Stefan Grace
// Created: 2017-07-24
// Modified: 2017-12-12

with(all) 
{
    if (player==2)
    {
        if(place_meeting(x,y,other) and character_id!=13)
        {
            with(other) script_execute(Auto_Stack)
        }
    }
}