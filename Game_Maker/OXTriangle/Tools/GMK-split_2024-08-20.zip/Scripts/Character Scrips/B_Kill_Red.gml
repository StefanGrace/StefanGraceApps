// B_Kill_Red
// Stefan Grace
// Created: 2016-07-20
// Modified: 2020-02-23
// This script is executed when a Red B infiltrates a Red box of 4 or when a Red $ casts an AOE stun on a Red Character


if (global.Red_B_Killing_Left>0)
{
    if (B_Detect())
    {
        global.Red_B_Killing_Left = 0
        with(Message_Object) instance_destroy()
        with(Red_Blue_B) alarm[1] = 1
        instance_destroy()
    }
}

if (global.Red_B_Killing_Up>0)
{
    if (B_Detect())
    {
        global.Red_B_Killing_Up = 0
        with(Message_Object) instance_destroy()
        with(Red_Blue_B) alarm[2] = 1
        instance_destroy()
    }
}

if (global.Red_B_Killing_Right>0)
{
    if (B_Detect())
    {
        global.Red_B_Killing_Right = 0
        with(Message_Object) instance_destroy()
        with(Red_Blue_B) alarm[3] = 1
        instance_destroy()
    }
}

if (global.Red_B_Killing_Down>0)
{
    if (B_Detect())
    {
        global.Red_B_Killing_Down = 0
        with(Message_Object) instance_destroy()
        with(Red_Blue_B) alarm[4] = 1
        instance_destroy()
    }
}

if (global.dollar_sign_stunning>0 and Dollar_Sign_Range_Detect()) script_execute(Dollar_Sign_Stun_Create,2)