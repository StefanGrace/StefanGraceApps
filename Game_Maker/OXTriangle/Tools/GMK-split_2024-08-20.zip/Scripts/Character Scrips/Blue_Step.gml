// Blue_Step
// Stefan Grace
// Created: 2017-07-24
// Modified: 2020-02-12
// This script is executed on blue (selected) characters every step

// Kills the character if it shoud be killed
if (to_be_killed) instance_destroy()

// Clears the anger atrributes from a character at the end of the turn
if (score<1) alarm[0] = 2

// Makes the character get crushed by a boulder
if (place_meeting(x,y,Boulder)) 
{
    if (character_id!=15) 
    {
        script_execute(Boulder_Crush_Blue) 
    }
    else
    {
        with (Boulder)
        {
            if (place_meeting(x,y,other)) instance_destroy()
        }
    }
}

// Controlls the auto stack
if (instance_number(Go_Number_Black)>0)
{
    repeat(4) script_execute(Auto_Stack_Detect_Black)
    script_execute(Auto_Stack_Detect_Red)
}
if (instance_number(Go_Number_Red)>0)
{
    repeat(4) script_execute(Auto_Stack_Detect_Red)
    script_execute(Auto_Stack_Detect_Black)
}

// Makes blue character interact with opponent's G or Big W in other side of teleport
if (place_meeting(x,y,Teleport))
{
    with (Teleport)
    {
        if (place_meeting(x,y,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    if (instance_number(Go_Number_Black)>0 and place_meeting(x,y,Red_Stuned_G)) 
                    {
                        with (Black_Blue_X) 
                        {
                            if (character_id==1)
                            or (character_id==2)
                            or (character_id==3)
                            or (character_id==7)
                            or (character_id==9)
                            or (character_id==14)
                            or (character_id==20)
                            or (Kill>0)
                            {
                                with(Red_Stuned_G) Blue_Attack_G_Teleport(false, port_color)
                            }
                            else if (character_id==8)
                            {
                                with(Red_Stuned_G) Blue_Attack_G_Teleport(true, port_color)
                            }
                            instance_destroy()
                        }
                        
                    }
                    else if (instance_number(Go_Number_Red)>0 and place_meeting(x,y,Black_Stuned_G)) 
                    {
                        with (Red_Blue) 
                        {
                            if (character_id==1)
                            or (character_id==2)
                            or (character_id==3)
                            or (character_id==7)
                            or (character_id==9)
                            or (character_id==14)
                            or (character_id==20)
                            or (Kill>0)
                            {
                                with(Black_Stuned_G) Blue_Attack_G_Teleport(false, port_color)
                            }
                            else if (character_id==8)
                            {
                                with(Black_Stuned_G) Blue_Attack_G_Teleport(true, port_color)
                            }
                            instance_destroy()
                        }
                    }
                }
            }
        }
    }
}

// Makes the character interact with a G
if (place_meeting(x,y,Red_Stuned_G))
{
    if (instance_number(Go_Number_Black)>0)
    {
        if (character_id==1)
        or (character_id==2)
        or (character_id==3)
        or (character_id==7)
        or (character_id==9)
        or (character_id==14)
        or (character_id==20)
        or (Kill>0)
        {
            with(Red_Stuned_G)
            {
                Blue_Attack_G(false)
            }
        }
        else if (character_id==8)
        {
            with(Red_Stuned_G)
            {
                Blue_Attack_G(true)
            }
        }
    }
    instance_destroy()
}  
else if (place_meeting(x,y,Black_Stuned_G))
{
    if (instance_number(Go_Number_Red)>0)
    {
        if (character_id==1)
        or (character_id==2)
        or (character_id==3)
        or (character_id==7)
        or (character_id==9)
        or (character_id==14)
        or (character_id==20)
        or (Kill>0)
            with(Black_Stuned_G)
            {
                Blue_Attack_G(false)
            }
        else if (character_id==8)
            with(Black_Stuned_G)
            {
                Blue_Attack_G(true)
            }
    }
    instance_destroy()
}  
if (place_meeting(x,y,Black_G) or place_meeting(x,y,Red_G)) instance_destroy()