// C_Catapult 
// Stefan Grace
// Created: 2017-08-04
// Modified: 2024-07-28
// This script makes the C catapult a boulder and N catapult nuclear bomb when the control key is held down


if (global.game_frozen>0) exit
if keyboard_check(vk_control) || global.tablet_function_button_active || joystick_check_button(0, 1)
{
    if (S_Stuned>0)
    {
        show_message(global.text_c_stun)
        exit
    }
    var catapult_sqaures;
    if (argument0==0) catapult_sqaures = -5
    if (argument0==2) catapult_sqaures = 5
    if place_meeting(x+(catapult_sqaures*grid_size),y,Yellow) and (!(place_meeting(x+(catapult_sqaures*grid_size),y,Boulder)))
    and (!(place_meeting(x+((catapult_sqaures*grid_size)*(1/5)),y,Concreet)))
    and (!(place_meeting(x+((catapult_sqaures*grid_size)*(2/5)),y,Concreet)))
    and (!(place_meeting(x+((catapult_sqaures*grid_size)*(3/5)),y,Concreet)))
    and (!(place_meeting(x+((catapult_sqaures*grid_size)*(4/5)),y,Concreet)))
    {
        if (character_id==24) instance_create((x-(x mod grid_size))+(catapult_sqaures*grid_size),y+(y mod grid_size),Nuclear_Bomb_Object)
        instance_create((x-(x mod grid_size))+(catapult_sqaures*grid_size),y+(y mod grid_size),Boulder)
        score -= 1
        with (Boulder) if place_meeting(x-(catapult_sqaures*grid_size),y,other) catapulted = 1
    }
}
else script_execute(Character_Move,argument0)