// B_Detect
// Stefan Grace
// Created: 2020-02-19
// Modified: 2020-02-25
// This scrip detects if the is a B in range that is infiltrating a box of 4

var b_place_x b_place_y;
if (global.Black_B_Killing_Left+global.Red_B_Killing_Left>0)
{
    b_place_x = grid_size
    b_place_y = 0
}
else if (global.Black_B_Killing_Up+global.Red_B_Killing_Up>0)
{
    b_place_x = 0
    b_place_y = grid_size
}
else if (global.Black_B_Killing_Right+global.Red_B_Killing_Right>0)
{
    b_place_x = 0-grid_size
    b_place_y = 0
}
else if (global.Black_B_Killing_Down+global.Red_B_Killing_Down>0)
{
    b_place_x = 0
    b_place_y = 0-grid_size
}
else
{
    return false
}

if (place_meeting(x,y,Teleport))
{
     with (Teleport)
     {
        if (place_meeting(x,y,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    if (instance_number(Go_Number_Black)>0)
                    {
                        if (place_meeting(x + b_place_x, y + b_place_y, Black_Blue_B)) return true
                    }
                    if (instance_number(Go_Number_Red)>0)
                    {
                        if (place_meeting(x + b_place_x, y + b_place_y, Red_Blue_B)) return true
                    }
                }
            }
        }
    }
}

if (instance_number(Go_Number_Black)>0)
{
    return ((x - (x mod grid_size)) + b_place_x == Black_Blue_B.x - (Black_Blue_B.x mod grid_size) and (y - (y mod grid_size)) + b_place_y == Black_Blue_B.y - (Black_Blue_B.y mod grid_size))
}

if (instance_number(Go_Number_Red)>0)
{
    return ((x - (x mod grid_size)) + b_place_x == Red_Blue_B.x - (Red_Blue_B.x mod grid_size) and (y - (y mod grid_size)) + b_place_y == Red_Blue_B.y - (Red_Blue_B.y mod grid_size))
}

