// Boulder_Crush_Blue
// Stefan Grace
// Created: 2016-07-05
// Modified: 2024-07-29
// This script kills the selected (blue) character when a boulder falls on it

if (!(keyboard_check(vk_left) || keyboard_check(ord("A")) || (keyboard_check(vk_right) || keyboard_check(ord("D")) 
|| Tablet_UI_Left_Button.clicked || Tablet_UI_Right_Button.clicked ||abs(joystick_xpos(0)) > 0.1)))
{
    instance_destroy()
}