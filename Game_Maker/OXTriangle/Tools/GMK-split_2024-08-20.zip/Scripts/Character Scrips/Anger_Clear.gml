Kill = 0
RockTunnle = 0
DimondTunnle = 0