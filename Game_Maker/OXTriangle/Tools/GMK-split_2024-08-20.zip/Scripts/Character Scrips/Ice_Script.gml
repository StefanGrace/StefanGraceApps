// Ice_Script
// Stefan Grace
// Created: 2017-07-16
// Modified: 2017-07-16
// This script makes an icy looking box apear round a character when it is stunded by an 'S'

if (S_Stuned>0) draw_sprite(Ice,0,x,y) 
if(argument0==0) draw_sprite(Black_X_Sprite,0,x,y)
