// Dollar_Sign_Range_Detect
// Stefan Grace
// Created: 2018-10-31
// Modified: 2018-10-31
// This script returns weather there is a blue $ within range

return Character_Range_Detect(1)