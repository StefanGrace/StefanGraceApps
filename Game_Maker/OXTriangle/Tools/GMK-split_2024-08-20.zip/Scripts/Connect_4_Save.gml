// Connect_4_Save
// Stefan Grace
// Created: 2024-07-25
// Modified: 2024-07-26
// This script saves the Connect 4 data to a TXT file

// Generate level data text with a line for each row
var level_text;
var i;
for (i = 0; i < room_height; i += grid_size)
{
    level_text[i / grid_size] = "";
    var j;
    for (j = grid_size; j < room_width - 1; j += grid_size)
    {
        var tile_letter;
        tile_letter = "."
        with(Connect_4_X)
        {
            if (x == j and y == i) {tile_letter = "R"}
        }
        with(Connect_4_O)
        {
            if (x == j and y == i) {tile_letter = "B"}
        }
        with(Connect_4_X_Yellow)
        {
            if (x == j and y == i) {tile_letter = "r"}
        }
        with(Connect_4_O_Yellow)
        {
            if (x == j and y == i) {tile_letter = "b"}
        }
        level_text[i / grid_size] += tile_letter
    }
}

// Save player turn and points
var turn_points_text;
if (instance_number(Connect_4_P1_Turn) > 0) 
{
    turn_points_text = "1"
}
else if (instance_number(Connect_4_P2_Turn) > 0)
{
    turn_points_text = "2"
}
else
{
    exit
}

turn_points_text += string(global.Player_One_Lines)
turn_points_text += string(global.Player_Two_Lines)
turn_points_text += string(global.level16messagenumber)
turn_points_text += string(global.level16message2hasshown)

// Save lines
var red_v_lines_text;
red_v_lines_text = ""
with (Red_Vertical_Line)
{
    red_v_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    red_v_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var red_h_lines_text;
red_h_lines_text = ""
with (Red_Horizontal_Line)
{
    red_h_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    red_h_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var red_tlbr_lines_text;
red_tlbr_lines_text = ""
with (Red_Diagonal_Line_TL_BR)
{
    red_tlbr_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    red_tlbr_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var red_trbl_lines_text;
red_trbl_lines_text = ""
with (Red_Diagonal_Line_TR_BL)
{
    red_trbl_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    red_trbl_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var black_v_lines_text;
black_v_lines_text = ""
with (Black_Vertical_Line)
{
    black_v_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    black_v_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var black_h_lines_text;
black_h_lines_text = ""
with (Black_Horizontal_Line)
{
    black_h_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    black_h_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var black_tlbr_lines_text;
black_tlbr_lines_text = ""
with (Black_Diagonal_Line_TL_BR)
{
    black_tlbr_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    black_tlbr_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}

var black_trbl_lines_text;
black_trbl_lines_text = ""
with (Black_Diagonal_Line_TR_BL)
{
    black_trbl_lines_text += string_replace_all(string_format(x, 4, 0)," ", "0")
    black_trbl_lines_text += string_replace_all(string_format(y, 4, 0)," ", "0")
}


// Pick file name
var file_path, lvl_num_text;
lvl_num_text = string_replace_all(string_format(global.levelnumber, 2, 0), " ", "0")
file_path = working_directory + "\Saves\Level_" + lvl_num_text + ".txt"

// Check that file is not read-only
if (file_attributes(file_path, fa_readonly)) {exit}

// Blank the file first    
var file;
file = file_text_open_write(file_path)
file_text_write_string(file, "")
file_text_close(file)

// Write level data text to file    
file = file_text_open_append(file_path)
var i;
for (i = 0; i < 22; i += 1) 
{
   file_text_write_string(file, level_text[i])
   file_text_writeln(file)
}
file_text_write_string(file, turn_points_text)
file_text_writeln(file)
file_text_write_string(file, red_v_lines_text)
file_text_writeln(file)
file_text_write_string(file, red_h_lines_text)
file_text_writeln(file)
file_text_write_string(file, red_tlbr_lines_text)
file_text_writeln(file)
file_text_write_string(file, red_trbl_lines_text)
file_text_writeln(file)
file_text_write_string(file, black_v_lines_text)
file_text_writeln(file)
file_text_write_string(file, black_h_lines_text)
file_text_writeln(file)
file_text_write_string(file, black_tlbr_lines_text)
file_text_writeln(file)
file_text_write_string(file, black_trbl_lines_text)
file_text_close(file)
