// Player_One_Select_Script
// Stefan Grace
// Created: 2016-07-19
// Modified: 2019-04-04
// This script is executed when Player 1 is selected to start the level 

script_execute(Red_Unstun)
script_execute(Player_Select_Script)
instance_create(0,0,Go_Number_Red)
instance_create(1120,0,Draw_Mode_Red)
if (global.levelnumber == 0) script_execute(Level_0_Intro, 1)