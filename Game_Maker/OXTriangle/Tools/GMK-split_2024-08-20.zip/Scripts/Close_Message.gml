if global.levelnumber==12 and global.level12messagenumber==0
{
    global.message_type = 30
    global.level12messagenumber = 1
    Move_Message.x = 490
    Move_Message.y = 175
    exit
}

if global.levelnumber==0 
{
    if (global.level0messagenumber==0)
    {
        global.level0messagenumber = 1
        global.message_type = 50
        Move_Message.x = 875
        Move_Message.y = 560
        exit
    }
    else if (global.level0messagenumber==1)
    {
        global.level0messagenumber = 2
        global.message_type = 51
        Move_Message.x = 70
        Move_Message.y = 70
        exit
    }
    else if (global.level0messagenumber==2)
    {
        global.level0messagenumber = 3
        global.message_type = 52
        Move_Message.x = 385
        Move_Message.y = 120
        exit
    }
    else if (global.level0messagenumber==3)
    {
        global.level0messagenumber = 4
        global.message_type = 53
        exit
    }
    else if (global.level0messagenumber==4)
    {
        global.level0messagenumber = 5
        global.message_type = 54
        exit
        
    }
    else if (global.level0messagenumber==5)
    {
        global.level0messagenumber = 6
        global.message_type = 55
        Move_Message.x = 490
        Move_Message.y = 70
        instance_create(315,0,Player_One_Select)
        instance_create(455,0,Player_Select)
        instance_create(875,0,Player_Two_Select)
        instance_create(1190,0,Player_Random)
        exit
    }/*
    else if (global.level0messagenumber==7)
    {
        global.level0messagenumber = 3
        global.message_type = 52
        Move_Message.x = 385
        Move_Message.y = 105
        exit
    }*/
    
    
}
if (global.at_swapping != 0) global.at_swapping = 0
if (global.dollar_sign_stunning != 0) global.dollar_sign_stunning = 0
if (global.big_w_life_draining) global.big_w_life_draining = false
if (global.big_w_life_giving) global.big_w_life_giving = false
if (global.w_casting) global.w_casting = false
if (global.t_detonating != 0) global.t_detonating = 0
if (global.Red_B_Killing_Left != 0) global.Red_B_Killing_Left = 0
if (global.Red_B_Killing_Up != 0) global.Red_B_Killing_Up = 0
if (global.Red_B_Killing_Right != 0) global.Red_B_Killing_Right = 0
if (global.Red_B_Killing_Down != 0) global.Red_B_Killing_Down = 0
if (global.Black_B_Killing_Left != 0) global.Black_B_Killing_Left = 0
if (global.Black_B_Killing_Up != 0) global.Black_B_Killing_Up = 0
if (global.Black_B_Killing_Right != 0) global.Black_B_Killing_Right = 0
if (global.Black_B_Killing_Down != 0) global.Black_B_Killing_Down = 0
with (Message_Object) instance_destroy()
with (Move_Message) instance_destroy()
global.mouse_has_clicked = true
Connect_4_Control.alarm[1] = 30
instance_destroy()
