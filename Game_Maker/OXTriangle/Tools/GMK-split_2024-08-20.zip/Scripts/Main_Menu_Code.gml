// Main_Menu_Code
// Stefan Grace
// Created: 2015-06-18
// Modified: 2024-07-27
// This script is activated when the player clicks the Main Menu button



//this block of code saves the level 
if (global.levelnumber>=0) && (global.onlevel==1)  && !keyboard_check(vk_shift)
&& (instance_number(Player_Winz) == 0) && (instance_number(Player_Select) == 0)
{
    Save_Level()
}


//this block of code goes to the main menu room
global.onlevel = false;
room_goto(Main_Menu_Room)

//this block of code stops the music playing
sound_stop_all()
