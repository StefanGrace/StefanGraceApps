// Stuned_Step_After_Kill_Check
// Stefan Grace
// Created: 2017-08-12
// Modified: 2017-08-12
// This script is executed on all stuned characters each step after the character has checked what it should kill and be killed by

if (to_be_killed) instance_destroy()
