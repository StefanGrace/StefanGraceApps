// Bring_Up_Menu
// Stefan Grace
// Created: 2016-07-02
// Modified: 2017-07-23
// This script brings up the menu in a level when the esape key is pressed

if (instance_number(Level_Cover) > 0) exit

if (instance_number(Player_One_Winz)==0 and instance_number(Player_Two_Winz)==0) instance_create(room_width/2,room_height/2,Menu) else room_goto(Main_Menu_Room)
// global.game_frozen = 1
