with(Player_One_Select) instance_destroy()
with(Player_Two_Select) instance_destroy()
with(Player_Select) instance_destroy()
with(Player_Random) instance_destroy()

if(global.levelnumber==16)
{
    global.message_type = 40
    instance_create(105, 210, Message_Object)
}

if(global.levelnumber==24)
{
    global.message_type = 41
    instance_create(945, 315, Message_Object)
}