with(all) 
{
    if (character_id+character_o>0)
    {
        if (character_id!=13 and character_id!=31)
        {
            if (place_meeting(x,y,other)) instance_destroy()
        }
    }
}