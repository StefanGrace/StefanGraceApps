// Save_Global
// Stefan Grace
// Created: before 2017-06-20
// Modified: 2022-08-21
// This script saves some important global variables to txt files

var dir file;

dir = working_directory + "\Settings\"
if (!directory_exists(dir)) directory_create(dir)

// Language
if (file_exists(working_directory+"\Settings\Language.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Language.txt")
    file_text_write_string(file, string(global.Language))
    file_text_close(file)
}

// Player 1 Name
if (file_exists(working_directory+"\Settings\Player_1_Name.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Player_1_Name.txt")
    file_text_write_string(file,global.Player_One)
    file_text_close(file)
}

// Player 2 Name
if (file_exists(working_directory+"\Settings\Player_2_Name.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Player_2_Name.txt")
    file_text_write_string(file,global.Player_Two)
    file_text_close(file)
}

// Music
if (file_exists(working_directory+"\Settings\Music.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Music.txt")
    file_text_write_real(file,global.Music_Playing)
    file_text_close(file)
}

// Date and Time Format Settings
if (file_exists(working_directory+"\Settings\Date_Time.txt"))
{
    var date_time_val;
    date_time_val = global.Date_Order + (global.Time_Format*10) + (global.Date_Time_Order*100) + (global.Year_Format*1000) + (global.Month_Format*10000)
    file = file_text_open_write(working_directory + "\Settings\Date_Time.txt")
    file_text_write_real(file,date_time_val)
    file_text_close(file)
}

// Show Backgrounds
if (file_exists(working_directory+"\Settings\Show_Backgrounds.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Show_Backgrounds.txt")
    file_text_write_real(file,global.show_backgrounds)
    file_text_close(file)
}

// Cheats
if (file_exists(working_directory+"\Settings\Cheats.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Cheats.txt")
    file_text_write_real(file,global.cheats)
    file_text_close(file)
}

// Tablet Mode
if (file_exists(working_directory+"\Settings\Tablet_Mode.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Tablet_Mode.txt")
    file_text_write_real(file,global.tablet_mode)
    file_text_close(file)
}

// Fullscreen
if (file_exists(working_directory+"\Settings\Fullscreen.txt"))
{
    file = file_text_open_write(working_directory + "\Settings\Fullscreen.txt")
    file_text_write_real(file, window_get_fullscreen());
    file_text_close(file)
}