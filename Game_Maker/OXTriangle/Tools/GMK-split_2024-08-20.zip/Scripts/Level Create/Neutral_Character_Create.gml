// Neutral_Character_Create
// Stefan Grace
// Created: 2017-07-16
// Modified: 2018-06-10
// This script creates the neutral (free, green) characters on each level

// Level 2
if (global.levelnumber==2)
{
    instance_create(595,210,Green_O)
    instance_create(630,210,Green_Triangle)
    instance_create(665,210,Green_O)
    instance_create(595,525,Green_O)
    instance_create(630,525,Green_Triangle)
    instance_create(665,525,Green_O)
}


// Level 3
if (global.levelnumber==3)
{
    instance_create(630,210,Green_O)
    instance_create(665,210,Green_O)
    instance_create(630,525,Green_O)
    instance_create(665,525,Green_O)
    instance_create(350,105,Green_X)
    instance_create(385,350,Green_A)
    instance_create(350,630,Green_X)
    instance_create(035,035,Green_Triangle)
    instance_create(035,700,Green_Triangle)
    instance_create(1260,35,Green_O)
    instance_create(1260,700,Green_O)   
}

// Level 4
if (global.levelnumber==4)
{
    instance_create(35,105,Green_X)
    instance_create(245,35,Green_Triangle)
    instance_create(630,35,Green_A)
    instance_create(1050,35,Green_Triangle)
    instance_create(1260,105,Green_X)
    instance_create(630,455,Green_O)
    instance_create(210,630,Green_O)
    instance_create(945,630,Green_O)
    instance_create(595,700,Green_A)
}   

// Level 5
if (global.levelnumber==5)
{
    instance_create(35,35,Green_X)
    instance_create(35+17,35,Green_A)
    instance_create(35,35+17,Green_Triangle)
    instance_create(35,70,Green_O)
    instance_create(35+17,70,Green_O)
    instance_create(665,140,Green_X)
    instance_create(595,245,Green_Triangle)
    instance_create(735,245,Green_A)
    instance_create(595,455,Green_Triangle)
    instance_create(770,455,Green_A)
    instance_create(665,525,Green_X)
    instance_create(1260,665,Green_O)
    instance_create(1260+17,665,Green_O)
    instance_create(1260,700,Green_X)
    instance_create(1260+17,700,Green_A)
    instance_create(1260,700+17,Green_Triangle)
}

// Level 6
if (global.levelnumber==6)
{
    instance_create(35,35,Green_X)
    instance_create(1260,35,Green_X)
    instance_create(525,245,Green_O)
    instance_create(735,245,Green_O)
    instance_create(35,350,Green_X)
    instance_create(1260,350,Green_X)
}

// Level 7
if (global.levelnumber==7)
{
    instance_create(420,35,Green_Square)
    instance_create(875,35,Green_Square)
    instance_create(490,175,Green_X)
    instance_create(770,315,Green_X)
    instance_create(385,420,Green_Triangle)
    instance_create(735,455,Green_Triangle)
    instance_create(35,700,Green_A)
    instance_create(945,700,Green_A)
}

// Level 8
if (global.levelnumber==8)
{
    instance_create(455,385,Green_Square)
    instance_create(455+17,385,Green_Square)
    instance_create(455,385+17,Green_Square)
    instance_create(490,385,Green_A)
    instance_create(490+17,385,Green_A)
    instance_create(490,385+17,Green_A)
    instance_create(525,385,Green_X)
    instance_create(525+17,385,Green_X)
    instance_create(525,385+17,Green_X)
    instance_create(560,385,Green_O)
    instance_create(560+17,385,Green_O)
    instance_create(560,385+17,Green_O)
    instance_create(875,385,Green_Square)
    instance_create(875+17,385,Green_Square)
    instance_create(875,385+17,Green_Square)
    instance_create(840,385,Green_A)
    instance_create(840+17,385,Green_A)
    instance_create(840,385+17,Green_A)
    instance_create(805,385,Green_X)
    instance_create(805+17,385,Green_X)
    instance_create(805,385+17,Green_X)
    instance_create(770,385,Green_O)
    instance_create(770+17,385,Green_O)
    instance_create(770,385+17,Green_O)
}

// Level 9
if (global.levelnumber==9)
{
    instance_create(490,105,Green_X)
    instance_create(490+17,105,Green_X)
    instance_create(735,105,Green_X)
    instance_create(735+17,105,Green_X)
    instance_create(455,245,Green_Triangle)
    instance_create(455+17,245,Green_Triangle)
    instance_create(735,245,Green_Triangle)
    instance_create(735+17,245,Green_Triangle)
    instance_create(490,280,Green_A)
    instance_create(490+17,280,Green_A)
    instance_create(700,280,Green_A)
    instance_create(700+17,280,Green_A)
}

// Level 10
if (global.levelnumber==10)
{
    instance_create(420,175,Green_X)
    instance_create(490,175,Green_A)
    instance_create(630,175,Green_K)
    instance_create(805,175,Green_A)
    instance_create(875,175,Green_X)
    instance_create(420,245,Green_Triangle)
    instance_create(875,245,Green_Triangle)
    instance_create(420,350,Green_Square)
    instance_create(875,350,Green_Square)
    instance_create(420,455,Green_Triangle)
    instance_create(875,455,Green_Triangle)
    instance_create(420,525,Green_X)
    instance_create(490,525,Green_A)
    instance_create(665,525,Green_K)
    instance_create(805,525,Green_A)
    instance_create(875,525,Green_X)
}

// Level 11
if (global.levelnumber==11)
{
    instance_create(35,35,Green_X)
    instance_create(210,35,Green_A)
    instance_create(1085,35,Green_A)
    instance_create(1260,35,Green_X)
    instance_create(35,175,Green_Triangle)
    instance_create(210,175,Green_O)
    instance_create(1085,175,Green_O)
    instance_create(1260,175,Green_Triangle)
}

// Level 12
if (global.levelnumber==12)
{
    instance_create(525,35,Green_X)
    instance_create(560,35,Green_Square)
    instance_create(875,280,Green_X)
    instance_create(875+17,280,Green_B)
    instance_create(560,385,Green_X)
    instance_create(560+17,385,Green_B)
    instance_create(595,700,Green_B)
    instance_create(595+17,700,Green_Square)
    instance_create(630,700,Green_X)
}

// Level 13
if (global.levelnumber==13)
{
    instance_create(315,35,Green_Square)
    instance_create(525,35,Green_A)
    instance_create(980,35,Green_Square)
    instance_create(665,280,Green_O)
    instance_create(910,280,Green_O)
    instance_create(770,385,Green_X)
    instance_create(385,560,Green_Triangle)
    instance_create(665,560,Green_O)
    instance_create(875,560,Green_E)
    instance_create(910,560,Green_E)
}

// Level 14
if (global.levelnumber==14)
{
    instance_create(980,35,Green_E)
    instance_create(210,140,Green_E)
    instance_create(35,280,Green_Square)
    instance_create(525,455,Green_X)
    instance_create(1050,455,Green_Square)
    instance_create(770,700,Green_A)

}

// Level 15
if (global.levelnumber==15)
{
    instance_create(385,245,Green_S)
    instance_create(910,245,Green_S)
    instance_create(665,385,Green_S)
    instance_create(770,385,Green_Square)
    instance_create(595,420,Green_X)
    instance_create(630,420,Green_A)
    instance_create(737,420,Green_O)
    instance_create(665,490,Green_E)
    instance_create(770,490,Green_Triangle)
    instance_create(560,525,Green_K)
    instance_create(630,525,Green_O)
    instance_create(735,525,Green_B)
    instance_create(525,595,Green_O)
    instance_create(595,595,Green_S)
    instance_create(560,630,Green_B)
    instance_create(665,630,Green_E)
}

// Level 17
if (global.levelnumber==17)
{
    instance_create(35,35,Green_O)
    instance_create(1260,35,Green_O)
    instance_create(490,140,Green_S)
    instance_create(875,140,Green_S)
    instance_create(140,315,Green_B)
    instance_create(1155,280,Green_B)
}

// Level 19
if (global.levelnumber==19)
{
    instance_create((17*grid_size),(4*grid_size),Green_X)
    instance_create((17*grid_size)+17,(4*grid_size),Green_X)
    instance_create((18*grid_size),(4*grid_size),Green_O)
    instance_create((18*grid_size)+17,(4*grid_size),Green_O)
    instance_create((19*grid_size),(4*grid_size),Green_A)
    instance_create((19*grid_size)+17,(4*grid_size),Green_A)
    instance_create((17*grid_size),(5*grid_size),Green_B)
    instance_create((17*grid_size)+17,(5*grid_size),Green_E)
    instance_create((17*grid_size),(5*grid_size)+17,Green_E)
    instance_create((18*grid_size),(5*grid_size),Green_S)
    instance_create((18*grid_size)+17,(5*grid_size),Green_S)
    instance_create((19*grid_size),(5*grid_size),Green_H)
    instance_create((19*grid_size)+17,(5*grid_size),Green_H)
    instance_create((17*grid_size),(6*grid_size),Green_Triangle)
    instance_create((17*grid_size)+17,(6*grid_size),Green_Triangle)
    instance_create((18*grid_size),(6*grid_size),Green_Square)
    instance_create((18*grid_size)+17,(6*grid_size),Green_Square)
}

// Level 20
if (global.levelnumber==20)
{
    instance_create((9*grid_size),(8*grid_size),Green_A)
    instance_create((28*grid_size),(8*grid_size),Green_A) 
    instance_create((1*grid_size),(10*grid_size),Green_O)
    instance_create((15*grid_size),(10*grid_size),Green_R)
    instance_create((16*grid_size),(10*grid_size),Green_X)
    instance_create((17*grid_size),(10*grid_size),Green_Square)
    instance_create((20*grid_size),(10*grid_size),Green_Square)
    instance_create((21*grid_size),(10*grid_size),Green_X)
    instance_create((22*grid_size),(10*grid_size),Green_R)
    instance_create((36*grid_size),(10*grid_size),Green_O)
    instance_create((1*grid_size),(11*grid_size),Green_E)
    instance_create((36*grid_size),(11*grid_size),Green_E)
}

// Level 21
if (global.levelnumber==21)
{
    instance_create((1*grid_size),(1*grid_size),Green_O)
    instance_create((21*grid_size),(1*grid_size),Green_A)
    instance_create((31*grid_size),(1*grid_size),Green_R)
    instance_create((7*grid_size),(2*grid_size),Green_X)
    instance_create((9*grid_size),(2*grid_size),Green_M)
    instance_create((29*grid_size),(2*grid_size),Green_M)
    instance_create((1*grid_size),(3*grid_size),Green_M)
    instance_create((16*grid_size),(3*grid_size),Green_M)
    instance_create((8*grid_size),(4*grid_size),Green_Triangle)
    instance_create((24*grid_size),(4*grid_size),Green_H)
    instance_create((12*grid_size),(5*grid_size),Green_E)
    instance_create((6*grid_size),(6*grid_size),Green_Triangle)
    instance_create((24*grid_size),(6*grid_size),Green_M)
    instance_create((9*grid_size),(7*grid_size),Green_S)
    instance_create((14*grid_size),(8*grid_size),Green_M)
    instance_create((27*grid_size),(8*grid_size),Green_B)
    instance_create((32*grid_size),(8*grid_size),Green_A)
    instance_create((2*grid_size),(9*grid_size),Green_Square)
    instance_create((24*grid_size),(9*grid_size),Green_M)
    instance_create((17*grid_size),(10*grid_size),Green_X)
    instance_create((17*grid_size)+17,(10*grid_size),Green_X)
    instance_create((17*grid_size),(10*grid_size)+17,Green_R)
    instance_create((19*grid_size),(10*grid_size),Green_A)
    instance_create((19*grid_size)+17,(10*grid_size),Green_A)
    instance_create((31*grid_size),(10*grid_size),Green_O)
    instance_create((35*grid_size),(10*grid_size),Green_M)
    instance_create((2*grid_size),(11*grid_size),Green_M)
    instance_create((19*grid_size),(11*grid_size),Green_Triangle)
    instance_create((20*grid_size),(11*grid_size),Green_Triangle)
    instance_create((5*grid_size),(12*grid_size),Green_A)
    instance_create((9*grid_size),(12*grid_size),Green_H)
    instance_create((28*grid_size),(12*grid_size),Green_S)
    instance_create((35*grid_size),(12*grid_size),Green_Square)
    instance_create((16*grid_size),(14*grid_size),Green_M)
    instance_create((30*grid_size),(14*grid_size),Green_M)
    instance_create((8*grid_size),(15*grid_size),Green_M)
    instance_create((22*grid_size),(15*grid_size),Green_M)
    instance_create((12*grid_size),(16*grid_size),Green_B)
    instance_create((16*grid_size),(17*grid_size),Green_M)
    instance_create((22*grid_size),(17*grid_size),Green_E)
    instance_create((12*grid_size),(18*grid_size),Green_A)
    instance_create((30*grid_size),(18*grid_size),Green_X)
    instance_create((7*grid_size),(20*grid_size),Green_R)
    instance_create((16*grid_size),(20*grid_size),Green_O)
    instance_create((20*grid_size),(20*grid_size),Green_Triangle)
    instance_create((26*grid_size),(20*grid_size),Green_Triangle)
    instance_create((29*grid_size),(20*grid_size),Green_M)
    instance_create((35*grid_size),(20*grid_size),Green_O)
    instance_create((36*grid_size),(20*grid_size),Green_M)
}

// Level 22
if (global.levelnumber==22)
{
    instance_create(420,70,Green_M)
    instance_create(875,70,Green_M)
    instance_create(595,140,Green_B)
    instance_create(700,140,Green_B)
    instance_create(595,595,Green_B)
    instance_create(700,595,Green_B)
    instance_create(420,665,Green_M)
    instance_create(875,665,Green_M)
}

// Level 23
if (global.levelnumber==23)
{
    instance_create((6*grid_size),(19*grid_size),Green_R)
    instance_create((31*grid_size),(19*grid_size),Green_R)
    instance_create((12*grid_size),(2*grid_size),Green_Square)
    instance_create((25*grid_size),(2*grid_size),Green_Square)
    instance_create((12*grid_size),(19*grid_size),Green_Square)
    instance_create((25*grid_size),(19*grid_size),Green_Square)
    var h_center;
    var v_center;
    var h_offset;
    var v_offset;
    var flip;
    h_center = 19*grid_size
    v_center = 10*grid_size
    h_offset = 0
    v_offset = 0
    flip = -1
    repeat(2)
    {    
        instance_create((1*grid_size*flip)+h_center+h_offset,(7*grid_size*flip)+v_center+v_offset,Green_O)
        instance_create((0*grid_size*flip)+h_center+h_offset,(7*grid_size*flip)+v_center+v_offset,Green_S)
        instance_create((3*grid_size*flip)+h_center+h_offset,(2*grid_size*flip)+v_center+v_offset,Green_H)
        instance_create((2*grid_size*flip)+h_center+h_offset,(2*grid_size*flip)+v_center+v_offset,Green_A)
        instance_create((-1*grid_size*flip)+h_center+h_offset,(2*grid_size*flip)+v_center+v_offset,Green_A)
        instance_create((-2*grid_size*flip)+h_center+h_offset,(2*grid_size*flip)+v_center+v_offset,Green_E)
        instance_create((7*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_F)
        instance_create((3*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_Triangle)
        instance_create((2*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_X)
        instance_create((-1*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_X)
        instance_create((-2*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_Triangle)
        instance_create((-6*grid_size*flip)+h_center+h_offset,(1*grid_size*flip)+v_center+v_offset,Green_M)
        flip = 1
        h_offset = -1*grid_size
    }
}

// Level 25
if (global.levelnumber==25)
{
    instance_create((19*grid_size),(2*grid_size),Green_O)
    instance_create((19*grid_size),(6*grid_size),Green_R)
    instance_create((21*grid_size),(6*grid_size),Green_M)
    instance_create((15*grid_size),(10*grid_size),Green_G)
    instance_create((19*grid_size),(19*grid_size),Green_O)
}

// Level 26
if (global.levelnumber==26)
{
    var i;
    for(i = 9; i <= 19; i += 1)
    {
        instance_create((7*grid_size),(i*grid_size),Green_G)
        instance_create((30*grid_size),(i*grid_size),Green_G)
    }
    for(i = 5; i <= 18; i += 1)
    {
        instance_create((13*grid_size),(i*grid_size),Green_G)
        instance_create((24*grid_size),(i*grid_size),Green_G)
    }
    for(i = 13; i <= 17; i += 1)
    {
        instance_create((9*grid_size),(i*grid_size),Green_G)
        instance_create((28*grid_size),(i*grid_size),Green_G)
    }
    for(i = 7; i <= 30; i += 1)
    {
        instance_create((i*grid_size),(20*grid_size),Green_G)
    }
    for(i = 8; i <= 12; i += 1)
    {
        instance_create((i*grid_size),(9*grid_size),Green_G)
        instance_create(((i+17)*grid_size),(9*grid_size),Green_G)
    }
    for(i = 1; i <= 19; i += 1)
    {
        instance_create((18*grid_size),(i*grid_size),Green_G)
        instance_create((19*grid_size),(i*grid_size),Green_G)
        if (i==5) i = 8
    }
    instance_create((14*grid_size),(12*grid_size),Green_S)
    instance_create((23*grid_size),(12*grid_size),Green_S)
    instance_create((14*grid_size),(13*grid_size),Green_Square)
    instance_create((23*grid_size),(13*grid_size),Green_Square)
    instance_create((12*grid_size),(22*grid_size),Green_R)
    instance_create((25*grid_size),(22*grid_size),Green_R)
    instance_create((12*grid_size),(24*grid_size),Green_M)
    instance_create((25*grid_size),(24*grid_size),Green_M)
    instance_create((10*grid_size),(24*grid_size),Green_M)
    instance_create((27*grid_size),(24*grid_size),Green_M)
    instance_create((8*grid_size),(19*grid_size),Green_X)
    instance_create((12*grid_size),(19*grid_size),Green_F)
    instance_create((14*grid_size),(19*grid_size),Green_X)
    instance_create((15*grid_size),(19*grid_size),Green_O)
    instance_create((16*grid_size),(19*grid_size),Green_Triangle)
    instance_create((17*grid_size),(19*grid_size),Green_A)
    instance_create((20*grid_size),(19*grid_size),Green_X)
    instance_create((21*grid_size),(19*grid_size),Green_O)
    instance_create((22*grid_size),(19*grid_size),Green_Triangle)
    instance_create((23*grid_size),(19*grid_size),Green_A)
    instance_create((25*grid_size),(19*grid_size),Green_F)
    instance_create((29*grid_size),(19*grid_size),Green_X)
}

// Level 27
if (global.levelnumber==27)
{
    // Middle Column
    var x_pos;
    x_pos = 19*grid_size
    instance_create(x_pos,3*grid_size,Green_M)
    instance_create(x_pos,4*grid_size,Green_M)
    instance_create(x_pos,5*grid_size,Green_X)
    instance_create(x_pos,6*grid_size,Green_A)
    instance_create(x_pos,7*grid_size,Green_X)
    instance_create(x_pos,8*grid_size,Green_A)
    instance_create(x_pos,9*grid_size,Green_F)
    instance_create(x_pos,10*grid_size,Green_R)
    instance_create(x_pos,11*grid_size,Green_O)
    instance_create(x_pos,12*grid_size,Green_O); instance_create(x_pos+17,12*grid_size,Green_Triangle)
    instance_create(x_pos,13*grid_size,Green_O)
    instance_create(x_pos,14*grid_size,Green_B)
    instance_create(x_pos,15*grid_size,Green_E)
    instance_create(x_pos,16*grid_size,Green_K)
    instance_create(x_pos,17*grid_size,Green_H)
    instance_create(x_pos,18*grid_size,Green_S)
    instance_create(x_pos,19*grid_size,Green_Square)
    // Left C
    instance_create(14*grid_size,1*grid_size,Green_C)
    // Right C
    instance_create(24*grid_size,1*grid_size,Green_C)
}

// Level 28
if (global.levelnumber==28)
{
    // Left
    instance_create(420,35,Green_X)
    instance_create(490,35,Green_M)
    instance_create(560,35,Green_M)
    instance_create(420,105,Green_Triangle)
    instance_create(490,105,Green_F)
    instance_create(560,105,Green_R)
    instance_create(420,175,Green_Square)
    instance_create(490,175,Green_F)
    instance_create(560,175,Green_S)
    instance_create(420,245,Green_A)
    instance_create(490,245,Green_E)
    instance_create(560,245,Green_H)
    // Right
    instance_create(735,35,Green_M)
    instance_create(805,35,Green_M)
    instance_create(875,35,Green_X)
    instance_create(735,105,Green_R)
    instance_create(805,105,Green_F)
    instance_create(875,105,Green_Triangle)
    instance_create(735,175,Green_S)
    instance_create(805,175,Green_F)
    instance_create(875,175,Green_Square)
    instance_create(735,245,Green_A)
    instance_create(805,245,Green_E)
    instance_create(875,245,Green_H)
}