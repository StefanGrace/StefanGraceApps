if (global.tablet_mode)
{
    if (global.levelnumber != 16 and global.levelnumber != 24) 
    {
        instance_create(735, 350, Tablet_UI)
    }
    else
    {
        instance_create(630, 735, Tablet_UI_Menu_Button)
    }
}