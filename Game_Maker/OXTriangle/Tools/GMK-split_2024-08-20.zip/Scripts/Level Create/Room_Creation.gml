// Room_Creation
// Stefan Grace
// Created: 2016-07-01
// Modified: 2024-07-27
// This Script is executed when the level starts

global.message_type = 0
script_execute(Base_Create)
script_execute(Double_Boxing_Create)
script_execute(Neutral_Character_Create)
script_execute(Background_Script)
script_execute(Ask_To_Load_Save)
script_execute(Create_Tablet_UI)
global.anger = 0