// Double_Boxing_Create
// Stefan Grace
// Created: 2016-07-09
// Modifed: 2018-04-16
// This script creates Double Boxing in the correct place when the room starts

// Test Level 7
if (global.levelnumber==-7)
{
    // Double_Boxing
    instance_create(630,420,Double_Boxing)
    instance_create(665,420,Double_Boxing)
    instance_create(630,455,Double_Boxing)
    instance_create(665,455,Double_Boxing)
    instance_create(630,490,Double_Boxing)
    instance_create(945,595,Double_Boxing)
    instance_create(980,595,Double_Boxing)
    instance_create(1015,595,Double_Boxing)
    instance_create(1050,595,Double_Boxing)
    instance_create(945,630,Double_Boxing)
    instance_create(980,630,Double_Boxing)
    instance_create(1015,630,Double_Boxing)
    instance_create(1050,630,Double_Boxing)
    instance_create(945,665,Double_Boxing)
    instance_create(980,665,Double_Boxing)
    instance_create(1015,665,Double_Boxing)
    instance_create(1050,665,Double_Boxing)
    // Double_Boxing_Yellow
    instance_create(1050,665,Double_Boxing_Yellow)
    instance_create(1050+18,665,Double_Boxing_Yellow)
    instance_create(1050,665+18,Double_Boxing_Yellow)
    instance_create(1050+18,665+18,Double_Boxing_Yellow)
    instance_create(945,595,Double_Boxing_Yellow)
    instance_create(945+18,595,Double_Boxing_Yellow)
    instance_create(945,595+18,Double_Boxing_Yellow)
    instance_create(945+18,595+18,Double_Boxing_Yellow)
    // Double_Boxing_Rock
    instance_create(630,420,Double_Boxing_Rock)
    instance_create(630+18,420,Double_Boxing_Rock)
    instance_create(630,420+18,Double_Boxing_Rock)
    instance_create(630+18,420+18,Double_Boxing_Rock)
    instance_create(665,420,Double_Boxing_Rock)
    instance_create(665+18,420,Double_Boxing_Rock)
    instance_create(665,420+18,Double_Boxing_Rock)
    instance_create(665+18,420+18,Double_Boxing_Rock)
    instance_create(630,455,Double_Boxing_Rock)
    instance_create(630+18,455,Double_Boxing_Rock)
    instance_create(630,455+18,Double_Boxing_Rock)
    instance_create(630+18,455+18,Double_Boxing_Rock)
    instance_create(665,455,Double_Boxing_Rock)
    instance_create(665+18,455,Double_Boxing_Rock)
    instance_create(665,455+18,Double_Boxing_Rock)
    instance_create(665+18,455+18,Double_Boxing_Rock)
    instance_create(630,490,Double_Boxing_Rock)
    instance_create(630+18,490,Double_Boxing_Rock)
    instance_create(630,490+18,Double_Boxing_Rock)
    instance_create(630+18,490+18,Double_Boxing_Rock)
    instance_create(980,595,Double_Boxing_Rock)
    instance_create(980+18,595,Double_Boxing_Rock)
    instance_create(980,595+18,Double_Boxing_Rock)
    instance_create(980+18,595+18,Double_Boxing_Rock)
    instance_create(1015,595,Double_Boxing_Rock)
    instance_create(1015+18,595,Double_Boxing_Rock)
    instance_create(1015,595+18,Double_Boxing_Rock)
    instance_create(1015+18,595+18,Double_Boxing_Rock)
    instance_create(945,630,Double_Boxing_Rock)
    instance_create(945+18,630,Double_Boxing_Rock)
    instance_create(945,630+18,Double_Boxing_Rock)
    instance_create(945+18,630+18,Double_Boxing_Rock)
    instance_create(980,630,Double_Boxing_Rock)
    instance_create(980+18,630,Double_Boxing_Rock)
    instance_create(980,630+18,Double_Boxing_Rock)
    instance_create(980+18,630+18,Double_Boxing_Rock)
    instance_create(1015,630,Double_Boxing_Rock)
    instance_create(1015+18,630,Double_Boxing_Rock)
    instance_create(1015,630+18,Double_Boxing_Rock)
    instance_create(1015+18,630+18,Double_Boxing_Rock)
    instance_create(1050,630,Double_Boxing_Rock)
    instance_create(1050+18,630,Double_Boxing_Rock)
    instance_create(1050,630+18,Double_Boxing_Rock)
    instance_create(1050+18,630+18,Double_Boxing_Rock)
    instance_create(980,665,Double_Boxing_Rock)
    instance_create(980+18,665,Double_Boxing_Rock)
    instance_create(980,665+18,Double_Boxing_Rock)
    instance_create(980+18,665+18,Double_Boxing_Rock)
    instance_create(1015,665,Double_Boxing_Rock)
    instance_create(1015+18,665,Double_Boxing_Rock)
    instance_create(1015,665+18,Double_Boxing_Rock)
    instance_create(1015+18,665+18,Double_Boxing_Rock)
    // Double_Boxing_Dimond
    instance_create(1050,595,Double_Boxing_Dimond)
    instance_create(1050+18,595,Double_Boxing_Dimond)
    instance_create(1050,595+18,Double_Boxing_Dimond)
    instance_create(1050+18,595+18,Double_Boxing_Dimond)
}

// Test Level 9
if (global.levelnumber==-9)
{
    instance_create(15*grid_size,15*grid_size,Double_Boxing)
    instance_create(15*grid_size,15*grid_size,Double_Boxing_Yellow)
    instance_create((15*grid_size)+18,15*grid_size,Double_Boxing_Yellow)
    instance_create(15*grid_size,(15*grid_size)+18,Double_Boxing_Yellow)
    instance_create((15*grid_size)+18,(15*grid_size)+18,Double_Boxing_Yellow)
}

// Level 17
if (global.levelnumber==17)
{
    // Double_Boxing
    //instance_create(630,35,Double_Boxing)
    instance_create(630,70,Double_Boxing)
    instance_create(630,105,Double_Boxing)
    instance_create(630,140,Double_Boxing)
    instance_create(630,175,Double_Boxing)
    instance_create(630,210,Double_Boxing)
    instance_create(630,245,Double_Boxing)
    instance_create(630,280,Double_Boxing)
    instance_create(630,315,Double_Boxing)
    instance_create(630,350,Double_Boxing)
    instance_create(630,385,Double_Boxing)
    instance_create(630,420,Double_Boxing)
    instance_create(630,455,Double_Boxing)
    instance_create(630,490,Double_Boxing)
    instance_create(630,525,Double_Boxing)
    instance_create(630,560,Double_Boxing)
    instance_create(630,595,Double_Boxing)
    instance_create(630,630,Double_Boxing)
    instance_create(630,665,Double_Boxing)
    instance_create(630,700,Double_Boxing)
    // Double_Boxing_Rock
    //instance_create(630,35,Double_Boxing_Rock)
    instance_create(630,70,Double_Boxing_Rock)
    instance_create(630,105,Double_Boxing_Rock)
    instance_create(630,140,Double_Boxing_Rock)
    instance_create(630,175,Double_Boxing_Rock)
    instance_create(630,210,Double_Boxing_Rock)
    instance_create(630,245,Double_Boxing_Rock)
    instance_create(630,280,Double_Boxing_Rock)
    instance_create(630,315,Double_Boxing_Rock)
    instance_create(630,350,Double_Boxing_Rock)
    instance_create(630,385,Double_Boxing_Rock)
    instance_create(630,420,Double_Boxing_Rock)
    instance_create(630,455,Double_Boxing_Rock)
    instance_create(630,490,Double_Boxing_Rock)
    instance_create(630,525,Double_Boxing_Rock)
    instance_create(630,560,Double_Boxing_Rock)
    instance_create(630,595,Double_Boxing_Rock)
    instance_create(630,630,Double_Boxing_Rock)
    instance_create(630,665,Double_Boxing_Rock)
    instance_create(630,700,Double_Boxing_Rock)
    //instance_create(630+18,35,Double_Boxing_Rock)
    instance_create(630+18,70,Double_Boxing_Rock)
    instance_create(630+18,105,Double_Boxing_Rock)
    instance_create(630+18,140,Double_Boxing_Rock)
    instance_create(630+18,175,Double_Boxing_Rock)
    instance_create(630+18,210,Double_Boxing_Rock)
    instance_create(630+18,245,Double_Boxing_Rock)
    instance_create(630+18,280,Double_Boxing_Rock)
    instance_create(630+18,315,Double_Boxing_Rock)
    instance_create(630+18,350,Double_Boxing_Rock)
    instance_create(630+18,385,Double_Boxing_Rock)
    instance_create(630+18,420,Double_Boxing_Rock)
    instance_create(630+18,455,Double_Boxing_Rock)
    instance_create(630+18,490,Double_Boxing_Rock)
    instance_create(630+18,525,Double_Boxing_Rock)
    instance_create(630+18,560,Double_Boxing_Rock)
    instance_create(630+18,595,Double_Boxing_Rock)
    instance_create(630+18,630,Double_Boxing_Rock)
    instance_create(630+18,665,Double_Boxing_Rock)
    instance_create(630+18,700,Double_Boxing_Rock)
    //instance_create(630,35+18,Double_Boxing_Rock)
    instance_create(630,70+18,Double_Boxing_Rock)
    instance_create(630,105+18,Double_Boxing_Rock)
    instance_create(630,140+18,Double_Boxing_Rock)
    instance_create(630,175+18,Double_Boxing_Rock)
    instance_create(630,210+18,Double_Boxing_Rock)
    instance_create(630,245+18,Double_Boxing_Rock)
    instance_create(630,280+18,Double_Boxing_Rock)
    instance_create(630,315+18,Double_Boxing_Rock)
    instance_create(630,350+18,Double_Boxing_Rock)
    instance_create(630,385+18,Double_Boxing_Rock)
    instance_create(630,420+18,Double_Boxing_Rock)
    instance_create(630,455+18,Double_Boxing_Rock)
    instance_create(630,490+18,Double_Boxing_Rock)
    instance_create(630,525+18,Double_Boxing_Rock)
    instance_create(630,560+18,Double_Boxing_Rock)
    instance_create(630,595+18,Double_Boxing_Rock)
    instance_create(630,630+18,Double_Boxing_Rock)
    instance_create(630,665+18,Double_Boxing_Rock)
    instance_create(630,700+18,Double_Boxing_Rock)
    //instance_create(630+18,35+18,Double_Boxing_Rock)
    instance_create(630+18,70+18,Double_Boxing_Rock)
    instance_create(630+18,105+18,Double_Boxing_Rock)
    instance_create(630+18,140+18,Double_Boxing_Rock)
    instance_create(630+18,175+18,Double_Boxing_Rock)
    instance_create(630+18,210+18,Double_Boxing_Rock)
    instance_create(630+18,245+18,Double_Boxing_Rock)
    instance_create(630+18,280+18,Double_Boxing_Rock)
    instance_create(630+18,315+18,Double_Boxing_Rock)
    instance_create(630+18,350+18,Double_Boxing_Rock)
    instance_create(630+18,385+18,Double_Boxing_Rock)
    instance_create(630+18,420+18,Double_Boxing_Rock)
    instance_create(630+18,455+18,Double_Boxing_Rock)
    instance_create(630+18,490+18,Double_Boxing_Rock)
    instance_create(630+18,525+18,Double_Boxing_Rock)
    instance_create(630+18,560+18,Double_Boxing_Rock)
    instance_create(630+18,595+18,Double_Boxing_Rock)
    instance_create(630+18,630+18,Double_Boxing_Rock)
    instance_create(630+18,665+18,Double_Boxing_Rock)
    instance_create(630+18,700+18,Double_Boxing_Rock)
}

// Level 20
if (global.levelnumber==20)
{
    var x_place;
    var y_place;
    // Strip of double boxing with dimond along the bottom
    x_place = 2
    repeat (34)
    {
        instance_create(x_place*grid_size,19*grid_size,Double_Boxing)
        instance_create(x_place*grid_size,19*grid_size,Double_Boxing_Dimond)
        instance_create((x_place*grid_size)+18,19*grid_size,Double_Boxing_Dimond)
        instance_create(x_place*grid_size,(19*grid_size)+18,Double_Boxing_Dimond)
        instance_create((x_place*grid_size)+18,(19*grid_size)+18,Double_Boxing_Dimond)
        x_place += 1
    }
    // Double strip of double boxing with dimond down the middle
    y_place = 1
    repeat (15)
    {
        instance_create((18*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((18*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((18*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((18*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((18*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((19*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((19*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((19*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((19*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((19*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        y_place += 1
    }
    // Small double strip (2x3) of double boxing with rock down the middle
    y_place = 16
    repeat (3)
    {
        instance_create((18*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((18*grid_size),(y_place*grid_size),Double_Boxing_Rock)
        instance_create((18*grid_size)+18,(y_place*grid_size),Double_Boxing_Rock)
        instance_create((18*grid_size),(y_place*grid_size)+18,Double_Boxing_Rock)
        instance_create((18*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Rock)
        instance_create((19*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((19*grid_size),(y_place*grid_size),Double_Boxing_Rock)
        instance_create((19*grid_size)+18,(y_place*grid_size),Double_Boxing_Rock)
        instance_create((19*grid_size),(y_place*grid_size)+18,Double_Boxing_Rock)
        instance_create((19*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Rock)
        y_place += 1
    }
    // Double boxing strip down the sides with dimond
    y_place = 8
    repeat (5)
    {
        instance_create((14*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((14*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((14*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((14*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((14*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((23*grid_size),(y_place*grid_size),Double_Boxing)
        instance_create((23*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((23*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((23*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((23*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        y_place += 1
    }
    // Double boxing at the middle bottom with dimond
    instance_create((15*grid_size),(12*grid_size),Double_Boxing)
    instance_create((15*grid_size),(12*grid_size),Double_Boxing_Dimond)
    instance_create((15*grid_size)+18,(12*grid_size),Double_Boxing_Dimond)
    instance_create((15*grid_size),(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((15*grid_size)+18,(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((16*grid_size),(12*grid_size),Double_Boxing)
    instance_create((16*grid_size),(12*grid_size),Double_Boxing_Dimond)
    instance_create((16*grid_size)+18,(12*grid_size),Double_Boxing_Dimond)
    instance_create((16*grid_size),(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((16*grid_size)+18,(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((21*grid_size),(12*grid_size),Double_Boxing)
    instance_create((21*grid_size),(12*grid_size),Double_Boxing_Dimond)
    instance_create((21*grid_size)+18,(12*grid_size),Double_Boxing_Dimond)
    instance_create((21*grid_size),(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((21*grid_size)+18,(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((22*grid_size),(12*grid_size),Double_Boxing)
    instance_create((22*grid_size),(12*grid_size),Double_Boxing_Dimond)
    instance_create((22*grid_size)+18,(12*grid_size),Double_Boxing_Dimond)
    instance_create((22*grid_size),(12*grid_size)+18,Double_Boxing_Dimond)
    instance_create((22*grid_size)+18,(12*grid_size)+18,Double_Boxing_Dimond)
    // Double boxing at the middle top with dimond and yellow
    instance_create((15*grid_size),(8*grid_size),Double_Boxing)
    instance_create((15*grid_size),(8*grid_size),Double_Boxing_Dimond)
    instance_create((15*grid_size)+18,(8*grid_size),Double_Boxing_Dimond)
    instance_create((15*grid_size),(8*grid_size)+18,Double_Boxing_Dimond)
    instance_create((15*grid_size)+18,(8*grid_size)+18,Double_Boxing_Dimond)
    instance_create((16*grid_size),(8*grid_size),Double_Boxing)
    instance_create((16*grid_size),(8*grid_size),Double_Boxing_Dimond)
    instance_create((16*grid_size)+18,(8*grid_size),Double_Boxing_Yellow)
    instance_create((16*grid_size),(8*grid_size)+18,Double_Boxing_Dimond)
    instance_create((16*grid_size)+18,(8*grid_size)+18,Double_Boxing_Yellow)
    instance_create((21*grid_size),(8*grid_size),Double_Boxing)
    instance_create((21*grid_size),(8*grid_size),Double_Boxing_Yellow)
    instance_create((21*grid_size)+18,(8*grid_size),Double_Boxing_Dimond)
    instance_create((21*grid_size),(8*grid_size)+18,Double_Boxing_Yellow)
    instance_create((21*grid_size)+18,(8*grid_size)+18,Double_Boxing_Dimond)
    instance_create((22*grid_size),(8*grid_size),Double_Boxing)
    instance_create((22*grid_size),(8*grid_size),Double_Boxing_Dimond)
    instance_create((22*grid_size)+18,(8*grid_size),Double_Boxing_Dimond)
    instance_create((22*grid_size),(8*grid_size)+18,Double_Boxing_Dimond)
    instance_create((22*grid_size)+18,(8*grid_size)+18,Double_Boxing_Dimond)
}

// Level 22
if (global.levelnumber==22)
{
    var x_place;
    var y_place;
    // Double line down
    x_place = 18
    y_place = 1
    repeat(20)
    {
        instance_create(x_place*grid_size,y_place*grid_size,Double_Boxing)
        instance_create((x_place+1)*grid_size,y_place*grid_size,Double_Boxing)
        instance_create((x_place*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((x_place*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create((x_place*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create((x_place*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create(((x_place+1)*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
        instance_create(((x_place+1)*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
        instance_create(((x_place+1)*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
        instance_create(((x_place+1)*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
        y_place += 1
    }
    // Single lines across
    y_place = 6
    repeat(2)
    {
        x_place = 11
        repeat(14)
        {
            instance_create(x_place*grid_size,y_place*grid_size,Double_Boxing) 
            instance_create((x_place*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
            instance_create((x_place*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
            instance_create((x_place*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
            instance_create((x_place*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
            if (x_place==17) x_place += 3 else x_place += 1
        }
        y_place = 15
    }
}

// Level 25
if (global.levelnumber==25)
{
    var x_place;
    var y_place;
    x_place = 22
    y_place = 16
    // Double_Boxing
    /*
    var i;
    var j;
    for (i = x_place; i <= x_place+2; i += 1)
    {
        for (j = y_place; i <= y_place+4; i += 1)
        {
            instance_create(i*grid_size,j*grid_size,Double_Boxing)
        }
    } 
    */
    // Row 0
    instance_create((x_place)*grid_size,(y_place)*grid_size,Double_Boxing)
    instance_create((x_place+1)*grid_size,(y_place)*grid_size,Double_Boxing)
    instance_create((x_place+2)*grid_size,(y_place)*grid_size,Double_Boxing)
    // Row 1
    instance_create((x_place)*grid_size,(y_place+1)*grid_size,Double_Boxing)
    instance_create((x_place+1)*grid_size,(y_place+1)*grid_size,Double_Boxing)
    instance_create((x_place+2)*grid_size,(y_place+1)*grid_size,Double_Boxing)
    // Row 2
    instance_create((x_place)*grid_size,(y_place+2)*grid_size,Double_Boxing)
    instance_create((x_place+1)*grid_size,(y_place+2)*grid_size,Double_Boxing)
    instance_create((x_place+2)*grid_size,(y_place+2)*grid_size,Double_Boxing)
    // Row 3
    instance_create((x_place)*grid_size,(y_place+3)*grid_size,Double_Boxing)
    instance_create((x_place+1)*grid_size,(y_place+3)*grid_size,Double_Boxing)
    instance_create((x_place+2)*grid_size,(y_place+3)*grid_size,Double_Boxing)
    // Row 4
    instance_create((x_place)*grid_size,(y_place+4)*grid_size,Double_Boxing)
    instance_create((x_place+1)*grid_size,(y_place+4)*grid_size,Double_Boxing)
    instance_create((x_place+2)*grid_size,(y_place+4    )*grid_size,Double_Boxing)
    // Line 0, Col 0
    instance_create((x_place*grid_size),(y_place*grid_size),Double_Boxing_Rock)
    instance_create((x_place*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
    instance_create((x_place*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
    // Line 0, Col 1
    instance_create(((x_place+1)*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+1)*grid_size)+18,(y_place*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+1)*grid_size),(y_place*grid_size)+18,Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Rock)
    // Line 0, Col 2
    instance_create(((x_place+2)*grid_size),(y_place*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,(y_place*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+2)*grid_size),(y_place*grid_size)+18,Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,(y_place*grid_size)+18,Double_Boxing_Dimond)
    // Line 1, Col 0
    var line;
    line = 1
    instance_create((x_place*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create((x_place*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    // Line 1, Col 1
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    // Line 1, Col 2
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 2, Col 0
    line = 2
    instance_create((x_place*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 2, Col 1
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 2, Col 2
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    // Line 3, Col 0
    line = 3
    instance_create((x_place*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create((x_place*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    // Line 3, Col 1
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    // Line 3, Col 2
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 4, Col 0
    line = 4
    instance_create((x_place*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create((x_place*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Rock)
    instance_create((x_place*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 4, Col 1
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Rock)
    instance_create(((x_place+1)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    instance_create(((x_place+1)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    // Line 4, Col 2
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size),Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size),((y_place+line)*grid_size)+18,Double_Boxing_Dimond)
    instance_create(((x_place+2)*grid_size)+18,((y_place+line)*grid_size)+18,Double_Boxing_Rock)
}

// Level 27
if (global.levelnumber==27) 
{
    var i;
    var j;
    var k;
    var l;
    // Outer Lower Column
    l = 16
    repeat(2) // Column
    {
        for (i = 7; i <= 20; i += 1) // Row
        {
            instance_create(l*grid_size,i*grid_size,Double_Boxing)
            for (j = 0; j <= 18; j += 18) // Sub Row
            {
                for (k = 0; k <= 18; k += 18) // Sub Column
                {
                    instance_create((l*grid_size)+j,(i*grid_size)+k,Double_Boxing_Dimond)
                }
            }
        }
        l = 22
    }
    // Inner Upper Column
    l = 18
    repeat(2) // Column
    {
        for (i = 2; i <= 7; i += 1) // Row
        {
            instance_create(l*grid_size,i*grid_size,Double_Boxing)
            for (j = 0; j <= 18; j += 18) // Sub Row
            {
                for (k = 0; k <= 18; k += 18) // Sub Column
                {
                    instance_create((l*grid_size)+j,(i*grid_size)+k,Double_Boxing_Dimond)
                }
            }
        }
        l = 20
    }
    // Top Middle Single Tile
    instance_create(19*grid_size, 2*grid_size, Double_Boxing)
    instance_create(19*grid_size, 2*grid_size, Double_Boxing_Dimond)
    instance_create(19*grid_size+18, 2*grid_size, Double_Boxing_Dimond)
    instance_create(19*grid_size, 2*grid_size+18, Double_Boxing_Dimond)
    instance_create(19*grid_size+18, 2*grid_size+18, Double_Boxing_Dimond)
    // Top Left Single Tile
    instance_create(17*grid_size, 7*grid_size, Double_Boxing)
    instance_create(17*grid_size, 7*grid_size, Double_Boxing_Dimond)
    instance_create(17*grid_size+18, 7*grid_size, Double_Boxing_Dimond)
    instance_create(17*grid_size, 7*grid_size+18, Double_Boxing_Dimond)
    instance_create(17*grid_size+18, 7*grid_size+18, Double_Boxing_Dimond)
    // Top Left Single Tile
    instance_create(21*grid_size, 7*grid_size, Double_Boxing)
    instance_create(21*grid_size, 7*grid_size, Double_Boxing_Dimond)
    instance_create(21*grid_size+18, 7*grid_size, Double_Boxing_Dimond)
    instance_create(21*grid_size, 7*grid_size+18, Double_Boxing_Dimond)
    instance_create(21*grid_size+18, 7*grid_size+18, Double_Boxing_Dimond)
    
}