if (instance_number(Go_Number_Red)==1)
{
    with other instance_destroy()
    instance_destroy()
}