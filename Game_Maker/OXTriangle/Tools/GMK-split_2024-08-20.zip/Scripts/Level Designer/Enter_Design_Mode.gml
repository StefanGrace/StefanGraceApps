room_goto(Level_Designer)
global.levelnumber = 100
global.designing = true