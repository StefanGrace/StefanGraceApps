if (mouse_x >= grid_size && mouse_x < 37 * grid_size)
{
    if (mouse_y >= 21 * grid_size && mouse_y < 22 * grid_size)
    {
        object_select = object_mouse_select
    }
    else if (mouse_y >= grid_size && item_select > 0 && object_select > -1)
    {
        var tile_x; tile_x = floor(mouse_x / grid_size) * grid_size;
        var tile_y; tile_y = floor(mouse_y / grid_size) * grid_size;
        switch (item_select)
        {
            case 1: // Player 1 characters
            case 2: // Player 2 character
            case 3: // Neutral character      
                break;
                
            case 4: // Materials              
                switch (object_select)
                {
                    case 0: 
                        Clear_Tile(tile_x, tile_y);
                        instance_create(tile_x, tile_y, Yellow);
                        break;
                    case 1: 
                        Clear_Tile(tile_x, tile_y);
                        instance_create(tile_x, tile_y, Rock); 
                        break;
                    case 2: 
                        Clear_Tile(tile_x, tile_y);    
                        instance_create(tile_x, tile_y, Dimond);
                        break;
                    case 3: 
                        Clear_Tile(tile_x, tile_y);
                        instance_create(tile_x, tile_y, Concreet); 
                        break;
                    case 4:
                        Clear_Tile(tile_x, tile_y);
                        instance_create(tile_x, tile_y, Yellow);
                        instance_create(tile_x, tile_y, Mud);
                        break;
                    case 5:
                        Create_Double_Boxing(tile_x, tile_y, Double_Boxing_Yellow);
                        break;
                    case 6:
                        Create_Double_Boxing(tile_x, tile_y, Double_Boxing_Rock);
                        break;
                    case 7:
                        Create_Double_Boxing(tile_x, tile_y, Double_Boxing_Dimond);
                        break;
                    case 8:
                        instance_create(tile_x, tile_y, Barria_Horizontal_Image);
                        break;
                    case 9:
                        instance_create(tile_x, tile_y, Barria_Vertical_Image);
                        break;
                    
                }
                break;
            
            case 5: // Angers/Ports  
                var port_color, anger_color; 
                port_color = -1;
                anger_color = -1;
                switch (object_select)
                {
                    case 0: anger_color = Red_Anger; break;
                    case 1: anger_color = Orange_Anger; break;
                    case 2: anger_color = Blue_Anger; break;
                    case 3: anger_color = Purple_Anger; break;
                    case 4: port_color = 1; break;
                    case 5: port_color = 0; break;
                    case 6: port_color = 2; break;
                    case 7: port_color = 3; break;
                    case 8: port_color = 4; break;
                    case 9: port_color = 5; break;
                    case 10: port_color = 6; break;
                    case 11: port_color = 7; break;
                }
                
                if (anger_color != -1)
                {
                    Clear_Tile(tile_x, tile_y);
                    instance_create(tile_x, tile_y, Yellow);
                    instance_create(tile_x, tile_y, anger_color);
                }
                
                if (port_color != -1)
                {   
                    var port_number; 
                    port_number = 0;
                    with (Teleport)
                    {
                        if (color == port_color) {port_number += 1;}
                    }
                    if (port_number < 2)
                    {
                        Clear_Tile(tile_x, tile_y);
                        instance_create(tile_x, tile_y, Yellow);
                        var port;
                        port = instance_create(tile_x, tile_y, Teleport);
                        port.side = port_number + 1;
                        port.color = port_color;
                    }
                    else
                    {
                        show_message("Each teleport color can only have 2 sides.");
                    }
                }
                break;
        }
    }
}