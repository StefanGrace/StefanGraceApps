Level_Designer_Control.object_select = -1
Level_Designer_Control.item_select = selection_index