if (mouse_y >= 21 * grid_size && mouse_y < 22 * grid_size)
{
    object_mouse_select = floor(mouse_x / grid_size) - 1
}
else
{
    object_mouse_select = -1
}