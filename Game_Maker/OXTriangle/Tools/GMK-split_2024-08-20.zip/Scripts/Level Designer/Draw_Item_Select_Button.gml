// Draw_Item_Select_Button
// Stefan Grace
// Created: 2024-08-05
// Modified: 2024-08-05
// This script draw the item select buttons at the top of the Level Designer


draw_set_font(Level_Designer_Item_Select_Font)
draw_set_halign(fa_center)
draw_set_valign(fa_middle)
draw_set_color(button_color)

if (Level_Designer_Control.item_select == selection_index)
{
    draw_rectangle(x, y, x + sprite_width, y + sprite_height, false)
    draw_set_color(c_white)
}
else
{
    var button_sprite;
    switch (button_color)
    {
        case c_red: button_sprite = Player_One_Sprite; break;
        case c_black: button_sprite = Player_Two_Sprite; break;
        case c_lime: button_sprite = Player_Random_Sprite; break;
        default: button_sprite = Level_Design_Button_Sprite; break;
    }
    draw_sprite(button_sprite, 0, x, y)
}

draw_text(x + round(sprite_width / 2), y + round(sprite_height / 2), button_text)
draw_set_halign(0)
draw_set_valign(0)


