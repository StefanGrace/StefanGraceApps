/* arguments
    argument0 - tile_x
    argument1 - tile_y
    argument2 - type of Double Boxing

*/

var tile_x; tile_x = argument0;
var tile_y; tile_y = argument1;

var double_boxing_present;
with (Double_Boxing)
{
    if (x == tile_x && y == tile_y) {double_boxing_present = true;}
}

if (!double_boxing_present) 
{
    Clear_Tile(tile_x, tile_y);
    instance_create(tile_x, tile_y, Double_Boxing);
    instance_create(tile_x, tile_y, argument2);
    instance_create(tile_x + 18, tile_y, argument2);
    instance_create(tile_x, tile_y + 18, argument2);
    instance_create(tile_x + 18, tile_y + 18, argument2);
}
else
{
    var db_tile_x, db_tile_y;
    
    if (mouse_x - tile_x < 18)
    {
        db_tile_x = tile_x;
    }
    else
    {
        db_tile_x = tile_x + 18;
    }
    
    if (mouse_y - tile_y < 18)
    {
        db_tile_y = tile_y;
    }
    else
    {
        db_tile_y = tile_y + 18;
    }
    
    instance_create(db_tile_x, db_tile_y, argument2);
}