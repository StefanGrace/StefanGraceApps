var tile_x; tile_x = argument0;
var tile_y; tile_y = argument1;

objects_to_remove[0] = Tile;
objects_to_remove[1] = Double_Boxing;
objects_to_remove[2] = Teleport;

var i;
for (i = 0; i < 3; i += 1)
{
    with (objects_to_remove[i])
    {
        if (x == tile_x && y == tile_y) {instance_destroy();}
    }
}

with (Double_Boxing_Tile)
{
    if ((x == tile_x || x = tile_x + 18) && (y == tile_y || y == tile_y + 18)) {instance_destroy();}
}