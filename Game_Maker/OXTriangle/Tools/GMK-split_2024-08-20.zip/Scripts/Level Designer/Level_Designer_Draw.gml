var char_draw_offset; char_draw_offset = 9;
var dray_y; draw_y = 21 * grid_size;
draw_set_font(Character_Font)
draw_set_halign(fa_center)
draw_set_valign(fa_center)

switch(item_select)
{
    case 1: // Player 1 characters
    case 2: // Player 2 character
    case 3: // Neutral character
        var num_tiles;
        var background;
        switch (item_select)
        {
            case 1:
            case 2:
                num_tiles = 36
                background = Yellow_Sprite
                break;
            case 3:
                num_tiles = 35
                background = Yellow_Sprite
                break;
        }
        var i;
        for(i = 0; i < num_tiles; i += 1)
        {
            switch(item_select)
            {
                case 1: draw_set_color(character_color_red); break;
                case 2: draw_set_color(character_color_black); break;
                case 3: draw_set_color(character_color_green); break;        
            }
            if (object_select == i || object_mouse_select == i)
            {
                draw_set_color(character_color_blue)
            }
            var draw_x; draw_x = (i * grid_size) + grid_size;
            draw_sprite(background, 0, draw_x, draw_y)
            var sprite;
            switch (i)
            {
                case 2:
                    
                    switch (draw_get_color())
                    {
                        case character_color_red: sprite = Red_Triangle_Sprite; break;
                        case character_color_black: sprite = Black_Triangle_Sprite; break;
                        case character_color_green: sprite = Green_Triangle_Sprite; break;
                        case character_color_blue: sprite = Blue_Triangle; break;
                    }
                    draw_sprite(sprite, 0, draw_x, draw_y)
                    break
                case 4:
                    switch (draw_get_color())
                    {
                        case character_color_red: sprite = Red_Square_Sprite; break;
                        case character_color_black: sprite = Black_Square_Sprite; break;
                        case character_color_green: sprite = Green_Square_Sprite; break;
                        case character_color_blue: sprite = Blue_Square; break;
                    }
                    draw_sprite(sprite, 0, draw_x, draw_y)
                    break
                case 13:
                    switch (draw_get_color())
                    {
                        case character_color_red: sprite = G_R_3hit; break;
                        case character_color_black: sprite = G_B_3hit; break;
                        case character_color_green: sprite = G_G_3hit; break;
                        case character_color_blue: sprite = G_Bl_3hit; break;
                    }
                    draw_sprite(sprite, 0, draw_x, draw_y)
                    break;
                case 25:
                    draw_text(draw_x + 17, draw_y + 17, "Gigga#G")
                    break;
                case 31:
                    switch (draw_get_color())
                    {
                        case character_color_red: sprite = Red_Pi_Sprite; break;
                        case character_color_black: sprite = Black_Pi_Sprite; break;
                        case character_color_green: sprite = Green_Pi_Sprite; break;
                        case character_color_blue: sprite = Blue_Pi; break;
                    }
                    draw_sprite(Concreet_Sprite, 0, draw_x, draw_y)
                    draw_sprite(sprite, 0, draw_x, draw_y)
                    break;
                case 33:
                    switch (draw_get_color())
                    {
                        case character_color_red: sprite = Big_W_R_1hit; break;
                        case character_color_black: sprite = Big_W_B_1hit; break;
                        case character_color_green: sprite = Big_W_G_1hit; break;
                        case character_color_blue: sprite = Big_W_Bl_1hit; break;
                    }
                    draw_sprite(sprite, 0, draw_x, draw_y)
                    break;
                case 34:
                    draw_text(draw_x + 17, draw_y + 17, "Terror#G")
                    break;
                case 35:
                    switch (draw_get_color())
                    {
                        case character_color_red: draw_set_color(character_color_purple); break;
                        case character_color_black: draw_set_color(character_color_dark_blue); break;
                    }
                    draw_text(draw_x + char_draw_offset, draw_y + char_draw_offset, "?")
                    break;                  
                default:
                    draw_text(draw_x + char_draw_offset, draw_y + char_draw_offset, global.character_text[i])
                    break; 
            }
            
        }
        break;
    
    case 4: // Materials
        var i;
        for(i = 0; i < 10; i += 1)
        {
            var draw_x; draw_x = (i * grid_size) + grid_size;
            var sprite;
            switch (i)
            {
                case 0: sprite = Yellow_Sprite; break;
                case 1: sprite = Rock_Sprite; break;
                case 2: sprite = Dimond_Sprite; break;
                case 3: sprite = Concreet_Sprite; break;
                case 4: sprite = Mud_Sprite; break;
                case 5: sprite = Double_Boxing_Yellow_Sprite break;
                case 6: sprite = Double_Boxing_Rock_Sprite; break;
                case 7: sprite = Double_Boxing_Dimond_Sprite; break;
                case 8: sprite = Horizontal_Barria; break;
                case 9: sprite = Vertical_Barria; break;
            }
            switch (i)
            {
                case 5:
                case 6:
                case 7:
                    draw_sprite(sprite, -1, draw_x, draw_y)
                    draw_sprite(sprite, -1, draw_x + 18, draw_y)
                    draw_sprite(sprite, -1, draw_x, draw_y + 18)
                    draw_sprite(sprite, -1, draw_x + 18, draw_y + 18)
                    break;
                default: 
                    draw_sprite(sprite, -1, draw_x, draw_y)
                    break;
            }
            
        }
        break;
        
    case 5: // Angers/Ports
        var i;
        for(i = 0; i < 12; i += 1)
        {
            var draw_x; draw_x = (i * grid_size) + grid_size;
            var sprite;
            switch (i)
            {
                case 0: sprite = Red_Anger_Sprite; break;
                case 1: sprite = Blue_Anger_Sprite; break;
                case 2: sprite = Orange_Anger_Sprite; break;
                case 3: sprite = Purple_Anger_Sprite; break;
                case 4: sprite = Teleport_Dark_Blue; break;
                case 5: sprite = Teleport_Brown; break;
                case 6: sprite = Teleport_Forest_Green; break;
                case 7: sprite = Teleport_Grey; break;
                case 8: sprite = Teleport_Green; break;
                case 9: sprite = Teleport_Light_Blue; break;
                case 10: sprite = Teleport_Orange; break;
                case 11: sprite = Teleport_Pink; break;
            }
            draw_sprite(Yellow_Sprite, 0, draw_x, draw_y)
            draw_sprite(sprite, animation_frame, draw_x, draw_y)
        }
        break;
        
    case 6: // Boulder/Bombs
        var i;
        for(i = 0; i < 6; i += 1)
        {
            var draw_x; draw_x = (i * grid_size) + grid_size;
            var sprite;
            switch (i)
            {
                case 0: sprite = Boulder_Sprite; break;
                case 1: sprite = Tunnling_Bomb_Sprite; break;
                case 2: sprite = Dimond_Bomb_Sprite; break;
                case 3: sprite = Nuclear_Bomb_Sprite; break;
                case 4: sprite = J_Bomb_Sprite; break;
                case 5: sprite = Time_Bomb_Sprite; break;
            }
            draw_sprite(Yellow_Sprite, 0, draw_x, draw_y)
            draw_sprite(sprite, 5, draw_x, draw_y)
        }
        break;
        
    case 7: // Other
        var i;
        for(i = 0; i < 11; i += 1)
        {
            var draw_x; draw_x = (i * grid_size) + grid_size;
            var sprite;
            switch (i)
            {
                case 0: sprite = Up_Arrow_Sprite; break;
                case 1: sprite = Down_Arrow_Sprite; break;
                case 2: sprite = Left_Arrow_Sprite; break;
                case 3: sprite = Right_Arrow_Sprite; break;
                case 4: sprite = Horizontal_Arrow_Sprite; break;
                case 5: sprite = Vertical_Arrow_Sprite; break;
                case 6: sprite = Steel_Sprite; break;
                case 7: sprite = Switch_Sprite; break;
                case 8: sprite = Gate_Vertical_Sprite; break;
                case 9: sprite = Gate_Horizontal_Sprite; break;
                case 10: sprite = Steel_Sprite; break;
            }
            draw_sprite(Rock_Sprite, 0, draw_x, draw_y)
            draw_sprite(sprite, animation_frame, draw_x, draw_y)
            switch (i)
            {
                case 10: 
                    draw_set_color(c_red)
                    draw_text(draw_x + 17, draw_y + 17, "NWH")
                    break;
            }
        }
        break;
}

draw_set_halign(0)
draw_set_valign(0)

animation_frame += 1