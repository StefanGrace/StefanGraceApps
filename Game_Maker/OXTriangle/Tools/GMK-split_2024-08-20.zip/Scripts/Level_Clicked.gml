global.Date_Order = 0
global.Time_Format = 0
global.Date_Time_Order = 0
global.Year_Format = 0
global.Month_Format = 0
