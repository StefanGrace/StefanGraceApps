// Date_Time_Room_Background
// Stefan Grace
// Created: 2016-06-26
// Modifed: 2016-07-14
// This script displays the text on the date time room

// This block of code sets the font and color of the text
draw_set_font(Room_Font)
draw_set_color(c_white)

// This block of code displays the text
draw_text(910,105,global.text_date_order)
draw_text(70,385,global.text_year_format)
draw_text(35,105,global.text_date_time_order)
draw_text(490,385,global.text_time_format)
draw_text(490,105,global.text_month_format)