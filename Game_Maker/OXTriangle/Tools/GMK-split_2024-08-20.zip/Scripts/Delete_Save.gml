var file_path, lvl_num_text;
lvl_num_text = string_replace_all(string_format(global.levelnumber, 2, 0), " ", "0")
file_path = working_directory + "\Saves\Level_" + lvl_num_text + ".txt"
if (file_exists(file_path) && !file_attributes(file_path, fa_readonly)) file_delete(file_path)