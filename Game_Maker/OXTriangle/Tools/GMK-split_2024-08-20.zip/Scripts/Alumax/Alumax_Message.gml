// Alumax Message
// Stefan Grace
// Created: I don't know
// Modified: 2020-02-10

show_message (global.text_alumax_message)
script_execute(Alumax_Creation)

/* UNUSED LINES OF CODE
show_message ("Alumax is not yet Implemented.#Coming Soon!!!")
*/