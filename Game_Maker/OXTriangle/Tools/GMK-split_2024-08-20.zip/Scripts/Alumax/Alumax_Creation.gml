// Alumax Creation
// Stefan Grace
// Created: 2015-06-16
// Modified: 2017-12-23

script_execute(Save_Global)
if (file_exists(working_directory+"\Alumax\Alumax.exe")) 
{
    execute_shell(working_directory+"\Alumax\Alumax.exe",0)
}
