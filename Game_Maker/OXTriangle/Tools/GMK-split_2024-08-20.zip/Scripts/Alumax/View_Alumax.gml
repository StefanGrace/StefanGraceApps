// View Alumax
// Stefan Grace
// Created: 2015-06-26
// Modified: 2017-08-09
// This script is executed when the use clicks the 'View Alumax' link in the top left corner of a massage at the start of a level

var alumax_page;
if (global.levelnumber==1) alumax_page = 3
if (global.levelnumber==4) alumax_page = 100
if (global.levelnumber==5) alumax_page = 101
if (global.levelnumber==6) alumax_page = 4
if (global.levelnumber==9) alumax_page = 5
if (global.levelnumber==10) alumax_page = 102
if (global.levelnumber==11) alumax_page = 6
if (global.levelnumber==12) alumax_page = 103
if (global.levelnumber==13) alumax_page = 7
if (global.levelnumber==14) alumax_page = 104
if (global.levelnumber==15) alumax_page = 8
if (global.levelnumber==17) alumax_page = 105
if (global.levelnumber==18) alumax_page = 9
if (global.levelnumber==19) alumax_page = 106
if (global.levelnumber==20) alumax_page = 10
if (global.levelnumber==21) alumax_page = 11
if (global.levelnumber==22) alumax_page = 107
if (global.levelnumber==23) alumax_page = 12
if (global.levelnumber==25) alumax_page = 13
if (global.levelnumber==26) alumax_page = 108
if (global.levelnumber==27) alumax_page = 14
var file;
if (file_exists(working_directory+"\Alumax\Page.txt"))
{
    file = file_text_open_write(working_directory + "\Alumax\Page.txt")
}
file_text_write_real(file,alumax_page)
file_text_close(file)
script_execute(Alumax_Creation)

