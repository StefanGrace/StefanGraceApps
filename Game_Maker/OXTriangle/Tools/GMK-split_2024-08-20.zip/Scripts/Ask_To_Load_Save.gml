if (!file_exists(working_directory + "\Saves\Level_" + string_replace_all(string_format(global.levelnumber, 2, 0), " ", "0") + ".txt"))
{
    exit
}

switch (global.levelnumber)
{
    case 16: 
        switch (show_message_ext(global.text_load_game, "&" + global.text_continue, "&" + global.text_restart, global.text_cancel))
        {
            case 1:
                Connect_4_Load()
                with(Background_Object) instance_destroy()
                break;
            case 2:
                Delete_Save()
                break;
            default:
                room_goto(Level_Select_1)
                break;
        }
        break;
}