// Explosion_Script
// Stefan Grace
// Created: 2016-08-23
// Modified: 2018-11-08
// This script controls all explosions

// Makes it not explode outside the room
if (x<0) or (y<0) or (x>room_width-35) or (y>room_height) instance_destroy()

// Makes concreet block explosions
if (place_meeting(x,y,Concreet)) instance_destroy()

// Makes it explode explodable things
script_execute(Object_Destroy)
script_execute(Character_Explosion_Destroy)
with (Mud) if (place_meeting(x,y,other)) instance_change(Mud_Explode,true)
with (Teleport) if (place_meeting(x,y,other)) alarm [1] = 1
alarm[2] = 1

// Makes explotions take 1 hit off a G
with (Red_Stuned_G) script_execute(G_Explode)
with (Black_Stuned_G) script_execute(G_Explode)
with (Red_G) script_execute(G_Explode)
with (Black_G) script_execute(G_Explode)
with (Red_Blue_G) script_execute(G_Explode)
with (Black_Blue_G) script_execute(G_Explode)
with (Green_G)
{
    script_execute(G_Explode)
    if (place_meeting(x,y,other))
    {
        if (g_type == 1 or g_type == 2)
        {
            with (Rock) if (place_meeting(x,y,other)) instance_destroy()
            with (Dimond) if (place_meeting(x,y,other)) instance_destroy()
            with (Mud) if (place_meeting(x,y,other)) instance_change(Mud_Explode,true)
        }
    }
}

// Makes HWH explosions not explode off the edge
if (instance_number(NWH_Explosion_Center) > 0)
{
    if (x<=0) or (y<=0) or (x>=room_width-36) or (y>=room_height-35) instance_destroy()
}

// Makes it not explode non-explodeage things
if (place_meeting(x,y,Steel)) 
or (place_meeting(x,y,Date_Time))
or (place_meeting(x,y,Go_Number_Black))
or (place_meeting(x,y,Go_Number_Red))
or (place_meeting(x,y,Draw_Mode_Black))
or (place_meeting(x,y,Draw_Mode_Red))
or (place_meeting(x,y,Level_Number_Object))
or (place_meeting(x,y,NWH_Object))
or (place_meeting(x,y,Gate_Object))
or (place_meeting(x,y,Switch))
{
    alarm[1] = 2
}
else
{
    // Turns the explotion into yellow
    alarm[0] = 2
}