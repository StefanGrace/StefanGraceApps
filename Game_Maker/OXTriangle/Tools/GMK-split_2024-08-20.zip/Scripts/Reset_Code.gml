// Reset Script
// Stefan Grace
// Created: 2015-06-19
// Modifed: 2016-07-14
// This script resets the whole game when the player cicks  the 'reset' button

//sets the appreance of the message
message_background (Message_background)
message_button (Message_button) 
message_button_font (font,11,blue,bold)

//resets the game
if(show_question(global.text_reset_message_a+"#"+global.text_reset_message_b))
{
    global.Level_0_Save = 0
    global.Level_1_Save = 0
    global.Level_2_Save = 0
    global.Level_3_Save = 0
    global.Level_4_Save = 0
    global.Level_5_Save = 0
    global.Level_6_Save = 0
    global.Level_7_Save = 0
    global.Level_8_Save = 0
    global.Level_9_Save = 0
    global.Level_10_Save = 0
    global.Level_11_Save = 0
    global.Level_12_Save = 0
    global.Date_Order = 0
    global.Time_Format = 0
    global.Date_Time_Order = 0
    global.Year_Format = 0
    global.Month_Format = 0
    room_goto(Main_Menu_Room)
    show_message(global.text_reset_message_c+"#"+global.text_reset_message_d) 
}
