if vk_right or vk_left or vk_down or vk_up 
instance_change (Yellow,false);