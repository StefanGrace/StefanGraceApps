if (g_hit >= Get_Max_Hits(g_type)) exit
g_hit += 1
Red_Blue_G.g_hit -= 1
Black_Blue_G.g_hit -= 1
score -= 1