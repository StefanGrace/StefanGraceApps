// G_Explode
// Stefan Grcae
// Created: 2018-10-25
// Modified: 2018-11-08
// This script makes explosions take 1 hit off a G, Gigga G or Terror G

if (place_meeting(x,y,other)) 
{
    if (instance_number(NWH_Explosion_Center) > 0)
    {
        instance_destroy()
    }
    else 
    {
        if (!been_exploded) 
        {
            g_hit -= 1
            been_exploded = true;
            alarm[0] = 3
        }
    }
}
    
