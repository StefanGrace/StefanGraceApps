// Blue_Attack_G
// Stefan Grace
// Created: 2020-02-10
// Modified: 2020-02-10

// Makes a stunned G, Gigga G or Terror lose a hit when a blue (clicked on) 
// character enters any of tiles that it is on

/* arguments
    argument0 = stun (S)
        true = stun
        false = kill
*/

g_size = Get_G_Size(g_type)
var i;
for (i = 0; i < g_size; i += grid_size) 
{
    var j;
    for (j = 0; j < g_size; j += grid_size) 
    {
        if (x + i == other.x and y + j == other.y) 
        {
            if (argument0) 
            {
                S_Stuned = 1
            }
            else 
            {
                g_hit -= 1
            }
        }
    }
}