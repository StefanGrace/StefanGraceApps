var max_hits;
switch(argument0)
{
    case 0:
        max_hits = 3
        break
    case 1:
        max_hits = 5
        break
    case 2:
        max_hits = 10
        break
    case 3:
        max_hits = 5
        break
}
return max_hits