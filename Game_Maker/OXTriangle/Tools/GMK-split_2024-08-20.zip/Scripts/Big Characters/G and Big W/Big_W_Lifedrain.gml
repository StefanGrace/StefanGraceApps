// Big_W_Lifedrain
// Stefan Grace
// Created: 2017-12-21
// Modified: 2018-11-01

if (g_type!=3) exit

global.big_w_life_draining = false;
global.big_w_life_giving = false;
with(Move_Message) instance_destroy()

var x_jump;
var y_jump;
var i;
var j;
var g_in_range;
g_in_range = false
for (j = 0; j < 4; j+= 1)
{
    switch(j)
    {
        case 0:
            x_jump = 1 * grid_size
            y_jump = 0 * grid_size
            break
        case 1:
            x_jump = 0 * grid_size
            y_jump = 1 * grid_size
            break
        case 2:
            x_jump = -1 * grid_size
            y_jump = 0 * grid_size
            break
        case 3:
            x_jump = 0 * grid_size
            y_jump = -1 * grid_size
            break
    }
    for (i = 1; i <= 5; i += 1)
    {
        if (!place_meeting(x + (x_jump * i), y + (y_jump * i), Yellow))
        {
            i = 6
        }
        if (place_meeting(x + (x_jump * i), y + (y_jump * i), Red_Stuned_G))
        or (place_meeting(x + (x_jump * i), y + (y_jump * i), Black_Stuned_G))
        or (place_meeting(x + (x_jump * i), y + (y_jump * i), Red_G))
        or (place_meeting(x + (x_jump * i), y + (y_jump * i), Black_G))
        {
            g_in_range = true;
            
        }
    }
}

if (g_in_range)
{
    global.message_type = 24
    script_execute(Local_Message_Create)
    instance_create(Message_Object.x + 100, Message_Object.y + 50, Life_Drain_Button)
    instance_create(Message_Object.x + 100, Message_Object.y + 105, Life_Give_Button)
}
else
{
    show_message(global.text_no_g_in_range)
}


/*
with(all)
{
    if (character_id==13 and g_type!=3 and other.g_hit<=4)
    {
        if (place_meeting(x+grid_size,y,other) and argument0==0)
        or (place_meeting(x,y+grid_size,other) and argument0==1)
        or (place_meeting(x-grid_size,y,other) and argument0==2)
        or (place_meeting(x,y-grid_size,other) and argument0==3)
        {
            g_hit -= 1
            other.g_hit += 1
            score -= 1
        }
    }
}
*/