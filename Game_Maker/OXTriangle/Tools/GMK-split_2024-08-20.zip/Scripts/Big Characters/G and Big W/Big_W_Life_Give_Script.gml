// Big_W_Life_Give_Script
// Stefan Grace
// Created: 2018-11-01
// Modified: 2018-11-01


global.big_w_life_giving = true
with(Message_Object) instance_destroy()
global.message_type = 23
script_execute(Local_Message_Create)

