// G_Die
// Stefan Grace
// Created: 2017-08-07
// Modified: 2017-08-07
// This scipt makes G's die when they have less than 1 hit left

if (g_hit<1) instance_destroy()