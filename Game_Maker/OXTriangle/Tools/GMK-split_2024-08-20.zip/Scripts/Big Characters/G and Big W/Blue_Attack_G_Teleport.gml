// Blue_Attack_G_Teleport
// Stefan Grace
// Created: 2020-02-14
// Modified: 2020-02-14
// This script blue (clicked on) characters attack or stun G or Big W in the other side of a teleport

/* arguments
    argument0 = stun (S)
        true = stun
        false = kill
        
    argument1 = teleport color
*/


with(Teleport)
{
    if (place_meeting(x,y,other) and color == argument1)
    {
        with(other)
        {
            if (argument0) 
            {
                S_Stuned = 1
            }
            else 
            {
                g_hit -= 1
            }
        }
    }
}