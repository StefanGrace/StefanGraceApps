// Big_W_Range_Detect
// Stefan Grace
// Created: 2018-11-01
// Modified: 2018-11-04
// This script returns weather there is a blue Big W within range

return Character_Range_Detect(2)
