// G_Move
// Stefan Grace
// Created: 2016-08-23
// Modified: 2020-02-24
// This script controls G, Gigga G, Terror G and Big W

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
*/


if (global.game_frozen>0) exit
if (instance_number(Level_Cover) > 0) exit

if (S_Stuned>0) 
{
    show_message (global.text_s_stun)
    exit
}

// Stop the player pressing 2 arrow keys at once
if (Key_Mash_Detect(argument0)) exit

if (g_type==3) // Big W
{
    // Barria
    if (argument0==0) and (place_meeting(x,y,Barria_Vertical)) exit
    if (argument0==1) and (place_meeting(x,y,Barria_Horizontal)) exit
    if (argument0==2) and (place_meeting(x+grid_size,y,Barria_Vertical)) exit
    if (argument0==3) and (place_meeting(x,y+grid_size,Barria_Horizontal)) exit
    // Arrow
    if (argument0==0) and ((place_meeting(x-35,y,Right_Arrow)) or (place_meeting(x-35,y,Horizontal_Arrow))) exit
    if (argument0==1) and ((place_meeting(x,y-35,Down_Arrow)) or (place_meeting(x,y-35,Vertical_Arrow))) exit
    if (argument0==2) and ((place_meeting(x+35,y,Left_Arrow)) or (place_meeting(x+35,y,Horizontal_Arrow))) exit
    if (argument0==3) and ((place_meeting(x,y+35,Up_Arrow)) or (place_meeting(x,y+35,Vertical_Arrow))) exit
    if (!(argument0==0)) and (place_meeting(x,y,Left_Arrow)) exit 
    if (!(argument0==1)) and (place_meeting(x,y,Up_Arrow)) exit 
    if (!(argument0==2)) and (place_meeting(x,y,Right_Arrow)) exit 
    if (!(argument0==3)) and (place_meeting(x,y,Down_Arrow)) exit 
    if ((argument0==0) or (argument0==2)) and (place_meeting(x,y,Vertical_Arrow)) exit
    if ((argument0==1) or (argument0==3)) and (place_meeting(x,y,Horizontal_Arrow)) exit
}

if (place_meeting(x,y,Mud)) exit

var X_Jump;
var Y_Jump;
X_Jump = 0
Y_Jump = 0
if (argument0==0) X_Jump = 0-grid_size
if (argument0==1) Y_Jump = 0-grid_size
if (argument0==2) X_Jump = grid_size
if (argument0==3) Y_Jump = grid_size

if (g_type==3) // Big W
{
    // Boulder
    if (argument0==0) or (argument0==2)
    {
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*2,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*3,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*4,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*4,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*5,y+Y_Jump,Yellow))) exit
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump,y+Y_Jump,Mud)) exit
    }
    if (argument0==1) or (argument0==3)
    {
        if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) exit
    }
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Left_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Right_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump*2,y,Barria_Vertical)) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump,y,Barria_Vertical)) exit
    if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Left_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Right_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Up_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Down_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Vertical_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
    // Anger Colors
    if (place_meeting(x+X_Jump,y+Y_Jump,Red_Anger))
    {
        score = 1+1
        background_index[0] = -1
        background_color = c_red
        Kill = 1
        RockTunnle = 0
        DimondTunnle = 0
        script_execute(Red_Stun)
        script_execute(Black_Stun)
        global.anger = 1
    }
    if (place_meeting(x+X_Jump,y+Y_Jump,Orange_Anger))
    {
        score = 1+1
        background_index[0] = -1
        background_color = $4080FF
        Kill = 0
        RockTunnle = 1
        DimondTunnle = 0
        script_execute(Red_Stun)
        script_execute(Black_Stun)
        global.anger = 1
    }
    if (place_meeting(x+X_Jump,y+Y_Jump,Blue_Anger))
    {
        score = 1+1
        background_index[0] = -1
        background_color = $FFFF00
        Kill = 0
        RockTunnle = 0
        DimondTunnle = 1
        script_execute(Red_Stun)
        script_execute(Black_Stun)
        global.anger = 1
    }
    if (place_meeting(x+X_Jump,y+Y_Jump,Purple_Anger))
    {
        score = 1+1
        background_index[0] = -1
        background_color = $FF00FF
        Kill = 1
        RockTunnle = 1
        DimondTunnle = 1
        script_execute(Red_Stun)
        script_execute(Black_Stun)
        global.anger = 1
    }
    // Anger Numbers
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_00)) score = 0+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_02)) score = 2+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_03)) score = 3+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_04)) score = 4+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_05)) score = 5+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_06)) score = 6+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_07)) score = 7+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_08)) score = 8+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_09)) score = 9+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_10)) score = 10+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_11)) score = 11+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_12)) score = 12+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_13)) score = 13+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_14)) score = 14+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_15)) score = 15+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_16)) score = 16+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_17)) score = 17+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_18)) score = 18+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_19)) score = 19+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_20)) score = 20+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_21)) score = 21+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_22)) score = 22+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_23)) score = 23+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_24)) score = 24+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_25)) score = 25+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_26)) score = 26+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_27)) score = 27+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_28)) score = 28+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_29)) score = 29+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_30)) score = 30+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_31)) score = 31+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_32)) score = 32+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_33)) score = 33+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_34)) score = 34+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_35)) score = 35+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_36)) score = 36+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_37)) score = 37+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_38)) score = 38+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_39)) score = 39+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_40)) score = 40+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_41)) score = 41+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_42)) score = 42+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_43)) score = 43+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_44)) score = 44+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_45)) score = 45+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_46)) score = 46+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_47)) score = 47+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_48)) score = 48+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_49)) score = 49+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_50)) score = 50+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_51)) score = 51+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_52)) score = 52+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_53)) score = 53+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_54)) score = 54+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_55)) score = 55+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_56)) score = 56+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_57)) score = 57+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_58)) score = 58+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_59)) score = 59+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_60)) score = 60+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_61)) score = 61+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_62)) score = 62+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_63)) score = 63+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_64)) score = 64+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_65)) score = 65+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_66)) score = 66+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_67)) score = 67+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_68)) score = 68+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_69)) score = 69+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_70)) score = 70+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_71)) score = 71+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_72)) score = 72+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_73)) score = 73+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_74)) score = 74+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_75)) score = 75+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_76)) score = 76+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_77)) score = 77+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_78)) score = 78+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_79)) score = 79+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_80)) score = 80+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_81)) score = 81+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_82)) score = 82+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_83)) score = 83+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_84)) score = 84+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_85)) score = 85+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_86)) score = 86+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_87)) score = 87+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_88)) score = 88+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_89)) score = 89+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_90)) score = 90+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_91)) score = 91+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_92)) score = 92+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_93)) score = 93+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_94)) score = 94+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_95)) score = 95+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_96)) score = 96+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_97)) score = 97+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_98)) score = 98+1
    if (place_meeting(x+X_Jump,y+Y_Jump,Anger_99)) score = 99+1
    // Rock and Dimond
    if (RockTunnle>0) with (Rock) if (place_meeting(x,y,other)) instance_destroy()
    if (DimondTunnle>0) with (Dimond) if (place_meeting(x,y,other)) instance_destroy()
    // Own Characters
    var character_detect;
    with(Character)
    {
        if (((player==1 and other.player==1) or (player==2 and other.player==2)) and place_meeting(x-X_Jump,y-Y_Jump,other) and character_id!=13) character_detect = true
    }
    var big_w_player;
    big_w_player = player
    with(Teleport) // Stops Big W getting into teleport if there is own character in other side and makes Big W interact with opponent's character on other side
    {
        if (place_meeting(x-X_Jump,y-Y_Jump,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    with (Character)
                    {
                        if (place_meeting(x,y,other))
                        {
                            if ((player==1 and big_w_player==1) or (player==2 and big_w_player==2) or g_type==3) character_detect = true
                            if (((player==1 and big_w_player==2) or (player==2 and big_w_player==1)) and !character_detect) alarm[11] = 2
                        }
                    }
                }
            }
        }
    }
    if (character_detect) exit
}

if (g_type == 1)
{
    X_Jump *= 2
    Y_Jump *= 2
}
if (g_type == 2)
{
    X_Jump *= 4
    Y_Jump *= 4
}

var g_in_the_way;
g_in_the_way = false
with(Red_Stuned_G)
{
    if (g_type == other.g_type)
    {
        var g_size;
        switch(g_type)
        {
            case 1:
                g_size = 2
                break
            case 2:
                g_size = 4
                break
            default:
                g_size = 1
                break
        }
        var other_g_size;
        switch(other.g_type)
        {
            case 1:
                other_g_size = 2
                break
            case 2:
                other_g_size = 4
                break
            default:
                other_g_size = 1
                break
        }
        if (argument0==0) 
        {
            if (x + (g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==2)
        {
            if (x - (other_g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==1)
        {
            if (y + (g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==3)
        {
            if (y - (other_g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
    }
}
with(Red_G)
{
    if (g_type == other.g_type)
    {
        var g_size;
        switch(g_type)
        {
            case 1:
                g_size = 2
                break
            case 2:
                g_size = 4
                break
            default:
                g_size = 1
                break
        }
        var other_g_size;
        switch(other.g_type)
        {
            case 1:
                other_g_size = 2
                break
            case 2:
                other_g_size = 4
                break
            default:
                other_g_size = 1
                break
        }
        if (argument0==0) 
        {
            if (x + (g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==2)
        {
            if (x - (other_g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==1)
        {
            if (y + (g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==3)
        {
            if (y - (other_g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
    }
}
with(Black_Stuned_G)
{
    if (g_type == other.g_type)
    {
        var g_size;
        switch(g_type)
        {
            case 1:
                g_size = 2
                break
            case 2:
                g_size = 4
                break
            default:
                g_size = 1
                break
        }
        var other_g_size;
        switch(other.g_type)
        {
            case 1:
                other_g_size = 2
                break
            case 2:
                other_g_size = 4
                break
            default:
                other_g_size = 1
                break
        }
        if (argument0==0) 
        {
            if (x + (g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==2)
        {
            if (x - (other_g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==1)
        {
            if (y + (g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==3)
        {
            if (y - (other_g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
    }
}
with(Black_G)
{
    if (g_type == other.g_type)
    {
        var g_size;
        switch(g_type)
        {
            case 1:
                g_size = 2
                break
            case 2:
                g_size = 4
                break
            default:
                g_size = 1
                break
        }
        var other_g_size;
        switch(other.g_type)
        {
            case 1:
                other_g_size = 2
                break
            case 2:
                other_g_size = 4
                break
            default:
                other_g_size = 1
                break
        }
        if (argument0==0) 
        {
            if (x + (g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==2)
        {
            if (x - (other_g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==1)
        {
            if (y + (g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==3)
        {
            if (y - (other_g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
    }
}
with(Green_G) 
{
    if (g_type >= other.g_type)
    {
        var g_size;
        switch(g_type)
        {
            case 1:
                g_size = 2
                break
            case 2:
                g_size = 4
                break
            default:
                g_size = 1
                break
        }
        var other_g_size;
        switch(other.g_type)
        {
            case 1:
                other_g_size = 2
                break
            case 2:
                other_g_size = 4
                break
            default:
                other_g_size = 1
                break
        }
        if (argument0==0) 
        {
            if (x + (g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==2)
        {
            if (x - (other_g_size * grid_size) == other.x and y >= other.y - ((g_size - 1) * grid_size) and y <= other.y + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==1)
        {
            if (y + (g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
        else if (argument0==3)
        {
            if (y - (other_g_size * grid_size) == other.y and x >= other.x - ((g_size - 1) * grid_size) and x <= other.x + ((other_g_size - 1) * grid_size)) g_in_the_way = true
        }
    }
}

// Makes G lose hits when there is a character that can attack it on the other side of a teleport
var gX_Jump gY_Jump;
gX_Jump = X_Jump / (Get_G_Size(g_type) / grid_size)
gY_Jump = Y_Jump / (Get_G_Size(g_type) / grid_size)
show_debug_message(string(gX_Jump)+" "+string(gY_Jump))
if (place_meeting(x+gX_Jump,y+gY_Jump,Teleport)) 
{
    var killers_in_port;
    killers_in_port = 0
    var g_player;
    if (instance_number(Go_Number_Red)>0) g_player = 1
    if (instance_number(Go_Number_Black)>0) g_player = 2
    var other_g_type;
    other_g_type = g_type
    var other_g_hit;
    other_g_hit = g_hit
    with(Teleport)
    {
        if (place_meeting(x-gX_Jump,y-gY_Jump,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    with (Character)
                    {
                        if (place_meeting(x,y,other))
                        {
                            switch(character_id)
                            {   case 13:
                                    if (g_type == other_g_type)
                                    { 
                                        exit
                                    }
                                    else 
                                    {
                                        if (player != g_player) 
                                        {
                                            killers_in_port += g_hit
                                            g_hit -= other_g_hit
                                        }
                                        else
                                        {
                                            instance_destroy()
                                        }
                                    }
                                    break 
                                case 1:
                                case 2:
                                case 3:
                                case 7:
                                case 9:
                                case 14:
                                case 20:
                                    if (player != g_player)
                                    {
                                        killers_in_port += 1
                                    }
                                    break
                            }
                        }
                    }
                }
            }
        }
    }
    g_hit -= killers_in_port
}

if (((place_meeting(x+X_Jump,y+Y_Jump,Yellow) 
or place_meeting(x+X_Jump,y+Y_Jump,Rock) 
or place_meeting(x+X_Jump,y+Y_Jump,Dimond) 
or place_meeting(x+X_Jump,y+Y_Jump,Concreet)
or place_meeting(x+X_Jump,y+Y_Jump,Double_Boxing)) 
and g_type!=3) or (place_meeting(x+X_Jump,y+Y_Jump,Yellow) or (place_meeting(x+X_Jump,y+Y_Jump,Rock) and RockTunnle>0) or (place_meeting(x+X_Jump,y+Y_Jump,Dimond) and DimondTunnle>0) and g_type==3))
and (!g_in_the_way)
{
    if (g_type == 1)
    {
        X_Jump /= 2
        Y_Jump /= 2
    }
    if (g_type == 2)
    {
        X_Jump /= 4
        Y_Jump /= 4
    }
    // Steel
    if (place_meeting(x+X_Jump,y+Y_Jump,Steel)) exit
    // Gates
    var gate_in_the_way;
    gate_in_the_way = false
    if (argument0==0) with (Barria_Vertical) if (place_meeting(x,y,other) and gate) gate_in_the_way = true
    if (argument0==1) with (Barria_Horizontal) if (place_meeting(x,y,other) and gate) gate_in_the_way = true
    if (argument0==2) with (Barria_Vertical) if (place_meeting(x-X_Jump,y,other) and gate) gate_in_the_way = true
    if (argument0==3) with (Barria_Horizontal) if (place_meeting(x,y-Y_Jump,other) and gate) gate_in_the_way = true 
    if (g_type == 1 or g_type == 2) // to make it so Big G's can't get through adjacent barriers
    {
        if (argument0==0 or argument0==2) with (Barria_Horizontal) if (place_meeting(x-X_Jump,y,other) and place_meeting(x-X_Jump,y-grid_size,other) and gate) gate_in_the_way = true 
        if (argument0==1 or argument0==3) with (Barria_Vertical) if (place_meeting(x,y-Y_Jump,other) and place_meeting(x-grid_size,y-Y_Jump,other) and gate) gate_in_the_way = true 
    }
    if (gate_in_the_way) exit
    //////// DOES THE ACTUAL MOVEMENT /////////
    x += X_Jump
    y += Y_Jump
    ///////////////////////////////////////////
    if (Kill==0)
    {
        if (instance_number(Go_Number_Black)>0)
        {
            if (place_meeting(x,y,Red_Stuned_X)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_Triangle)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_A)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_E)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_S)) S_Stuned = 1
            if (place_meeting(x,y,Red_Stuned_H)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_C)) g_hit -= 1
            if (place_meeting(x,y,Red_Stuned_P)) g_hit -= 1
            with(Red_Stuned_G) script_execute(G_Fight)
            with(Black_G) script_execute(G_Kill_Own_G)
        }
        if (instance_number(Go_Number_Red)>0)
        {
            if (place_meeting(x,y,Black_Stuned_X)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_Triangle)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_A)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_E)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_S)) S_Stuned = 1
            if (place_meeting(x,y,Black_Stuned_H)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_C)) g_hit -= 1
            if (place_meeting(x,y,Black_Stuned_P)) g_hit -= 1
            with(Black_Stuned_G) script_execute(G_Fight)
            with(Red_G) script_execute(G_Kill_Own_G)
        }
    }
    if (g_type!=3) 
    {
        script_execute(Object_Destroy)
        with (Teleport) if (place_meeting(x,y,other)) alarm[1] = 1
    }
    script_execute(Character_Explosion_Destroy)
    with (Concreet) if (place_meeting(x,y,other)) instance_destroy()
    with (Red_Stuned_Pi) if (place_meeting(x,y,other)) instance_destroy()
    with (Red_Pi) if (place_meeting(x,y,other)) instance_destroy()
    with (Black_Stuned_Pi) if (place_meeting(x,y,other)) instance_destroy()
    with (Black_Pi) if (place_meeting(x,y,other)) instance_destroy()
    with (Green_Pi) if (place_meeting(x,y,other)) instance_destroy()
    with (Green_G) if (place_meeting(x,y,other)) instance_destroy()
    if (argument0==0) with (Barria_Vertical) if (place_meeting(x+X_Jump,y,other)) instance_destroy()
    if (argument0==1) with (Barria_Horizontal) if (place_meeting(x,y+Y_Jump,other)) instance_destroy()
    if (argument0==2) with (Barria_Vertical) if (place_meeting(x,y,other)) instance_destroy()
    if (argument0==3) with (Barria_Horizontal) if (place_meeting(x,y,other)) instance_destroy() 
    if (g_type == 1 or g_type == 2) // to make it so Big G's destroy adjacent barriers
    {
        if (argument0==0 or argument0==2) with (Barria_Horizontal) if (place_meeting(x,y,other) and place_meeting(x,y-grid_size,other)) instance_destroy()
        if (argument0==1 or argument0==3) with (Barria_Vertical) if (place_meeting(x,y,other) and place_meeting(x-grid_size,y,other)) instance_destroy()
    }
    if (!place_meeting(x,y,Yellow)) instance_create(x,y,Yellow)
    if (g_type == 1) // to make Gigga G's leave yellow behind them
    {
        instance_create(x+grid_size,y,Yellow)
        instance_create(x,y+grid_size,Yellow)
        instance_create(x+grid_size,y+grid_size,Yellow)
    } 
    if (g_type == 2) // to make Terror G's leave yellow behind them
    {
        var i;
        for (i = 0; i < 4; i += 1)
        {
            var j;
            for (j = 0; j < 4; j += 1)
            {
                instance_create(x + (grid_size * i), y + (grid_size * j), Yellow)
            }
        }
    } 
    score -= 1
}