// G_Fight
// Stefan Grace
// Created: 2018-10-25
// Modified: 2018-10-25
// This script makes G's loose hits or die when they interact with the opponent's G of a differnt size

if(place_meeting(x,y,other))
{
    hits_to_be_removed = other.g_hit
    other.hits_to_be_removed = g_hit
    if (other.g_hit - other.hits_to_be_removed > 0) 
    {
        other.g_hit -= other.hits_to_be_removed
    }
    else
    {
        other.alarm[1] = 1
    }
    if (g_hit - hits_to_be_removed > 0) 
    {
        g_hit -= hits_to_be_removed
    }
    else
    {
        alarm[1] = 1
    }
}
