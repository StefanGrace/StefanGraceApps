// Big_G_Mask
// Stefan Grace
// Created: 2018-10-23
// Modified: 2018-10-24
// This scirpt updates the mask for Gigga G and Terror G

if (g_type == 1)
{
    if (mask_index != Gigga_Colission_Mask) mask_index = Gigga_Colission_Mask
}
if (g_type == 2)
{
    if (mask_index != Terror_Colission_Mask) mask_index = Terror_Colission_Mask
}