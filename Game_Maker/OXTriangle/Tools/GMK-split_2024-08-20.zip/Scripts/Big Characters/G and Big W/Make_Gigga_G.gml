// Make_Gigga_G
// Stefan Grace
// Created: 2017-12-14
// Modified: 2017-12-14


g_type = 1
g_hit = 5