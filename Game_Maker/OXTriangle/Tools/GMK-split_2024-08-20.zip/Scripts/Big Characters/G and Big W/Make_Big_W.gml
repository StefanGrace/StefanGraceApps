// Make_Big_W
// Stefan Grace
// Created: 2017-12-20
// Modified: 2017-12-20


g_type = 3
g_hit = 1