// G_Draw
// Stefan Grace
// Created: 2017-08-07
// Modified: 2018-11-01
// This script draws out G's with the right amount of hits in the right color

/* arguments
   
     argument0 - color
        0 - Blue
        1 - Red
        2 - Black
        3 - Green                
        4 - Yellow
        5 - Purple
        6 - Dark Blue

*/

if (S_Stuned>0 and g_type != 1 and g_type != 2) draw_sprite_ext(Ice,0,x-1,y-1,2,2,0,c_white,1) 

if (g_type==0) // G
{
    if (argument0==0)
    {
        if (g_hit==1) draw_sprite(G_Bl_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_Bl_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_Bl_3hit,0,x,y)
    }
    else if (argument0==1)
    {
        if (g_hit==1) draw_sprite(G_R_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_R_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_R_3hit,0,x,y)
    }
    else if (argument0==2)
    {
        if (g_hit==1) draw_sprite(G_B_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_B_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_B_3hit,0,x,y)
    }
    else if (argument0==3)
    {
        if (g_hit==1) draw_sprite(G_G_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_G_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_G_3hit,0,x,y)
    }
    else if (argument0==4)
    {
        if (g_hit==1) draw_sprite(G_Y_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_Y_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_Y_3hit,0,x,y)
    }
    else if (argument0==5)
    {
        if (g_hit==1) draw_sprite(G_P_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_P_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_P_3hit,0,x,y)
    }
    else if (argument0==6)
    {
        if (g_hit==1) draw_sprite(G_DB_1hit,0,x,y)
        if (g_hit==2) draw_sprite(G_DB_2hit,0,x,y)
        if (g_hit==3) draw_sprite(G_DB_3hit,0,x,y)
    }
}
else if (g_type==1) // Gigga G 
{
    
    if (place_meeting(x,y,Mud))
    {
        draw_sprite(Gigga_Mud,0,x,y)
    }
    else if (place_meeting(x,y,Rock))
    {
        draw_sprite(Gigga_Rock,0,x,y)
    }
    else if (place_meeting(x,y,Dimond))
    {
        draw_sprite(Gigga_Dimond,0,x,y)
    }
    else if (place_meeting(x,y,Concreet))
    {
        draw_sprite(Gigga_Concreet,0,x,y)
    }
    else 
    {
        draw_sprite(Gigga_Yellow,0,x,y)
    }
    if (S_Stuned>0)
    {
        draw_sprite_ext(Ice,0,x-2,y-2,4,4,0,c_white,1)
    }
    if (argument0==0)
    {
        if (g_hit==1) draw_sprite(GiggaG_Bl_1hit,0,x,y)
        if (g_hit==2) draw_sprite(GiggaG_Bl_2hit,0,x,y)
        if (g_hit==3) draw_sprite(GiggaG_Bl_3hit,0,x,y)
        if (g_hit==4) draw_sprite(GiggaG_Bl_4hit,0,x,y)
        if (g_hit==5) draw_sprite(GiggaG_Bl_5hit,0,x,y)
    }
    else if (argument0==1)
    {
        if (g_hit==1) draw_sprite(GiggaG_R_1hit,0,x,y)
        if (g_hit==2) draw_sprite(GiggaG_R_2hit,0,x,y)
        if (g_hit==3) draw_sprite(GiggaG_R_3hit,0,x,y)
        if (g_hit==4) draw_sprite(GiggaG_R_4hit,0,x,y)
        if (g_hit==5) draw_sprite(GiggaG_R_5hit,0,x,y)
    }
    else if (argument0==2)
    {
        if (g_hit==1) draw_sprite(GiggaG_B_1hit,0,x,y)
        if (g_hit==2) draw_sprite(GiggaG_B_2hit,0,x,y)
        if (g_hit==3) draw_sprite(GiggaG_B_3hit,0,x,y)
        if (g_hit==4) draw_sprite(GiggaG_B_4hit,0,x,y)
        if (g_hit==5) draw_sprite(GiggaG_B_5hit,0,x,y)
    }
    else if (argument0==3)
    {
        if (g_hit==1) draw_sprite(GiggaG_G_1hit,0,x,y)
        if (g_hit==2) draw_sprite(GiggaG_G_2hit,0,x,y)
        if (g_hit==3) draw_sprite(GiggaG_G_3hit,0,x,y)
        if (g_hit==4) draw_sprite(GiggaG_G_4hit,0,x,y)
        if (g_hit==5) draw_sprite(GiggaG_G_5hit,0,x,y)
    }
}
else if (g_type==2) // Tera G
{

    if (place_meeting(x,y,Mud))
    {
        draw_sprite(Terror_Mud,0,x,y)
    }
    else if (place_meeting(x,y,Rock))
    {
        draw_sprite(Terror_Rock,0,x,y)
    }
    else if (place_meeting(x,y,Dimond))
    {
        draw_sprite(Terror_Dimond,0,x,y)
    }
    else if (place_meeting(x,y,Concreet))
    {
        draw_sprite(Terror_Concreet,0,x,y)
    }
    else 
    {
        draw_sprite(Terror_Yellow,0,x,y)
    }
    if (S_Stuned>0)
    {
        draw_sprite_ext(Ice,0,x-4,y-4,8,8,0,c_white,1)
    }
    if (argument0==0)
    {
        if (g_hit==1) draw_sprite(Terror_G_Bl_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Terror_G_Bl_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Terror_G_Bl_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Terror_G_Bl_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Terror_G_Bl_5hit,0,x,y)
        if (g_hit==6) draw_sprite(Terror_G_Bl_6hit,0,x,y)
        if (g_hit==7) draw_sprite(Terror_G_Bl_7hit,0,x,y)
        if (g_hit==8) draw_sprite(Terror_G_Bl_8hit,0,x,y)
        if (g_hit==9) draw_sprite(Terror_G_Bl_9hit,0,x,y)
        if (g_hit==10) draw_sprite(Terror_G_Bl_10hit,0,x,y)
    }
    else if (argument0==1)
    {
        if (g_hit==1) draw_sprite(Terror_G_R_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Terror_G_R_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Terror_G_R_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Terror_G_R_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Terror_G_R_5hit,0,x,y)
        if (g_hit==6) draw_sprite(Terror_G_R_6hit,0,x,y)
        if (g_hit==7) draw_sprite(Terror_G_R_7hit,0,x,y)
        if (g_hit==8) draw_sprite(Terror_G_R_8hit,0,x,y)
        if (g_hit==9) draw_sprite(Terror_G_R_9hit,0,x,y)
        if (g_hit==10) draw_sprite(Terror_G_R_10hit,0,x,y)
    }
    else if (argument0==2)
    {
        if (g_hit==1) draw_sprite(Terror_G_B_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Terror_G_B_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Terror_G_B_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Terror_G_B_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Terror_G_B_5hit,0,x,y)
        if (g_hit==6) draw_sprite(Terror_G_B_6hit,0,x,y)
        if (g_hit==7) draw_sprite(Terror_G_B_7hit,0,x,y)
        if (g_hit==8) draw_sprite(Terror_G_B_8hit,0,x,y)
        if (g_hit==9) draw_sprite(Terror_G_B_9hit,0,x,y)
        if (g_hit==10) draw_sprite(Terror_G_B_10hit,0,x,y)
    }
    else if (argument0==3)
    {
        if (g_hit==1) draw_sprite(Terror_G_G_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Terror_G_G_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Terror_G_G_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Terror_G_G_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Terror_G_G_5hit,0,x,y)
        if (g_hit==6) draw_sprite(Terror_G_G_6hit,0,x,y)
        if (g_hit==7) draw_sprite(Terror_G_G_7hit,0,x,y)
        if (g_hit==8) draw_sprite(Terror_G_G_8hit,0,x,y)
        if (g_hit==9) draw_sprite(Terror_G_G_9hit,0,x,y)
        if (g_hit==10) draw_sprite(Terror_G_G_10hit,0,x,y)
    }
}
else // Big W
{
    if (argument0==0)
    {
        if (g_hit==1) draw_sprite(Big_W_Bl_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_Bl_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_Bl_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_Bl_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_Bl_5hit,0,x,y)
    }
    else if (argument0==1)
    {
        if (g_hit==1) draw_sprite(Big_W_R_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_R_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_R_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_R_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_R_5hit,0,x,y)
    }
    else if (argument0==2)
    {
        if (g_hit==1) draw_sprite(Big_W_B_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_B_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_B_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_B_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_B_5hit,0,x,y)
    }
    else if (argument0==3)
    {
        if (g_hit==1) draw_sprite(Big_W_G_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_G_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_G_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_G_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_G_5hit,0,x,y)
    }
    else if (argument0==4)
    {
        if (g_hit==1) draw_sprite(Big_W_Y_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_Y_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_Y_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_Y_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_Y_5hit,0,x,y)
    }
    else if (argument0==5)
    {
        if (g_hit==1) draw_sprite(Big_W_P_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_P_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_P_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_P_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_P_5hit,0,x,y)
    }
    else if (argument0==6)
    {
        if (g_hit==1) draw_sprite(Big_W_DB_1hit,0,x,y)
        if (g_hit==2) draw_sprite(Big_W_DB_2hit,0,x,y)
        if (g_hit==3) draw_sprite(Big_W_DB_3hit,0,x,y)
        if (g_hit==4) draw_sprite(Big_W_DB_4hit,0,x,y)
        if (g_hit==5) draw_sprite(Big_W_DB_5hit,0,x,y)
    }
}