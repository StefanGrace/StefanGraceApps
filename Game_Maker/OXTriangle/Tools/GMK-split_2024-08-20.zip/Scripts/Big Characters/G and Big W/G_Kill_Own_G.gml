if (place_meeting(x,y,other))
{
	var g_rank;
	if (g_type == 3)
	{
		g_rank = -1
	}
	else
	{
		g_rank = g_type
	}
	var other_g_rank
	if (other.g_type == 3)
	{
		other_g_rank = -1
	}
	else
	{
		other_g_rank = other.g_type
	}
	if (other_g_rank > g_rank)
	{
		instance_destroy()
	}
	else
	{
		with(other) instance_destroy()
	}
}