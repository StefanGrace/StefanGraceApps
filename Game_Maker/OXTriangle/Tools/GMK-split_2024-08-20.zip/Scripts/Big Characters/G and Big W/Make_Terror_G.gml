// Make_Terror_G
// Stefan Grace
// Created: 2018-10-24
// Modified: 2018-10-24


g_type = 2
g_hit = 10