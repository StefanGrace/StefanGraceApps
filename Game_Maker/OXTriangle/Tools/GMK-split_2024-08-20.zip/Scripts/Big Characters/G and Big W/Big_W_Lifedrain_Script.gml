// Big_W_Lifedrain_Script
// Stefan Grace
// Created: 2018-10-31
// Modified: 2018-10-31


global.big_w_life_draining = true
with(Message_Object) instance_destroy()
global.message_type = 23
script_execute(Local_Message_Create)

