if (global.big_w_life_draining)
{
    if (Big_W_Range_Detect()) Big_W_Drain_Life() 
}
else if (global.big_w_life_giving)
{
    if (Big_W_Range_Detect()) Big_W_Give_Life() 
}
else if (global.Black_B_Killing_Left+global.Black_B_Killing_Up+global.Black_B_Killing_Right+global.Black_B_Killing_Down == 0)
{
    Character_Click_Black()
    if (!global.at_swapping > 0 and !global.big_w_life_draining and !global.w_casting and instance_number(Level_Cover) == 0)
    {
        instance_change(Black_Blue_G, false)
    }
}