// Big_W_Port
// Stefan Grace
// Created: 2017-12-21
// Modified: 2020-02-11
// This script allows Big W to go thoug a Teleport


var port_side;
var port_color;

with(Teleport) if (place_meeting(x,y,other)) 
{
    port_side = side
    port_color = color
    with(Teleport) if (side!=port_side and color==port_color)
    {
        Red_Blue_G.x = x
        Red_Blue_G.y = y
        Black_Blue_G.x = x
        Black_Blue_G.y = y
    }
}