// Get_G_Size
// Stefan Grace
// Created: 2018-11-01
// Modified: 2018-11-01

/* arguments
    argument0 - g_type
        0 - Normal G
        1 - Gigga G
        2 - Terror G
        3 - Big W
*/


var g_size;
switch(argument0)
{
    case 1:
        g_size = grid_size * 2
        break
    case 2:
        g_size = grid_size * 4
        break
    default:
        g_size = grid_size
        break
}
return g_size