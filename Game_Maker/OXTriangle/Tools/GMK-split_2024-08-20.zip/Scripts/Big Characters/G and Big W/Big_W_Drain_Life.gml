if (Red_Blue_G.g_hit > 4 or Red_Blue_G.g_hit > 4) exit
g_hit -= 1
Red_Blue_G.g_hit += 1
Black_Blue_G.g_hit += 1
score -= 1