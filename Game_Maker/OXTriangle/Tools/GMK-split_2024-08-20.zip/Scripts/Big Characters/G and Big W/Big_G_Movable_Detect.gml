if (argument0 != 0)
{

}
var movable;
movable = true
var i;
for (i = 0; i < Get_G_Size(g_type); i += grid_size)
{ 
    with(Yellow)
    {
        if (x == other.x + argument0 and y == other.y + i)
        {
            movable = false
        }
    }
}

return movable