// Pi_Step
// Stefan Grace
// Created: 2017-08-15
// Modified: 2017-09-24
// This script is executed on all Pi's every step

if (place_meeting(x,y,Boulder)) script_execute(Boulder_Crush_Blue)