// Pi_Draw
// Stefan Grace
// Created: 2017-08-15
// Modified: 2017-12-23
// This script draws Pi's out in the right color

/* arguments

    argument0 - state
        0 - Red Stuned
        1 - Red
        2 - Red Blue
        3 - Black Stuned
        4 - Black
        5 - Black Blue
        6 - Green
*/


if (S_Stuned>0) draw_sprite_ext(Ice,0,x-1,y-1,2,2,0,c_white,1) 

var color;
if (argument0==0)
{
    if (global.dollar_sign_stunning>0 and mouse_x>x and mouse_x<x+sprite_width and mouse_y>y and mouse_y<y+sprite_height) 
    {
        color = character_color_blue
    }
    else
    {
        if (purple==0) color = character_color_red else color = character_color_purple
    }
}
if (argument0==1)
{
    if (mouse_x>x and mouse_x<x+sprite_width and mouse_y>y and mouse_y<y+sprite_height)
    {
        color = character_color_blue
    }
    else if (purple==0)
    {
        color = character_color_red
    }
    else
    {
        color = character_color_purple
    }
}
if (argument0==2 or argument0==5) color = character_color_blue
if (argument0==3)
{
    if (global.dollar_sign_stunning>0 and mouse_x>x and mouse_x<x+sprite_width and mouse_y>y and mouse_y<y+sprite_height) 
    {
        color = character_color_blue
    }
    else
    {
        if (purple==0) color = character_color_black else color = character_color_dark_blue
    }
}
if (argument0==4)
{
    if (mouse_x>x and mouse_x<x+sprite_width and mouse_y>y and mouse_y<y+sprite_height)
    {
        color = character_color_blue
    }
    else if (purple==0)
    {
        color = character_color_black
    }
    else
    {
        color = character_color_dark_blue
    }
}
if (argument0==6) color = character_color_green

if (color==character_color_red) draw_sprite(Red_Pi_Sprite,0,x,y)
if (color==character_color_black) draw_sprite(Black_Pi_Sprite,0,x,y)
if (color==character_color_blue) draw_sprite(Blue_Pi,0,x,y)
if (color==character_color_green) draw_sprite(Green_Pi_Sprite,0,x,y)
if (color==character_color_purple) draw_sprite(Purple_Pi,0,x,y)
if (color==character_color_dark_blue) draw_sprite(Dark_Blue_Pi,0,x,y)
