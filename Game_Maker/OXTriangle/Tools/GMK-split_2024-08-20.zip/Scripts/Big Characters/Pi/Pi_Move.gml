// Pi_Move
// Stefan Grace
// Created: 2017-08-15
// Modified: 2020-02-24

/* arguments

argument0 = Direction
    0 = Left
    1 = Up
    2 = Right
    3 = Down
*/


// Game Frozen
if (global.game_frozen>0) exit

// $ Stuned
if (S_Stuned>0) exit

// Stop the player pressing 2 arrow keys at once
if (Key_Mash_Detect(argument0)) exit

// Barria
if (argument0==0) and (place_meeting(x,y,Barria_Vertical)) exit
if (argument0==1) and (place_meeting(x,y,Barria_Horizontal)) exit
if (argument0==2) and (place_meeting(x+grid_size,y,Barria_Vertical)) exit
if (argument0==3) and (place_meeting(x,y+grid_size,Barria_Horizontal)) exit

// Arrow
if (argument0==0) and ((place_meeting(x-35,y,Right_Arrow)) or (place_meeting(x-35,y,Horizontal_Arrow))) exit
if (argument0==1) and ((place_meeting(x,y-35,Down_Arrow)) or (place_meeting(x,y-35,Vertical_Arrow))) exit
if (argument0==2) and ((place_meeting(x+35,y,Left_Arrow)) or (place_meeting(x+35,y,Horizontal_Arrow))) exit
if (argument0==3) and ((place_meeting(x,y+35,Up_Arrow)) or (place_meeting(x,y+35,Vertical_Arrow))) exit
if (!(argument0==0)) and (place_meeting(x,y,Left_Arrow)) exit 
if (!(argument0==1)) and (place_meeting(x,y,Up_Arrow)) exit 
if (!(argument0==2)) and (place_meeting(x,y,Right_Arrow)) exit 
if (!(argument0==3)) and (place_meeting(x,y,Down_Arrow)) exit 
if ((argument0==0) or (argument0==2)) and (place_meeting(x,y,Vertical_Arrow)) exit
if ((argument0==1) or (argument0==3)) and (place_meeting(x,y,Horizontal_Arrow)) exit

// Sets X_Jump and Y_Jump
var X_Jump;
var Y_Jump;
X_Jump = 0
Y_Jump = 0
if (argument0==0) X_Jump = -35
if (argument0==1) Y_Jump = -35
if (argument0==2) X_Jump = 35
if (argument0==3) Y_Jump = 35

// Detect Character
var character_detect;
with(all)
{
    if ((character_id>0 or character_o>0) and place_meeting(x-X_Jump,y-Y_Jump,other)) character_detect = true
}
if (character_detect) exit

// Angers
if place_meeting(x+X_Jump,y+Y_Jump,Red_Anger)
or place_meeting(x+X_Jump,y+Y_Jump,Orange_Anger)
or place_meeting(x+X_Jump,y+Y_Jump,Blue_Anger)
or place_meeting(x+X_Jump,y+Y_Jump,Purple_Anger)
{
    exit
}

// Teleport
if (place_meeting(x+X_Jump,y+Y_Jump,Teleport)) exit

// Boulder
if (argument0==0) or (argument0==2)
{
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*2,y+Y_Jump,Yellow))) exit
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*3,y+Y_Jump,Yellow))) exit
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*4,y+Y_Jump,Yellow))) exit
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*2,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*3,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump*4,y+Y_Jump,Boulder)) and (!(place_meeting(x+X_Jump*5,y+Y_Jump,Yellow))) exit
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) and (place_meeting(x+X_Jump,y+Y_Jump,Mud)) exit
}
if (argument0==1) or (argument0==3)
{
    if (place_meeting(x+X_Jump,y+Y_Jump,Boulder)) exit
}
if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Left_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump*2,y,Right_Arrow)) or (place_meeting(x+X_Jump*2,y,Horizontal_Arrow))) exit
if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump*2,y,Barria_Vertical)) exit
if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and (place_meeting(x+X_Jump,y,Barria_Vertical)) exit
if (argument0==2) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Left_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
if (argument0==0) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Right_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Up_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Down_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit
if ((argument0==0) or (argument0==2)) and (place_meeting(x+X_Jump,y,Boulder)) and ((place_meeting(x+X_Jump,y,Vertical_Arrow)) or (place_meeting(x+X_Jump,y,Horizontal_Arrow))) exit

// Yellow
if (place_meeting(x+X_Jump,y+Y_Jump,Yellow))
{
    with (Concreet)
    {
        if (place_meeting(x,y,other))
        {
            x += X_Jump
            y += Y_Jump
        }
    }
    instance_create(x,y,Yellow)
    x += X_Jump
    y += Y_Jump
    score -= 1
    with (Yellow)
    {
        if (place_meeting(x,y,other)) instance_destroy()
    }
    if (place_meeting(x,y,Mud)) 
    {
        with (Mud)
        {
            if (place_meeting(x,y,other)) instance_destroy()
        }
        instance_destroy()
    }
    exit
}

// Concreet
if (place_meeting(x+X_Jump,y+Y_Jump,Concreet))
{
    x += X_Jump
    y += Y_Jump
    score -= 1
    exit
}