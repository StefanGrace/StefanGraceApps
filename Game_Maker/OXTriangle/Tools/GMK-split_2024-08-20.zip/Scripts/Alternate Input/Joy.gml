// Joy
// Stefan Grace
// Created: 2020-02-24
// Modified: 2020-02-24
// This script make it so you can use a joystick as arrow keys

/* arguments
    argument0 - key
*/

if (!global.joy_press) 
{
    Press_Arrow(argument0)
    global.joy_press = true
}