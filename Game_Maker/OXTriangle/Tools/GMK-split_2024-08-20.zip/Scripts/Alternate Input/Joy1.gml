if (!Level_Number_Object.joy_button_press[1]) 
{
    Level_Number_Object.joy_button_press[1] = true
    event_perform(ev_keypress,vk_control)   
}
