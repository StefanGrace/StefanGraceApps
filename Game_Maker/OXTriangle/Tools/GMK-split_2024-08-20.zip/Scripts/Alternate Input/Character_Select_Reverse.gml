// Character_Select_Reverse
// Stefan Grace
// Created: 2020-02-24
// Modified: 2020-02-24
// This script clycles through in reverse selecting characters when the backspace key is pressed

repeat(2)
{
    var i;
    for (i = i_place; i >= 0; i -= 1)
    {
        var j;
        for (j = j_place; j >= 0; j -= 1)
        {
            var k;
            for (k = k_place; k >= 0; k -= 17)
            {
                var l;
                for (l = l_place; l >= 0; l -= 17)
                {
                    with (Black_Inactive)
                    {
                        if (y == (i*grid_size) + k and x == (j*grid_size) + l) 
                        {
                            if (character_id != 13) 
                            {
                                Character_Click_Black_Script()
                                exit
                            }
                            else 
                            {
                                G_Click_Black()
                                exit
                            }
                        }
                    }
                    with (Red_Inactive)
                    {
                        if (y == (i*grid_size) + k and x == (j*grid_size) + l) 
                        {
                            if (character_id != 13) 
                            {
                                Character_Click_Red_Script()
                                exit
                            }
                            else 
                            {
                                G_Click_Red()
                                exit
                            }
                        }
                    }
                    l_place = l - 17
                }
                l_place = 17
                k_place = k - 17
            }
            k_place = 17
            j_place = j - 1
        }
        j_place = 38
        i_place = i - 1
    }
    i_place = 22
}