// Press_Arrow
// Stefan Grace
// Created: 2020-02-24
// Modified: 2020-02-24
// This script preforms the apporiate arrow key press events when an alternate input method is used

/* arguments
    argument0 - key

*/

if (keyboard_check(vk_left) or keyboard_check(vk_up) or keyboard_check(vk_right) or keyboard_check(vk_down)) exit
if (keyboard_check(ord("A")) + keyboard_check(ord("W")) + keyboard_check(ord("D")) + keyboard_check(ord("S")) > 1) exit 
event_perform(ev_keypress, argument0)/*
with (Rock) event_perform(ev_keypress, argument0)
with (Dimond) event_perform(ev_keypress, argument0)
with (Mud) event_perform(ev_keypress, argument0)*/