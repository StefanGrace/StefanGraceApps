// Continue_Sript
// Stefan Grace
// Craeted: 2017-07-22
// Modifed: 2017-07-23
// This script gets rid of the menu when the continue button is clicked

global.game_frozen = 0
with(Menu) instance_destroy()
with(Main_Menu_Button) instance_destroy()
with(Restart) instance_destroy()
with(Music_Button) instance_destroy()
instance_destroy()