// Question_Mark_Display
// Stefan Grace
// Created: 2017-12-23
// Modified: 2020-02-27


var x_plus;
var y_plus;
x_plus = 0
y_plus = -200

var hide_pi;
hide_pi = false

with (Black_Blue)
{
    if (S_Stuned > 0) exit
}

with (Red_Blue)
{
    if (S_Stuned > 0) exit
}

with (X_Message) Close_Message()

with(Character)
{
    if (character_id==26 or purple>0)
    {
        if (state==3)
        {
            with(all)
            {
                if (character_id>0 or character_o>0)
                {
                    if (x - (x mod grid_size) == other.x - (other.x mod grid_size)) and (y - (y mod grid_size) == other.y - (other.y mod grid_size))
                    {
                        hide_pi = true
                    }
                }
            }
            instance_create(0,0,Wood_Object_Level_Cover)
            if (character_id!=0) instance_create(280+x_plus,420+y_plus,Character_Button_O)
            if (character_id!=1) instance_create(350+x_plus,420+y_plus,Character_Button_X)
            if (character_id!=2) instance_create(420+x_plus,420+y_plus,Character_Button_Triangle)
            if (character_id!=3) instance_create(490+x_plus,420+y_plus,Character_Button_A)
            if (character_id!=4) instance_create(560+x_plus,420+y_plus,Character_Button_Square)
            if (character_id!=5) instance_create(630+x_plus,420+y_plus,Character_Button_K)
            if (character_id!=6) instance_create(700+x_plus,420+y_plus,Character_Button_B)
            if (character_id!=7) instance_create(770+x_plus,420+y_plus,Character_Button_E)
            if (character_id!=8) instance_create(840+x_plus,420+y_plus,Character_Button_S)
            if (character_id!=9) instance_create(910+x_plus,420+y_plus,Character_Button_H)
            if (character_id!=10) instance_create(980+x_plus,420+y_plus,Character_Button_R)
            if (character_id!=11) instance_create(280+x_plus,490+y_plus,Character_Button_M)
            if (character_id!=12) instance_create(350+x_plus,490+y_plus,Character_Button_F)
            if (character_id!=13 or g_type!=0) instance_create(420+x_plus,490+y_plus,Character_Button_G)
            if (character_id!=14) instance_create(490+x_plus,490+y_plus,Character_Button_C)
            if (character_id!=15) instance_create(560+x_plus,490+y_plus,Character_Button_Y)
            if (character_id!=16) instance_create(630+x_plus,490+y_plus,Character_Button_Z)
            if (character_id!=17) instance_create(700+x_plus,490+y_plus,Character_Button_W)
            if (character_id!=18) instance_create(770+x_plus,490+y_plus,Character_Button_J)
            if (character_id!=19) instance_create(840+x_plus,490+y_plus,Character_Button_V)
            if (character_id!=20) instance_create(910+x_plus,490+y_plus,Character_Button_P)
            if (character_id!=21) instance_create(980+x_plus,490+y_plus,Character_Button_T)
            if (character_id!=22) instance_create(280+x_plus,560+y_plus,Character_Button_D)
            if (character_id!=23) instance_create(350+x_plus,560+y_plus,Character_Button_Q)
            if (character_id!=24) instance_create(420+x_plus,560+y_plus,Character_Button_N)
            if (character_id!=26) instance_create(490+x_plus,560+y_plus,Character_Button_Question_Mark)
            if (character_id!=27) instance_create(560+x_plus,560+y_plus,Character_Button_U)
            if (character_id!=28) instance_create(630+x_plus,560+y_plus,Character_Button_L)
            if (character_id!=29) instance_create(700+x_plus,560+y_plus,Character_Button_Dollar_Sign)
            if (character_id!=30) instance_create(770+x_plus,560+y_plus,Character_Button_At)
            if (character_id!=31 and !place_meeting(x,y,Steel) and !place_meeting(x,y,Double_Boxing) /*and !hide_pi*/) instance_create(840+x_plus,560+y_plus,Character_Button_Pi)
            if (character_id!=32) instance_create(910+x_plus,560+y_plus,Character_Button_I)
            if ((character_id!=13 or g_type!=3) /*and !hide_pi*/) instance_create(980+x_plus,560+y_plus,Character_Button_Big_W)
            instance_create(490,600,Cancel)
        }
    }
}