show_message (global.text_b_help)
