var current_month_leading_zero;
var current_day_leading_zero;
var current_hour_leading_zero;
var current_minute_leading_zero;
var current_second_leading_zero;

var date_text;
var time_text;
var level_name;
var date_time_text;

var fname;
var dir;


// Add leading zeros to date elements
if (current_month<10) current_month_leading_zero=string("0")+string(current_month) else current_month_leading_zero = current_month
if (current_day<10) current_day_leading_zero=string("0")+string(current_day) else current_day_leading_zero = current_day 
if (current_hour<10) current_hour_leading_zero=string("0")+string(current_hour) else current_hour_leading_zero = current_hour 
if (current_minute<10) current_minute_leading_zero=string("0")+string(current_minute) else current_minute_leading_zero = current_minute
if (current_second<10) current_second_leading_zero=string("0")+string(current_second) else current_second_leading_zero = current_second 

// Assesemble the date elements
date_text = string(current_year)+"-"+string(current_month_leading_zero)+"-"+string(current_day_leading_zero)
time_text = string(current_hour_leading_zero)+"-"+string(current_minute_leading_zero)+"-"+string(current_second_leading_zero)
date_time_text = date_text+" "+time_text

// Create the level name
if (!global.onlevel)
{
    level_name = "Menu"
}
else if (global.levelnumber < -10)
{
    level_name = "Test Level " + string(-global.levelnumber)
}
else if (global.levelnumber < 0)
{
    level_name = "Test Level 0" + string(-global.levelnumber)
}
else if (global.levelnumber < 10)
{
    level_name = "Level 0" + string(global.levelnumber) 
}
else 
{
    level_name = "Level " + string(global.levelnumber)
}


// Save the screenshot to the BMP file
fname = level_name + " " + date_time_text + ".bmp"
dir = working_directory + "\Screenshots\"
if (!directory_exists(dir)) directory_create(dir)

screen_save(dir + fname)