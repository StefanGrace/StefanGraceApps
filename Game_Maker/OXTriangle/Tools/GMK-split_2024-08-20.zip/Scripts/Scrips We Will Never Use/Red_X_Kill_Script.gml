// X_Kill_Script
// Stefan Grace
// Created: 2016-07-16
// Modified: 2016-07-16
// This script makes two characters interact when they are both in the same box but in differnt places

/*
argument0
    0 = No Kill
    1 = Blue Kills Stuned
    2 = Stuned Kills Blue
*/

with Red_Blue_X 
{
    if (place_snapped(35,35)) global.other_is_snapped = 1
}
if (global.other_is_snapped==1)
{
    if ((place_meeting(Red_Blue_X,x-17,y)) or (place_meeting(Red_Blue_X,x,y-17)) or (place_meeting(Red_Blue_X,x-17,y-17)))
    {
        if ((Red_Blue_X.Kill==1) or (argument0==1)) instance_destroy()
        if (argument0==2) with(Red_Blue_X) instance_destroy()
    }
    global.other_is_snapped = 0
}