draw_set_font(Go_Number);
draw_text_color(3,3,score,c_black,c_black,c_black,c_black,100);