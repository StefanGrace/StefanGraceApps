// Alumax Index Script
// Stefan Grace
// Created: 2015-06-19
// Modified: 2015-06-24

with(Alumax_Backdrop) sprite_index = Alumax_index
instance_create(280,495,Character_Button)
instance_create(700,495,Objects_Button)
if(instance_number(O_Button_Object) > 0) script_execute(Remove_Character_Buttons,0,0,0,0,0)
if(instance_number(Boulder_Button_Object) > 0) script_execute(Remove_Object_Buttons,0,0,0,0,0)
instance_destroy()