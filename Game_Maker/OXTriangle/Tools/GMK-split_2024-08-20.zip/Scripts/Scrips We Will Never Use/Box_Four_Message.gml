message_background (Message_background)
message_button (Message_button) 
message_button_font (font,11,blue,bold)
show_message (global.text_box_four_message)