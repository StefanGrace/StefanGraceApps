draw_set_font(Go_Number);
draw_text_color(x+3,y+2,Number,c_black,c_black,c_black,c_black,100);