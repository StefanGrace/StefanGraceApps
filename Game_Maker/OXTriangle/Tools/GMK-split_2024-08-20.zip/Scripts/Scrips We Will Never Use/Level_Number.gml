draw_set_font(Go_Number);
draw_text_color(0,0,global.levelnumber,c_green,c_green,c_green,c_green,100);