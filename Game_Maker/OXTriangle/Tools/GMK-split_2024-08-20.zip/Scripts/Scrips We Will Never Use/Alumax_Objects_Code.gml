// Alumax Objects Script
// Stefan Grace
// Created: 2015-06-19
// Modified: 2015-06-19

with(Alumax_Backdrop) sprite_index = Alumax_Objects
with(Character_Button) instance_destroy()
instance_create(35,642,Index_Button)
instance_create(315,490,Boulder_Button_Object)
instance_create(420,490,Bomb_Button_Object)
instance_destroy()