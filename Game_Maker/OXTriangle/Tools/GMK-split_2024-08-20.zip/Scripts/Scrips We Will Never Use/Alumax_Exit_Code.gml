// Alumax Exit
// Stefan Grace
// Created: 2015-06-16
// Modified: 2016-07-02

with(Alumax_Wood) instance_destroy()
with(Character_Button) instance_destroy()
with(Objects_Button) instance_destroy()
with(Alumax_Backdrop) instance_destroy()
with(Index_Button) instance_destroy()
if(instance_number(O_Button_Object) > 0) script_execute(Remove_Character_Buttons,0,0,0,0,0)
if(instance_number(Boulder_Button_Object) > 0) script_execute(Remove_Object_Buttons,0,0,0,0,0)
instance_destroy()
