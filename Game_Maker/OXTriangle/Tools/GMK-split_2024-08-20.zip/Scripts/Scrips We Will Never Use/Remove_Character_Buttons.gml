// Remove Character Buttons
// Stefan Grace
// Created: 2015-06-24
// Modifed: 2015-06-24

with(O_Button_Object) instance_destroy()
with(X_Button_Object) instance_destroy()
with(Triangle_Button_Object) instance_destroy()
with(A_Button_Object) instance_destroy()
with(Square_Button_Object) instance_destroy()
with(K_Button_Object) instance_destroy()
with(B_Button_Object) instance_destroy()
