// Remove Object Buttons
// Stefan Grace
// Created: 2015-06-24
// Modifed: 2015-06-24

with(Boulder_Button_Object) instance_destroy()
with(Bomb_Button_Object) instance_destroy()
