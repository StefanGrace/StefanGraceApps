if (place_meeting(x,y,Teleport))
{
    var teleport_x;
    var teleport_y;
    with(Teleport)
    {
        if (place_meeting(x,y,other))
        {
            var port_color;
            var port_side;
            port_color = color
            port_side = side
            with (Teleport)
            {
                if (color==port_color and side!=port_side)
                {
                    teleport_x = x
                    teleport_y = y
                }
            }
        }
    }
    if (other.x - (other.x mod grid_size) == teleport_x and other.y - (other.y mod grid_size) == teleport_y) 
    {
        return true
    }
}
return false