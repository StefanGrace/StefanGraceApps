message_background (Message_background)
message_button (Message_button) 
message_button_font (font,11,blue,bold)
show_message ("Only 4 characters can occupy a box at any one time")
box_of_4_red = 1