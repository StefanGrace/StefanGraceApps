draw_set_font(Go_Number);
draw_text_color(3,3,score,c_green,c_green,c_green,c_green,100);