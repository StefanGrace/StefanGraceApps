message_background (Message_background)
message_button (Message_button) 
message_button_font (font,11,blue,bold)
show_message ("Alumax is not yet Implemented.#Coming Soon!!!")
