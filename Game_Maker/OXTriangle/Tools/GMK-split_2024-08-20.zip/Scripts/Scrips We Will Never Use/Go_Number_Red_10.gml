draw_set_font(Go_Number);
draw_text_color(3,3,score,c_red,c_red,c_red,c_red,100);