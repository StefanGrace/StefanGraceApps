// Boulder_Push
// Stefan Grace
// Created: 2016-07-19
// Modified: 2016-07-19
// This is is executed when a charater pushed a boulder

if keyboard_check(vk_left) x = x-35
if keyboard_check(vk_right) x = x+35