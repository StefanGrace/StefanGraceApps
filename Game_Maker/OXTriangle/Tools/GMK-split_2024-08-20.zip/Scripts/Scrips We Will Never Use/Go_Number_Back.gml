draw_set_font(Go_Number);
draw_text_color(10,3,score,c_black,c_black,c_black,c_black,100);