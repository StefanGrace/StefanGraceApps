// Start Level 0
// Stefan Grace
// Created: 2015-06-18
// Modifed: 2015-06-18

//if (global.Level_0_Save > 0) game_load(Save_Level_0)
//else global.Level_0_Save = 1

//room_goto(Level_0)