// Alumax Characters Script
// Stefan Grace
// Created: 2015-06-19
// Modifed: 2015-06-24

with(Alumax_Backdrop) sprite_index = Alumax_Characters //changes 'Alumax - Index' to 'Alumax - Characters'
with(Objects_Button) instance_destroy() //gets rid of the objects button
instance_create(35,642,Index_Button) //creates the index button

//creates character buttons
instance_create(315,490,O_Button_Object)
instance_create(420,490,X_Button_Object)
instance_create(525,490,Triangle_Button_Object)
instance_create(630,490,A_Button_Object)
instance_create(735,490,Square_Button_Object)
instance_create(840,490,K_Button_Object)
instance_create(945,490,B_Button_Object)

//gets rid of the character button
instance_destroy()