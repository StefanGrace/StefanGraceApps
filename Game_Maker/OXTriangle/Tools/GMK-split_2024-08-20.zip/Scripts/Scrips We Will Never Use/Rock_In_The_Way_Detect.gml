var k;
if (argument0 > 0) k = 1; else if (argument0 < 0) k = -1; else k = 0
var rock_in_the_way;
var j;
for (j = argument0; j != 0; j -= k)
{
    if (!place_meeting(x - (j * grid_size), y, Yellow) and argument1 == 0)
    {
        rock_in_the_way = true;
    }
    else if (!place_meeting(x, y - (j * grid_size), Yellow) and argument1 == 1)
    {
        rock_in_the_way = true;
    }
}
return rock_in_the_way