if (Joy_Press==0)
{
    script_execute(Character_Move,argument0,argument1,argument2)
    Joy_Press=1
    alarm[1] = 15
}