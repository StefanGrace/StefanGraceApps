// Get_Neutral_Characters
// Stefan Grace
// Created: 2016-08-26
// Modified: 2016-08-26
// This script makes Player 1's character get neutral characters

if (place_meeting(x,y,Green_O)) with(Green_O) instance_change(Red_O,false)