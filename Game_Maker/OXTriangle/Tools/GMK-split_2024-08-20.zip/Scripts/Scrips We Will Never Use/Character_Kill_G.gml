// Character_Kill_G
// Stefan Grace
// Created: 2017-12-12
// Modified: 2017-12-12

// Kill
/*
with(all)
{
    if (Kill>0 
    or character_id==1 
    or character_id==2
    or character_id==3
    or character_id==7
    or character_id==9
    or character_id==14
    ){
        if(place_meeting(x,y,other))
        {
            with(other) g_hit -= 1
        }
    }
}*/