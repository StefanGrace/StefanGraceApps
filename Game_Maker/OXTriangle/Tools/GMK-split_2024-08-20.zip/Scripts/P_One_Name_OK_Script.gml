// P_One_Name_OK_Script
// Stefan Grace
// Created: 2016-07-03
// Modified: 2016-07-03
// This script sets Player 1's name when the OK button is clicked or the ENTER key is pressed

if (string_length(keyboard_string)==0)
{
    message_background (Message_background)
    message_button (Message_button) 
    message_button_font (font,11,blue,bold)
    show_message (string(global.text_player_name_change_a)+string(global.MAX_LENGTH)+string(global.text_player_name_change_b))
}
else
{
    global.Player_One = keyboard_string
    room_goto(Settings_Room)
}