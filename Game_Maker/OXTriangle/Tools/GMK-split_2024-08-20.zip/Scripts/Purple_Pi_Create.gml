// Purple_Pi_Create
// Stefan Grace
// Created: 2017-12-23
// Modified: 2017-12-23


move_snap(grid_size,grid_size)
with(Yellow)
{
    if(place_meeting(x,y,other)) instance_destroy()
}
with(Rock)
{
    if(place_meeting(x,y,other)) instance_destroy()
}
with(Dimond)
{
    if(place_meeting(x,y,other)) instance_destroy()
}
instance_create(x,y,Concreet)