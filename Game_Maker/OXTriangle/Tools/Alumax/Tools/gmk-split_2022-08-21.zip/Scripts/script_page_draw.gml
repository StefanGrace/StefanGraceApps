// script_page_draw
// Stefan Grace
// Created: 2016-09-30
// Modified: 2020-02-26
// This scrips draws out the items pages

// Dark Mode
if (global.dark)
{
    draw_rectangle_color(122,58,1242,150,0,0,0,0,0)
    draw_rectangle_color(122,167,1242,660,0,0,0,0,0)
}

// Heading
draw_set_valign(fa_center)
draw_set_font(font_heading)
draw_text(140,105,array_characters[global.var_page])
draw_set_valign(0)

// Page
draw_set_font(font_text)

// O
if (global.var_page==0) draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)

// X
if (global.var_page==1) 
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+array_kills[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,315)
    draw_text_ext(140,385,global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)
}

// Triangle, A
if (global.var_page==2 or global.var_page==3) draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+array_kills[global.var_page]+"# #"+global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)

// Square
if (global.var_page==4)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,260)
    draw_text_ext(140,315,global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)
}

// K
if (global.var_page==5)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_diamond,0,140,260)
    draw_text_ext(140,315,global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)
}

// B, D
if (global.var_page==6 or global.var_page==22)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,260)
    draw_sprite(sprite_diamond,0,175,260)
    draw_text_ext(140,315,global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+array_special[global.var_page],line_spacing,line_length)        
}

// E
if (global.var_page==7)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+array_kills[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,315)
    draw_sprite(sprite_diamond,0,175,315)
    draw_sprite(sprite_arrow_down,-1,140,315)
    draw_sprite(sprite_arrow_down,-1,175,315)
    draw_text_ext(140,375,global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)
}

// S, F
if (global.var_page==8 or global.var_page==12) draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+array_special[global.var_page],line_spacing,line_length)

// H
if (global.var_page==9)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+array_kills[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,315)
    draw_sprite(sprite_diamond,0,175,315)
    draw_sprite(sprite_arrow_horizontal,-1,140,315)
    draw_sprite(sprite_arrow_horizontal,-1,175,315)
    draw_text_ext(140,375,global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page],line_spacing,line_length)
}

// R, Y, Z, W, P, N, ?, $, @, Purple ?
if (global.var_page==10 or global.var_page==15 or global.var_page==16 or global.var_page==17 or global.var_page==20 or global.var_page==24 or global.var_page==26 or global.var_page==29 or global.var_page==30 or global.var_page==35)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+array_special[global.var_page],line_spacing,line_length)
}

// M
if (global.var_page==11)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_m[0],line_spacing,line_length)
    draw_sprite(sprite_yellow,0,140,315)
    draw_sprite(sprite_yellow,0,175,315)
    draw_sprite(sprite_yellow,0,210,315)
    draw_sprite(sprite_yellow,0,140,350)
    draw_sprite(sprite_yellow,0,175,350)
    draw_sprite(sprite_yellow,0,210,350)
    draw_sprite(sprite_yellow,0,140,385)
    draw_sprite(sprite_yellow,0,175,385)
    draw_sprite(sprite_yellow,0,210,385)
    draw_set_font(font_character)
    draw_text_color(177,350,"M",0,0,0,0,1)
    draw_set_font(font_text)
    draw_text_ext(140,440,"* "+global.special_m[1]+"# #* "+global.special_m[2],line_spacing,line_length)
}

// G
if (global.var_page==13)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+global.text_all+"# #"+global.text_weakness+": "+array_weakness[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_g[0],line_spacing,line_length)
    if (global.dark) draw_sprite(sprite_diagram_g_dark,0,140,455) else draw_sprite(sprite_diagram_g,0,140,455)
}

// C
if (global.var_page==14) draw_text(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+array_kills[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_c[0]+"# #* "+global.special_c[2]+"# #* "+global.special_c[3]+"# #* "+global.special_c[4])

// J
if (global.var_page==18)
{
    // Text
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_j[0],line_spacing,line_length)
    // Line 0
    draw_sprite(sprite_rock,0,140,315)
    draw_sprite(sprite_rock,0,175,315)
    draw_sprite(sprite_yellow,0,210,315)
    draw_sprite(sprite_rock,0,245,315)
    draw_sprite(sprite_rock,0,280,315)
    // Line 1
    draw_sprite(sprite_rock,0,140,350)
    draw_sprite(sprite_rock,0,175,350)
    draw_sprite(sprite_yellow,0,210,350)
    draw_sprite(sprite_rock,0,245,350)
    draw_sprite(sprite_rock,0,280,350)
    // Line 2
    draw_sprite(sprite_yellow,0,140,385)
    draw_sprite(sprite_yellow,0,175,385)
    draw_sprite(sprite_yellow,0,210,385)
    draw_sprite(sprite_yellow,0,245,385)
    draw_sprite(sprite_yellow,0,280,385)
    // Line 3
    draw_sprite(sprite_rock,0,140,420)
    draw_sprite(sprite_rock,0,175,420)
    draw_sprite(sprite_yellow,0,210,420)
    draw_sprite(sprite_rock,0,245,420)
    draw_sprite(sprite_rock,0,280,420)
    // Line 3
    draw_sprite(sprite_rock,0,140,455)
    draw_sprite(sprite_rock,0,175,455)
    draw_sprite(sprite_yellow,0,210,455)
    draw_sprite(sprite_rock,0,245,455)
    draw_sprite(sprite_rock,0,280,455)
    // Character
    draw_set_font(font_character)
    draw_text_color(212,385,"J",0,0,0,0,1)
    draw_set_font(font_text)
    // Text
    draw_text_ext(140,500,"* "+global.special_m[1]+"# #* "+global.special_m[2],line_spacing,line_length)
}

// V
if (global.var_page==19) draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_kills+": "+global.text_all+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_v[0]+"#"+global.special_v[1]+"#"+global.special_v[2]+"# #* "+global.special_v[3],line_spacing,line_length)

// T
if (global.var_page==21)
{
    if (global.var_page_num==0)
        {
            draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_t[0],line_spacing,line_length)
            draw_sprite(sprite_rock,0,140,350)
            draw_sprite(sprite_yellow,0,175,350)
            draw_sprite(sprite_yellow,0,210,350)
            draw_sprite(sprite_yellow,0,245,350)
            draw_sprite(sprite_yellow,0,280,350)
            draw_sprite(sprite_yellow,0,315,350)
            draw_sprite(sprite_rock,0,350,350)
            draw_set_font(font_character)
            draw_text_color(140,350,"T",0,0,0,0,1)
            draw_text_color(350,350,"T",0,0,0,0,1)
            draw_set_font(font_text)
            draw_text_ext(140,420,global.special_t[2],line_spacing,line_length)
            draw_text(140,595,global.text_next_click)
        }
    if (global.var_page_num==1)
    {
        // Line 0
        draw_sprite(sprite_rock,0,140,175)
        draw_sprite(sprite_yellow,0,175,175)
        draw_sprite(sprite_yellow,0,210,175)
        draw_sprite(sprite_yellow,0,245,175)
        draw_sprite(sprite_yellow,0,280,175)
        draw_sprite(sprite_yellow,0,315,175)
        draw_sprite(sprite_yellow,0,350,175)
        draw_sprite(sprite_rock,0,385,175)
        // Line 1
        draw_sprite(sprite_yellow,0,140,210)
        draw_sprite(sprite_yellow,0,175,210)
        draw_sprite(sprite_yellow,0,210,210)
        draw_sprite(sprite_yellow,0,245,210)
        draw_sprite(sprite_yellow,0,280,210)
        draw_sprite(sprite_yellow,0,315,210)
        draw_sprite(sprite_yellow,0,350,210)
        draw_sprite(sprite_yellow,0,385,210)
        // Line 2
        draw_sprite(sprite_yellow,0,140,245)
        draw_sprite(sprite_yellow,0,175,245)
        draw_sprite(sprite_yellow,0,210,245)
        draw_sprite(sprite_yellow,0,245,245)
        draw_sprite(sprite_yellow,0,280,245)
        draw_sprite(sprite_yellow,0,315,245)
        draw_sprite(sprite_yellow,0,350,245)
        draw_sprite(sprite_yellow,0,385,245)
        // Line 3
        draw_sprite(sprite_yellow,0,140,280)
        draw_sprite(sprite_yellow,0,175,280)
        draw_sprite(sprite_yellow,0,210,280)
        draw_sprite(sprite_yellow,0,245,280)
        draw_sprite(sprite_yellow,0,280,280)
        draw_sprite(sprite_yellow,0,315,280)
        draw_sprite(sprite_yellow,0,350,280)
        draw_sprite(sprite_yellow,0,385,280)
        // Line 4
        draw_sprite(sprite_yellow,0,140,315)
        draw_sprite(sprite_yellow,0,175,315)
        draw_sprite(sprite_yellow,0,210,315)
        draw_sprite(sprite_yellow,0,245,315)
        draw_sprite(sprite_yellow,0,280,315)
        draw_sprite(sprite_yellow,0,315,315)
        draw_sprite(sprite_yellow,0,350,315)
        draw_sprite(sprite_yellow,0,385,315)
        // Line 5
        draw_sprite(sprite_rock,0,140,350)
        draw_sprite(sprite_yellow,0,175,350)
        draw_sprite(sprite_yellow,0,210,350)
        draw_sprite(sprite_yellow,0,245,350)
        draw_sprite(sprite_rock,0,280,350)
        draw_sprite(sprite_yellow,0,315,350)
        draw_sprite(sprite_yellow,0,350,350)
        draw_sprite(sprite_yellow,0,385,350)
        // Line 6
        draw_sprite(sprite_rock,0,140,385)
        draw_sprite(sprite_rock,0,175,385)
        draw_sprite(sprite_rock,0,210,385)
        draw_sprite(sprite_rock,0,245,385)
        draw_sprite(sprite_yellow,0,280,385)
        draw_sprite(sprite_yellow,0,315,385)
        draw_sprite(sprite_yellow,0,350,385)
        draw_sprite(sprite_yellow,0,385,385)
        // Line 7
        draw_sprite(sprite_rock,0,140,420)
        draw_sprite(sprite_rock,0,175,420)
        draw_sprite(sprite_rock,0,210,420)
        draw_sprite(sprite_rock,0,245,420)
        draw_sprite(sprite_yellow,0,280,420)
        draw_sprite(sprite_yellow,0,315,420)
        draw_sprite(sprite_yellow,0,350,420)
        draw_sprite(sprite_yellow,0,385,420)
        // Line 8
        draw_sprite(sprite_rock,0,140,455)
        draw_sprite(sprite_rock,0,175,455)
        draw_sprite(sprite_rock,0,210,455)
        draw_sprite(sprite_rock,0,245,455)
        draw_sprite(sprite_rock,0,280,455)
        draw_sprite(sprite_yellow,0,315,455)
        draw_sprite(sprite_yellow,0,350,455)
        draw_sprite(sprite_rock,0,385,455)
        // Characters
        draw_set_font(font_character)
        draw_text_color(142,175,"T",0,0,0,0,1)
        draw_text_color(387,175,"T",0,0,0,0,1)
        draw_text_color(142,350,"T",0,0,0,0,1)
        draw_text_color(282,455,"T",0,0,0,0,1)
        draw_text_color(387,455,"T",0,0,0,0,1)
        draw_text_color(283,350,"T",0,0,0,0,1)
        draw_set_font(font_text)
        // Text
        draw_text_ext(142,490,global.special_t[3]+"# #* "+global.special_t[4]+"# #* "+global.special_t[5],line_spacing,line_length)
    }
}

// Q
if (global.var_page==23)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_q[0],line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,350)
    draw_sprite(sprite_yellow,0,175,350)
    draw_sprite(sprite_rock,0,210,350)
    draw_sprite(sprite_yellow,0,140,385)
    draw_sprite(sprite_yellow,0,175,385)
    draw_sprite(sprite_yellow,0,210,385)
    draw_sprite(sprite_rock,0,140,420)
    draw_sprite(sprite_yellow,0,175,420)
    draw_sprite(sprite_rock,0,210,420)
    draw_set_font(font_character)
    draw_text_color(177,385,"Q",0,0,0,0,1)
    draw_text_color(177,350,"q",0,0,0,0,1)
    draw_text_color(142,385,"q",0,0,0,0,1)
    draw_text_color(212,385,"q",0,0,0,0,1)
    draw_text_color(177,420,"q",0,0,0,0,1)
    draw_set_font(font_text)
    draw_text_ext(140,465,"* "+global.special_q[1]+"# #* "+global.special_q[2]+"# #* "+global.special_q[3],line_spacing,line_length)
}

// Gigga G
if (global.var_page==25)
{
    if (global.var_page_num==0)
    {
        draw_text_ext(140,175,"* "+global.special_gigga_g[0],line_spacing,line_length)
        draw_sprite(sprite_yellow,0,140,210)
        draw_sprite(sprite_yellow,0,175,210)
        draw_sprite(sprite_yellow,0,140,245)
        draw_sprite(sprite_yellow,0,175,245)
        draw_sprite(sprite_gigga_g,0,140,210)
        draw_text_ext(140,315,"* "+global.special_gigga_g[1]+"# #* "+global.special_gigga_g[2],line_spacing,line_length)
        draw_sprite(sprite_yellow,0,140,400)
        draw_sprite(sprite_yellow,0,175,400)
        draw_sprite(sprite_yellow,0,140,435)
        draw_sprite(sprite_yellow,0,175,435)
        draw_text_ext(140,505,"* "+global.special_gigga_g[3]+"# #* "+global.special_gigga_g[4]+"# #"+global.text_next_click,line_spacing,line_length)
    }
    if (global.var_page_num==1)
    {
       draw_text_ext(140,175,"* "+global.special_gigga_g[5],line_spacing,line_length)
       if (global.dark) draw_sprite(sprite_diagram_gigga_g_dark,0,140,235) else draw_sprite(sprite_diagram_gigga_g,0,140,235)
       draw_set_halign(fa_center)
       draw_text(184,308,"(2 "+global.text_hit+")")
       draw_text(275,308,"(3 "+global.text_hit+")")
       draw_text(236,273,global.text_vs)
       draw_text(179,400,global.text_dies)
       draw_set_halign(0)
       draw_text_ext(140,488,"* "+global.special_gigga_g[6],line_spacing,line_length)
    }
}

// U
if (global.var_page==27)
{
    if (global.var_page_num==0) draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_u[0]+"# #* "+global.special_u[1]+"# #* "+global.special_u[2]+"# #* "+global.special_u[3]+"# #* "+global.special_u[4]+"# # #"+global.text_next_click,line_spacing,line_length)
    if (global.var_page_num==1) draw_text_ext(140,175,"* "+global.special_u[5]+"# #* "+global.special_u[6]+"# #* "+global.special_u[7],line_spacing,line_length)
}

// L
if (global.var_page==28)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_rock,0,140,260)
    draw_text_ext(140,315,global.text_toughness+": "+array_toughness[global.var_page]+"# #"+global.text_special+": "+global.special_l[0],line_spacing,768)
    // Line 0
    draw_sprite(sprite_rock,0,1085,315)
    draw_sprite(sprite_yellow,0,1120,315)
    draw_sprite(sprite_yellow,0,1155,315)
    // Line 1
    draw_sprite(sprite_rock,0,1085,350)
    draw_sprite(sprite_yellow,0,1120,350)
    draw_sprite(sprite_rock,0,1155,350)
    // Line 2
    draw_sprite(sprite_rock,0,1085,385)
    draw_sprite(sprite_yellow,0,1120,385)
    draw_sprite(sprite_rock,0,1155,385)
    // Line 3
    draw_sprite(sprite_yellow,0,1085,420)
    draw_sprite(sprite_yellow,0,1120,420)
    draw_sprite(sprite_rock,0,1155,420)
    // line 4
    draw_sprite(sprite_rock,0,1085,455)
    draw_sprite(sprite_yellow,0,1120,455)
    draw_sprite(sprite_rock,0,1155,455)
    // Line 5
    draw_sprite(sprite_rock,0,1085,490)
    draw_sprite(sprite_yellow,0,1120,490)
    draw_sprite(sprite_rock,0,1155,490)
    // Line 6
    draw_sprite(sprite_rock,0,1085,525)
    draw_sprite(sprite_yellow,0,1120,525)
    draw_sprite(sprite_rock,0,1155,525)
    // Line 7
    draw_sprite(sprite_rock,0,1085,560)
    draw_sprite(sprite_yellow,0,1120,560)
    draw_sprite(sprite_rock,0,1155,560)
    // Line 8
    draw_sprite(sprite_yellow,0,1085,595)
    draw_sprite(sprite_yellow,0,1120,595)
    draw_sprite(sprite_rock,0,1155,595)
    // Character
    draw_set_font(font_character)
    draw_text_color(1122,595,"L",0,0,0,0,1)
    draw_set_font(font_text)
    // Arrow
    draw_sprite(sprite_diagram_l,0,1120,315)
}

// Pi
if (global.var_page==31)
{
    draw_text_ext(140,175,global.description[global.var_page],line_spacing,line_length)
    draw_sprite(sprite_concreet,0,140,225)
    draw_sprite(sprite_pi,0,157,242)
    draw_text_ext(140,295,global.text_special+": "+global.special_pi[0]+"# #* "+global.special_pi[1],line_spacing,line_length)
}

// I
if (global.var_page==32) 
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #"+global.text_tunnels+":",line_spacing,line_length)
    draw_sprite(sprite_mud,0,140,260)
    draw_text_ext(140,330,"* "+global.special_i[0]+"# #* "+global.special_i[1],line_spacing,line_length)
}

// Big W
if (global.var_page==33)
{
    draw_text_ext(140,175,global.description[global.var_page],line_spacing,line_length)
    draw_sprite(sprite_big_w,0,140,225)
    draw_text_ext(140,295,"* "+global.special_big_w[0]+"# #* "+global.special_big_w[1]+"# #* "+global.special_big_w[2]+"# #* "+global.special_big_w[3]+"# #* "+global.special_big_w[4],line_spacing,line_length)

}

// Terra G
if (global.var_page==34)
{
    draw_text_ext(140,175,"* "+global.special_terra_g[0],line_spacing,line_length)
    draw_sprite(sprite_yellow,0,140,225)
    draw_sprite(sprite_yellow,0,175,225)
    draw_sprite(sprite_yellow,0,210,225)
    draw_sprite(sprite_yellow,0,245,225)
    draw_sprite(sprite_yellow,0,140,260)
    draw_sprite(sprite_yellow,0,175,260)
    draw_sprite(sprite_yellow,0,210,260)
    draw_sprite(sprite_yellow,0,245,260)
    draw_sprite(sprite_yellow,0,140,295)
    draw_sprite(sprite_yellow,0,175,295)
    draw_sprite(sprite_yellow,0,210,295)
    draw_sprite(sprite_yellow,0,245,295)
    draw_sprite(sprite_yellow,0,140,330)
    draw_sprite(sprite_yellow,0,175,330)
    draw_sprite(sprite_yellow,0,210,330)
    draw_sprite(sprite_yellow,0,245,330)
    draw_sprite(sprite_yellow,0,140,225)
    draw_sprite(sprite_terra_g,0,140,225)
    draw_text_ext(140,400,"* "+global.special_terra_g[1]+"# #* "+global.special_terra_g[2],line_spacing,line_length)
}

// Boulder, Red Anger, Bomb, Orange Anger, Barrier, Double Boxing, Blue Anger, Diamond Bomb, Teleport, Purple Anger, Concreate Bomb, Time Bomb
if (global.var_page==100 or global.var_page==101 or global.var_page==102 or global.var_page==103 or global.var_page==104 or global.var_page==105 or global.var_page==107 or global.var_page==108 or global.var_page==111 or global.var_page==112 or global.var_page==113 or global.var_page==115)
{
    if (global.var_page!=104) draw_sprite(sprite_yellow,0,140,175)
    if (global.var_page==100) draw_sprite(sprite_boulder,0,140,175)
    if (global.var_page==101) draw_sprite(sprite_red_anger,-1,140,175)
    if (global.var_page==102) draw_sprite(sprite_bomb,0,140,175)
    if (global.var_page==103) draw_sprite(sprite_orange_anger,-1,140,175)
    if (global.var_page==107) draw_sprite(sprite_blue_anger,-1,140,175)
    if (global.var_page==111) draw_sprite(sprite_teleport,-1,140,175)
    if (global.var_page==107) draw_sprite(sprite_blue_anger,-1,140,175)
    if (global.var_page==112) draw_sprite(sprite_purple_anger,-1,140,175)
    if (global.var_page==113) draw_sprite(sprite_concreate_bomb,0,140,175)
    if (global.var_page==115) draw_sprite(sprite_time_bomb,0,140,175)
    if (global.var_page==104)
    { 
        draw_sprite(sprite_barrier_horizontal,0,140,175)
        draw_sprite(sprite_barrier_vertical,0,210,175)
    }
    if (global.var_page==105)
    {
        draw_sprite(sprite_double_boxing_rock,0,140,175)
        draw_sprite(sprite_double_boxing_rock,0,158,175)
        draw_sprite(sprite_double_boxing_rock,0,140,193)
        draw_sprite(sprite_double_boxing_rock,0,158,193)
    }
    draw_text_ext(140,245,global.description[global.var_page],line_spacing,line_length)
}
    
// Arrow
if (global.var_page==106)
{
    draw_text_ext(140,175,global.description[global.var_page],line_spacing,line_length)
    draw_sprite(sprite_arrow_right,-1,140,215)
    draw_text_ext(140,260,"* "+global.special_arrow[0],line_spacing,line_length)
}

// Concrete
if (global.var_page==109)
{
    draw_text_ext(140,175,"* "+global.special_concrete[0]+"# #* "+global.special_concrete[1],line_spacing,line_length)
    draw_text_ext(140,425,"* "+global.special_concrete[2]+"# #* "+global.special_concrete[3],line_spacing,line_length)
    
    // Line 0 
    draw_sprite(sprite_rock,0,140,285)
    draw_sprite(sprite_concreet,0,175,285)
    draw_sprite(sprite_rock,0,210,285)
    draw_sprite(sprite_rock,0,245,285)
    draw_sprite(sprite_yellow,0,280,285)
    draw_sprite(sprite_rock,0,315,285)
    // Line 1
    draw_sprite(sprite_rock,0,140,320)
    draw_sprite(sprite_concreet,0,175,320)
    draw_sprite(sprite_yellow,0,210,320)
    draw_sprite(sprite_yellow,0,245,320)
    draw_sprite(sprite_yellow,0,280,320)
    draw_sprite(sprite_yellow,0,315,320)
    // Line 2 
    draw_sprite(sprite_rock,0,140,355)
    draw_sprite(sprite_concreet,0,175,355)
    draw_sprite(sprite_rock,0,210,355)
    draw_sprite(sprite_rock,0,245,355)
    draw_sprite(sprite_yellow,0,280,355)
    draw_sprite(sprite_rock,0,315,355)
    // J
    draw_set_font(font_character)
    draw_text_color(282,320,"J",0,0,0,0,1)
    draw_set_font(font_text)
}

// Nuclear Bomb
if (global.var_page==110)
{
    draw_text_ext(140,175,global.description[global.var_page],line_spacing,line_length)
    draw_sprite(sprite_yellow,0,140,225)
    draw_sprite(sprite_nuclear_bomb,0,140,225)
    draw_text_ext(140,295,"* "+global.special_nuclear_bomb[0]+"# #* "+global.special_nuclear_bomb[1]+"# #* "+global.special_nuclear_bomb[2],line_spacing,line_length)
}

// NWH
if (global.var_page==114)
{
    draw_text_ext(140,175,global.description[global.var_page],line_spacing,line_length)
    draw_text_ext(140,425,"* "+global.special_nwh[0]+"# #* "+global.special_nwh[1]+"# #* "+global.special_nwh[2]+"# #* "+global.special_nwh[3],line_spacing,line_length)
    // Line 0
    draw_sprite(sprite_steel,0,140,215)
    draw_sprite(sprite_steel,0,175,215)
    draw_sprite(sprite_rock,0,210,215)
    draw_sprite(sprite_arrow_up,-1,210,215)
    draw_sprite(sprite_steel,0,245,215)
    draw_sprite(sprite_steel,0,280,215)
    // Line 1
    draw_sprite(sprite_steel,0,140,250)
    draw_sprite(sprite_rock,0,175,250)
    draw_sprite(sprite_rock,0,210,250)
    draw_sprite(sprite_rock,0,245,250)
    draw_sprite(sprite_steel,0,280,250)
    // Line 2
    draw_sprite(sprite_steel,0,140,285)
    draw_sprite(sprite_rock,0,175,285)
    draw_sprite(sprite_nwh,0,210,285)
    draw_text_color(220,290,"0",$00FF00,$00FF00,$00FF00,$00FF00,100)
    draw_sprite(sprite_rock,0,245,285)
    draw_sprite(sprite_steel,0,280,285)
    // Line 3
    draw_sprite(sprite_steel,0,140,320)
    draw_sprite(sprite_rock,0,175,320)
    draw_sprite(sprite_rock,0,210,320)
    draw_sprite(sprite_rock,0,245,320) 
    draw_sprite(sprite_steel,0,280,320)
    // Line 4
    draw_sprite(sprite_steel,0,140,355)
    draw_sprite(sprite_steel,0,175,355)
    draw_sprite(sprite_diamond,0,210,355)
    draw_sprite(sprite_steel,0,245,355)
    draw_sprite(sprite_steel,0,280,355)
}

// Mud
if (global.var_page==116)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #* "+global.special_mud[0]+"# #e.g.",line_spacing,line_length)
    var y_place;
    y_place = 350
    var x_pos;
        x_pos = 140
        repeat(3)
        {
            y_pos = y_place
            repeat(2)
            {
                draw_sprite(sprite_mud,0,x_pos,y_pos)
                y_pos += 35
            }
            x_pos += 35
        }
    draw_sprite(sprite_mud,0,140,y_place+70)
    draw_sprite(sprite_rock,0,175,y_place+70)
    draw_sprite(sprite_rock,0,210,y_place+70)
    draw_sprite(sprite_rock,0,140,y_place+105)
    draw_sprite(sprite_yellow,0,175,y_place+105)
    draw_set_font(font_character)
    draw_text(175,y_place+105,"M")
    draw_set_font(font_text)
    draw_sprite(sprite_rock,0,210,y_place+105)
    draw_text_ext(140,500,"* "+global.special_mud[1],line_spacing,line_length)
}

// Switch/Gate
if (global.var_page==117)
{
    draw_text_ext(140,175,global.description[global.var_page]+"# #* "+global.special_switch_gate[0]+"# #* "+global.special_switch_gate[1],line_spacing,line_length)
}

// Gigga Port
if (global.var_page==118)
{
    if (global.var_page_num==0)
    {
        draw_text_ext(140,175,"* "+global.special_gigga_port[0],line_spacing,line_length)
        draw_sprite(sprite_gigga_port,-1,140,215)
        draw_text_ext(140,285,"* "+global.special_gigga_port[1]+"# #* "+global.special_gigga_port[2]+"# #* "+global.special_gigga_port[3]+"# #* "+global.special_gigga_port[4],line_spacing,line_length)
        var y_place;
        y_place = 490
        draw_sprite(sprite_rock,0,140,y_place)
        draw_sprite(sprite_yellow,0,175,y_place)
        draw_sprite(sprite_yellow,0,210,y_place)
        draw_sprite(sprite_rock,0,245,y_place)
        draw_sprite(sprite_yellow,0,140,y_place+35)
        draw_sprite(sprite_gigga_port,-1,175,y_place+35)
        draw_sprite(sprite_yellow,0,245,y_place+35)
        draw_sprite(sprite_yellow,0,140,y_place+70)
        draw_sprite(sprite_yellow,0,245,y_place+70)
        draw_sprite(sprite_rock,0,140,y_place+105)
        draw_sprite(sprite_yellow,0,175,y_place+105)
        draw_sprite(sprite_yellow,0,210,y_place+105)
        draw_sprite(sprite_rock,0,245,y_place+105)
        draw_set_font(font_character)
        draw_text(175,y_place+35,"J")
        draw_set_font(font_text)
    }
    if (global.var_page_num==1)
    {
        draw_text_ext(140,175,"* "+global.special_gigga_port[5],line_spacing,line_length)
        var y_place;
        y_place = 215
        draw_sprite(sprite_rock,0,140,y_place)
        var y_pos;
        y_pos = y_place
        repeat(5)
        {
            draw_sprite(sprite_yellow,0,175,y_pos)
            y_pos += 35
        }
        draw_sprite(sprite_rock,0,210,y_place)
        draw_sprite(sprite_gigga_port,-1,245,y_place)
        var x_pos;
        x_pos = 315
        repeat(4)
        {
            y_pos = y_place
            repeat(3)
            {
                draw_sprite(sprite_rock,0,x_pos,y_pos)
                y_pos += 35
            }
            x_pos += 35
        }
        draw_sprite(sprite_yellow,0,140,y_place+35)
        draw_sprite(sprite_yellow,0,210,y_place+35)
        y_pos = y_place+70
        repeat(3)
        {
            draw_sprite(sprite_rock,0,140,y_pos)
            y_pos += 35
        }
        x_pos = 210
        repeat(3)
        {
            y_pos = y_place+70
            repeat(3)
            {
                draw_sprite(sprite_rock,0,x_pos,y_pos)
                y_pos += 35
            }
            x_pos += 35
        }
        draw_sprite(sprite_gigga_port,-1,315,y_place+105)
        draw_sprite(sprite_rock,0,385,y_place+105)
        draw_sprite(sprite_rock,0,420,y_place+105)
        draw_sprite(sprite_yellow,0,385,y_place+140)
        draw_sprite(sprite_yellow,0,420,y_place+140)
        draw_set_font(font_character)
        draw_text_color(177,y_place+35,"J",0,0,0,0,1)
        draw_set_font(font_text)
        draw_text_ext(140,400,"* "+global.special_gigga_port[6],line_spacing,line_length)
        y_place = 435
        x_pos = 140
        repeat(4)
        {
            draw_sprite(sprite_yellow,0,x_pos,y_place)
            x_pos += 35
        }
        draw_sprite(sprite_yellow,0,140,y_place+35)
        draw_sprite(sprite_gigga_port,-1,175,y_place+35)
        draw_sprite(sprite_yellow,0,245,y_place+35)
        draw_sprite(sprite_yellow,0,140,y_place+70)
        draw_sprite(sprite_yellow,0,245,y_place+70)
        x_pos = 140
        repeat(4)
        {
            draw_sprite(sprite_yellow,0,x_pos,y_place+105)
            x_pos += 35
        }
        draw_set_font(font_character)
        draw_text_color(177,y_place+35,"M",0,0,0,0,1)
        draw_set_font(font_text)
        draw_text_ext(140,600,"* "+global.special_gigga_port[7],line_spacing,line_length)
    }
}