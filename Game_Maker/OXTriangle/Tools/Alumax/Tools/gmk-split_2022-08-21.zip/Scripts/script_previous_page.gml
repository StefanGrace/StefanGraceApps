// script_previous_page
// Stefan Grace
// Created: 2016-10-03
// Modified: 2016-10-04
// This script goes the the previous page when an item has multiple pages

global.var_page_num = 0
instance_change(object_button_next_page,true)