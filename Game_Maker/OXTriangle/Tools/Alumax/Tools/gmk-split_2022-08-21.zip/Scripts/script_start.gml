// script_start
// Stefan Grace
// Created: 2017-06-11
// Modified: 2022-08-21
// This script is executed when the Alumax starts

script_execute(script_english)

if (file_exists(working_directory+"\Settings\Language.txt"))
{
    var file;
    file = file_text_open_read(working_directory+"\Settings\Language.txt")
    global.language = file_text_read_real(file)
    file_text_close(file)
    if (global.language==1) script_execute(script_french)
    if (global.language==2) script_execute(script_spanish)
    if (global.language==3) script_execute(script_german)
}

if (file_exists(working_directory+"\Alumax\Page.txt"))
{
    var file;
    var page_id;
    file = file_text_open_read(working_directory+"\Alumax\Page.txt")
    page_id = file_text_read_real(file)
    file_text_close(file)
    file = file_text_open_write(working_directory+"\Alumax\Page.txt")
    file_text_write_real(file,0)
    if (page_id>0) script_execute(script_go_to_page,page_id)
    file_text_close(file)
}

if (file_exists(working_directory+"\Settings\Dark.txt"))
{
    var file;
    file = file_text_open_read(working_directory + "\Settings\Dark.txt")
    global.dark = file_text_read_real(file)
    if (global.dark) 
    {
        draw_set_color(c_white)
        with (object_button_dark) instance_change(object_button_light,true)
    }
    file_text_close(file)
}

if (file_exists(working_directory+"\Settings\Fullscreen.txt"))
{
    var file;
    file = file_text_open_read(working_directory + "\Settings\Fullscreen.txt")
    window_set_fullscreen(file_text_read_real(file))
    file_text_close(file)
}

show_score = false