// script_go_to_page
// Stefan Grace
// Created: 2016-09-30
// Modified: 2020-02-26
// This script takes you to the page about the character or object you have clicked on

/* Arguments

    Characters
        0 - O
        1 - X
        2 - Triangle
        3 - A
        4 - Square
        5 - K
        6 - B
        7 - E
        8 - S
        9 - H
        10 - R
        11 - M
        12 - F
        13 - G
        14 - C
        15 - Y
        16 - Z
        17 - W
        18 - J
        19 - V
        20 - P
        21 - T
        22 - D
        23 - Q
        24 - N
        25 - Gigga G
        26 - ?
        27 - U
        28 - L
        29 - $
        30 - @
        31 - Pi
        32 - I
        33 - Big W
        34 - Terra G
        35 - Purple ?
        
    Objects
        100 - Boulder
        101 - Red Anger
        102 - Bomb
        103 - Orange Anger
        104 - Barrier
        105 - Double Boxing
        106 - Arrow
        107 - Blue Anger
        108 - Diamond Bomb
        109 - Concrete
        110 - Nuclear Bomb
        111 - Teleport
        112 - Purple Anger
        113 - Concreate Bomb
        114 - Nuclear War Head
        115 - Time Bomb
        116 - Mud
        117 - Switch/Gate
        118 - Gigga Port
*/


if (((argument0 == 29 || argument0 == 34 || argument0 == 35) xor !keyboard_check(vk_control)) 
|| (mouse_x >= x-(sprite_width/2) && mouse_y >= y-(sprite_height/2) && mouse_x < x+(sprite_width/2) && mouse_y < y+(sprite_height/2)))
{
    global.var_page = argument0
    room_goto(room_page)
}