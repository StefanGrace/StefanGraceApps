// script_index
// Stefan Grace
// Created: 2016-09-29
// Modified: 2016-09-29
// This script enters the index menu

game_restart()
