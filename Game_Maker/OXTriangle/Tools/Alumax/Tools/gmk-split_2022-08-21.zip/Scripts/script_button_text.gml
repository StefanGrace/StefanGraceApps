// script_button_text
// Stefan Grace
// Created: 2016-08-27
// Modifed: 2016-10-31
// This script draws the text on buttons and makes the text and buttons change color

/* 
argument0
    0 = Normal Button
    1 = Index Button
    2 = Item Button
    
argument1
    0 = font_index
    1 = font_small 
*/

var y_plus;

if (argument1==0) draw_set_font(font_index)
if (argument1==1) draw_set_font(font_small)
draw_set_halign(fa_center)
draw_set_valign(fa_center)

if(position_meeting(mouse_x,mouse_y,self))
{
    if mouse_button  
    {  
        if (argument0==0) draw_sprite(sprite_button_pressed,0,x,y)
        if (argument0==1) draw_sprite(sprite_button_index_pressed,0,x,y)
        if (argument0==2) draw_sprite(sprite_button_item_pressed,0,x,y)
        if (argument1==0) draw_text_color(x,y,button_name,c_blue,c_blue,c_blue,c_blue,100)
        if (argument1==1) draw_text_ext_color(x,y,button_name,button_spacing,button_length,c_blue,c_blue,c_blue,c_blue,100)
    }
    else
    {
        if (argument0==0) draw_sprite(sprite_button_hot,0,x,y)
        if (argument0==1) draw_sprite(sprite_button_index_hot,0,x,y)
        if (argument0==2) draw_sprite(sprite_button_item_hot,0,x,y)
        if (argument1==0) draw_text_color(x,y,button_name,c_blue,c_blue,c_blue,c_blue,100)
        if (argument1==1) draw_text_ext_color(x,y,button_name,button_spacing,button_length,c_blue,c_blue,c_blue,c_blue,100)
    }
}

else
{
    if (argument0==0) draw_sprite(sprite_button_normal,0,x,y)
    if (argument0==1) draw_sprite(sprite_button_index_normal,0,x,y)
    if (argument0==2) draw_sprite(sprite_button_item_normal,0,x,y)
    if (argument1==0) draw_text_color(x,y,button_name,c_black,c_black,c_black,c_black,100)
    if (argument1==1) draw_text_ext_color(x,y,button_name,button_spacing,button_length,c_black,c_black,c_black,c_black,100)
}

draw_set_valign(0)
draw_set_halign(0)