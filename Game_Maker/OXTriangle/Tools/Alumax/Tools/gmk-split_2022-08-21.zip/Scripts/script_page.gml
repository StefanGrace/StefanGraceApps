// script_page
// Stefan Grace
// Created: 2016-09-30
// Modified: 2019-03-19
// This script does the maths behind drawing out the item pages

// Next Button
if (global.var_page==21 or global.var_page==25 or global.var_page==27 or global.var_page==118) instance_create(455,700,object_button_next_page)

// Dark Mode
if (global.dark)
{
    with (object_button_dark) instance_change(object_button_light,true)
}

// Character Name
array_characters[0] = "O"
array_characters[1] = "X"
array_characters[2] = global.text_triangle
array_characters[3] = "A"
array_characters[4] = global.text_square
array_characters[5] = "K"
array_characters[6] = "B"
array_characters[7] = "E"
array_characters[8] = "S"
array_characters[9] = "H"
array_characters[10] = "R"
array_characters[11] = "M"
array_characters[12] = "F"
array_characters[13] = "G"
array_characters[14] = "C"
array_characters[15] = "Y"
array_characters[16] = "Z"
array_characters[17] = "W"
array_characters[18] = "J"
array_characters[19] = "V"
array_characters[20] = "P"
array_characters[21] = "T"
array_characters[22] = "D"
array_characters[23] = "Q"
array_characters[24] = "N"
array_characters[25] = "Gigga G"
array_characters[26] = "?"
array_characters[27] = "U"
array_characters[28] = "L"
array_characters[29] = "$"
array_characters[30] = "@"
array_characters[31] = "Pi"
array_characters[32] = "I"
array_characters[33] = global.text_big+" W"
array_characters[34] = "Terra G" 
array_characters[35] = global.text_purple+" ?"

// Object Name
array_characters[100] = global.text_boulder
array_characters[101] = global.text_red_anger
array_characters[102] = global.text_bomb
array_characters[103] = global.text_orange_anger
array_characters[104] = global.text_barrier
array_characters[105] = global.text_double_boxing
array_characters[106] = global.text_arrow
array_characters[107] = global.text_blue_anger
array_characters[108] = global.text_diamond_bomb
array_characters[109] = global.text_concrete
array_characters[110] = global.text_nuclear_bomb
array_characters[111] = global.text_teleport
array_characters[112] = global.text_purple_anger
array_characters[113] = global.text_concreate_bomb
array_characters[114] = global.text_nwh
array_characters[115] = global.text_time_bomb
array_characters[116] = global.text_mud
array_characters[117] = global.text_switch_gate
array_characters[118] = "GiggaPort"

// Description
global.description[26] = "?????????????"

// Kills
array_kills[1] = "O,"+global.text_triangle+","+global.text_square+",K,B,E,R,M,G,C,Y,Z,W,J,V,P,T,D,Q,N,?,U,L,$,@,I"
array_kills[2] = "O,A,"+global.text_square+",K,B,E,H,R,M,G,C,Y,Z,W,J,V,P,T,D,Q,N,?,U,L,$,@,I"
array_kills[3] = "X,H,R,M,G,Y,Z,W,J,V,T,D,Q,N,?,U,L,$,I"
array_kills[7] = "O,"+global.text_square+",K,B,S,H,R,M,F,G,C,Y,Z,W,J,V,P,T,D,Q,N,?,U,L,$,@,I"
array_kills[9] = "X,S,F,G,V,U"
array_kills[14] = "O,"+global.text_square+",K,B,R,M,G,Y,Z,W,J,V,P,T,D,Q,N,?,U,L,$,@,I"

// Weakness
array_weakness[1] = "A,H"
array_weakness[2] = "X"
array_weakness[3] = global.text_triangle
array_weakness[7] = "X,"+global.text_triangle
array_weakness[8] = "H,E,F"
array_weakness[9] = global.text_triangle+",E,A"
array_weakness[12] = "H,E"
array_weakness[13] = "R"
array_weakness[31] = "G"

// Toughness
array_toughness[0] = global.text_weak
array_toughness[1] = global.text_high
array_toughness[2] = global.text_very_high
array_toughness[3] = global.text_very_high
array_toughness[4] = global.text_weak
array_toughness[5] = global.text_weak
array_toughness[6] = global.text_weak
array_toughness[7] = global.text_high
array_toughness[8] = global.text_high
array_toughness[9] = global.text_medium
array_toughness[10] = global.text_weak
array_toughness[11] = global.text_weak
array_toughness[12] = global.text_high
array_toughness[13] = global.text_extremely_high+" (x3)"
array_toughness[14] = global.text_medium
array_toughness[15] = global.text_weak
array_toughness[16] = global.text_weak
array_toughness[17] = global.text_weak
array_toughness[18] = global.text_weak 
array_toughness[19] = global.text_weak
array_toughness[20] = global.text_weak
array_toughness[21] = global.text_weak
array_toughness[22] = global.text_weak
array_toughness[23] = global.text_weak
array_toughness[24] = global.text_weak
array_toughness[26] = global.text_weak
array_toughness[27] = global.text_weak
array_toughness[28] = global.text_weak
array_toughness[29] = global.text_weak
array_toughness[30] = global.text_weak
array_toughness[31] = global.text_very_high
array_toughness[32] = global.text_weak
array_toughness[35] = global.text_weak

// Special
array_special[6] = global.special_b[0]
array_special[8] = global.special_s[0]+" (O,X,"+global.text_triangle+",A,"+global.text_square+",K,B,R,M,G,C,Y,Z,J,V,P,T,D,Q,N,?,U,L,$,@,I) "+global.special_s[1]+"# #"+global.special_s[2]
array_special[10] = global.special_r[0]+"# #* "+global.special_r[1]+"# #* "+global.special_r[2]
array_special[12] = global.special_f[0]+" (O,X,"+global.text_triangle+",A,"+global.text_square+",K,B,S,R,M,C,Y,Z,W,J,V,P,T,D,Q,N,?,U,L,$,@,I)#"+global.special_f[1]
array_special[15] = global.special_y[0]
array_special[16] = global.special_z[0]+"# #* "+global.special_m[1]+"# #* "+global.special_z[3]+"# #* "+global.special_z[4]+"# #* "+global.special_z[5]
array_special[17] = global.special_w[0]+"# #* "+global.special_w[1]+"# #* "+global.special_w[2]+"# #* "+global.special_w[3]+"# #* "+global.special_w[4]+"# #* "+global.special_w[5]
array_special[20] = global.special_p[0]+"# #* "+global.special_p[1]+"# #* "+global.special_p[2]
array_special[22] = global.special_d[0]+"# #* "+global.special_d[1]
array_special[24] = global.special_n[0]
array_special[26] = global.special_question_mark[0]+"# #* "+global.special_question_mark[1]+"# #* "+global.special_question_mark[2]
array_special[29] = global.special_dollar_sign[0]+"# #* "+global.special_dollar_sign[1]+"# #* "+global.special_dollar_sign[2]
array_special[30] = global.special_at[0]+"# #* "+global.special_at[1]+"# #* "+global.special_at[2]
array_special[35] = global.special_purple_question_mark[0]



