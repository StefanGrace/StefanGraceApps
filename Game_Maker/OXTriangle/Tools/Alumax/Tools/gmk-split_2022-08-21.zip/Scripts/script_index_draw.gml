// script_index_draw
// Stefan Grace
// Created: 2016-08-27
// Modified: 2019-03-19
// This script draws the text on the Alumax Index


// Dark Mode
if (global.dark)
{
    draw_rectangle_color(333,47,1027,271,0,0,0,0,0)
    draw_rectangle_color(400,287,964,353,0,0,0,0,0)
}


// OXTriangle Logo
draw_sprite(sprite_logo,0,333,47)


// Text
draw_set_halign(fa_center)
draw_set_valign(fa_center)
draw_set_font(font_index)
if (global.var_alumax_index==0) draw_text(680,320,"Alumax - "+global.text_index)
if (global.var_alumax_index==1) draw_text(680,320,"Alumax - "+global.text_characters)
if (global.var_alumax_index==2) draw_text(680,320,"Alumax - "+global.text_objects)
draw_set_valign(0)
draw_set_halign(0)