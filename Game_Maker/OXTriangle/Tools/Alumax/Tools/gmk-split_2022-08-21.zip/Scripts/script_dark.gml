// script_dark
// Stefan Grace
// Created: 2019-03-19
// Modified: 2019-03-19
// This script activates the dark color scheme

draw_set_color(c_white)
global.dark = true
alarm[0] = 1
if (file_exists(working_directory+"\Settings\Dark.txt"))
{
    var file;
    file = file_text_open_write(working_directory + "\Settings\Dark.txt")
    file_text_write_real(file,global.dark)
    file_text_close(file)
}
