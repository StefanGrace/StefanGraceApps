// script_characters
// Stefan Grace
// Created: 2016-10-29
// Modified: 2016-10-31
// This script enters the objects menu

global.var_alumax_index = 2
with(object_button_characters) instance_destroy()
with(object_button_objects) instance_destroy()
instance_create(175,700,object_button_index)
instance_create(280,420,object_button_boulder)
instance_create(350,420,object_button_red_anger)
instance_create(420,420,object_button_bomb)
instance_create(490,420,object_button_orange_anger)
instance_create(560,420,object_button_barrier)
instance_create(630,420,object_button_double_boxing)
instance_create(700,420,object_button_arrow)
instance_create(770,420,object_button_blue_anger)
instance_create(840,420,object_button_diamond_bomb)
instance_create(910,420,object_button_concrete)
instance_create(980,420,object_button_nuclear_bomb)
instance_create(1050,420,object_button_teleport)
instance_create(280,490,object_button_purple_anger)
instance_create(350,490,object_button_concreate_bomb)
instance_create(420,490,object_button_nwh)
instance_create(490,490,object_button_time_bomb)
instance_create(560,490,object_button_mud)
instance_create(630,490,object_button_switch_gate)
instance_create(700,490,object_button_gigga_port)


/* UNUSED LINE OF CODE
instance_create(770,490,object_button_v)
instance_create(840,490,object_button_p)
instance_create(910,490,object_button_t)
instance_create(980,490,object_button_d)
instance_create(1050,490,object_button_q)
instance_create(280,560,object_button_n)
instance_create(350,560,object_button_gigga_g)
instance_create(420,560,object_button_question_mark)
instance_create(490,560,object_button_u)
instance_create(560,560,object_button_l)
instance_create(630,560,object_button_dollar_sign)
instance_create(700,560,object_button_at_sign)
instance_create(770,560,object_button_pi)
instance_create(840,560,object_button_i)
instance_create(910,560,object_button_big_w)
instance_create(980,560,object_button_terra_g)
instance_create(1050,560,object_button_purple_question_mark)
*/