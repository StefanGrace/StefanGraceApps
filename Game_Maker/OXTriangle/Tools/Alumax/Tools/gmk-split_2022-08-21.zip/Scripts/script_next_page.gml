// script_next_page
// Stefan Grace
// Created: 2016-10-03
// Modified: 2016-10-04
// This script goes the the next page when an item has multiple pages

global.var_page_num = 1
instance_change(object_button_previous_page,true)