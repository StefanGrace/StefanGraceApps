/* arguments
    argument0 - light
    argument1 - target value
*/

var increment;

switch (transition) {
    case "cut": increment = 1; break;
    case "slow_fade": 
        switch (speed_mode) {
            case "slow": increment = 1/60; break;
            case "med": increment = 1/30; break;
            case "fast": increment = 1/15; break;
        }
        break;
    case "fast_fade": 
        switch (speed_mode) {
            case "slow": increment = 1/20; break;
            case "med": increment = 1/10; break;
            case "fast": increment = 1/5; break;
        }
        break;
}

if (argument1 == 0) {
    increment = -increment;
}

switch (argument0) {
    case "lights_pink": lights_pink += increment; break;
    case "lights_orange": lights_orange += increment; break;
    case "lights_green": lights_green += increment; break;
    case "lights_cyan": lights_cyan += increment; break;
}

if (lights_pink > 1) {lights_pink = 1;}
if (lights_orange > 1) {lights_orange = 1;}
if (lights_green > 1) {lights_green = 1;}
if (lights_cyan > 1) {lights_cyan = 1;}

if (lights_pink < 0) {lights_pink = 0;}
if (lights_orange < 0) {lights_orange = 0;}
if (lights_green < 0) {lights_green = 0;}
if (lights_cyan < 0) {lights_cyan = 0;}
