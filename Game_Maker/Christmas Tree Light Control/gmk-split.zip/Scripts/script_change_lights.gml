/* arguments
    argument0 - pink
    argument1 - orange
    argument2 - green
    argument3 - cyan
*/

script_change_light("lights_pink", argument0);
script_change_light("lights_orange", argument1);
script_change_light("lights_green", argument2);
script_change_light("lights_cyan", argument3);
