if (!on) {
    lights_pink = 0.0;
    lights_orange = 0.0;
    lights_green = 0.0;
    lights_cyan = 0.0;
} else {
    switch (mode) {
        case "solid":
            lights_pink = 1.0;
            lights_orange = 1.0;
            lights_green = 1.0;
            lights_cyan = 1.0;
            break;
        case "pulse":
            switch (speed_mode) {
                case "slow":
                    if (floor(clock / 60) mod 2 == 1) {
                        script_change_lights(0, 0, 0, 0);
                    } else {
                        script_change_lights(1, 1, 1, 1);
                    }
                    break;
                case "med":
                    if (floor(clock / 30) mod 2 == 1) {
                        script_change_lights(0, 0, 0, 0);
                    } else {
                        script_change_lights(1, 1, 1, 1);
                    }
                    break;
                case "fast":
                    if (floor(clock / 15) mod 2 == 1) {
                        script_change_lights(0, 0, 0, 0);
                    } else {
                        script_change_lights(1, 1, 1, 1);
                    }
                    break;
            }
            break;
        case "cycle":
            switch (speed_mode) {
                case "slow":
                    var light_cycle;
                    light_cycle = floor(clock / 60) mod 4
                    break;
                case "med":
                    var light_cycle;
                    light_cycle = floor(clock / 30) mod 4
                    break;
                case "fast":
                    var light_cycle;
                    light_cycle = floor(clock / 15) mod 4
                    break;
            }
            switch (light_cycle) {
                case 0: script_change_lights(1, 0, 0, 0); break;
                case 1: script_change_lights(0, 1, 0, 0); break;
                case 2: script_change_lights(0, 0, 1, 0); break;
                case 3: script_change_lights(0, 0, 0, 1); break;
            }    
            break;
    }
}

clock += 1;
