if (on) {
    draw_sprite(sprite_switch, 0, 166, 79);
} else {
    draw_sprite(sprite_switch, 0, 106, 79);
}

switch (mode) {
    case "solid": draw_sprite(sprite_switch, 0, 15, 428); break;
    case "pulse": draw_sprite(sprite_switch, 0, 15, 482); break;
    case "cycle": draw_sprite(sprite_switch, 0, 15, 538); break;
}

switch (speed_mode) {
    case "slow": draw_sprite(sprite_switch, 0, 124, 428); break;
    case "med": draw_sprite(sprite_switch, 0, 124, 482); break;
    case "fast": draw_sprite(sprite_switch, 0, 124, 538); break;
}

switch (transition) {
    case "cut": draw_sprite(sprite_switch, 0, 233, 428); break;
    case "fast_fade": draw_sprite(sprite_switch, 0, 233, 482); break;
    case "slow_fade": draw_sprite(sprite_switch, 0, 233, 538); break;
}

draw_sprite_ext(sprite_lights_pink, 0, 0, 0, 1, 1, 0, c_white, lights_pink);
draw_sprite_ext(sprite_lights_orange, 0, 0, 0, 1, 1, 0, c_white, lights_orange);
draw_sprite_ext(sprite_lights_green, 0, 0, 0, 1, 1, 0, c_white, lights_green);
draw_sprite_ext(sprite_lights_cyan, 0, 0, 0, 1, 1, 0, c_white, lights_cyan);
