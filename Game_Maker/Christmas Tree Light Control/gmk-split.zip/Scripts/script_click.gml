// POWER SWITCH
// off
if (mouse_x > 101 && mouse_x < 152 && mouse_y > 73 && mouse_y < 115) {
    on = false;
// on
} else if (mouse_x > 114 && mouse_x < 202 && mouse_y > 73 && mouse_y < 115) {
    on = true;
    clock = 0;

// MODE SWITCH
// solid
} else if (mouse_x > 9 && mouse_x < 50 && mouse_y > 423 && mouse_y < 471) {
    mode = "solid";
// pulse
} else if (mouse_x > 9 && mouse_x < 50 && mouse_y > 470 && mouse_y < 525) {
    mode = "pulse";
    clock = 0;
// cycle
} else if (mouse_x > 9 && mouse_x < 50 && mouse_y > 524 && mouse_y < 574) {
    mode = "cycle";
    clock = 0;

// SPEED SWITCH
// slow
} else if (mouse_x > 118 && mouse_x < 159 && mouse_y > 423 && mouse_y < 471) {
    speed_mode = "slow";
    clock = 0;
// med
} else if (mouse_x > 118 && mouse_x < 159 && mouse_y > 470 && mouse_y < 525) {
    speed_mode = "med";
    clock = 0;
// fast
} else if (mouse_x > 118 && mouse_x < 159 && mouse_y > 524 && mouse_y < 574) {
    speed_mode = "fast";
    clock = 0;

// TRANSITION SWITCH
// cut
} else if (mouse_x > 227 && mouse_x < 269 && mouse_y > 423 && mouse_y < 471) {
    transition = "cut";
    clock = 0;
// fast fade
} else if (mouse_x > 227 && mouse_x < 269 && mouse_y > 470 && mouse_y < 525) {
    transition = "fast_fade";
    clock = 0;
// slow fade
} else if (mouse_x > 227 && mouse_x < 269 && mouse_y > 524 && mouse_y < 574) {
    transition = "slow_fade";
    clock = 0;
}
