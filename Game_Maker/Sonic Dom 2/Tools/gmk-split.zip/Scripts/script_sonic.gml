// script_sonic
// Stefan Grace
// Created: 2018-01-07
// Modified: 2021-02-23



// Walk
if (keyboard_check(vk_right) && !crouch && x + sprite_width < right_bound && !place_meeting(x + 10, y, object_Wall) && !place_meeting(x + 10, y, object_Gate)) {
    if (spin) {
        if (hspeed < 0) {hspeed += 1;}
    } else {
        if (hspeed < sonic_speed) {hspeed += 1;}
        facing = 1;
    }
} else if (keyboard_check(vk_left) && !crouch && x - sprite_width > left_bound && !place_meeting(x - 10, y, object_Wall) && !place_meeting(x - 10, y, object_Gate)) {
    if (spin) {
        if (hspeed > 0) {hspeed -= 1;}
    } else {
        if (hspeed > -sonic_speed) {hspeed -= 1;}
        facing = -1;
    }    
} else if (!spin) {
    if (hspeed >= 1) {
        hspeed -= 1;
    } else if (hspeed <= -1) {
        hspeed += 1;
    } else {
        hspeed = 0;
    }
}
if (spin && floor((time * 30) mod 4) == 0) {
    if (hspeed >= 1) {
        hspeed -= 1;
    } else if (hspeed <= -1) {
        hspeed += 1;
    } else {
        hspeed = 0;
    }
}
if (hspeed == 0) {spin = false;}
if ((x - sprite_width <= left_bound || place_meeting(x - 10, y, object_Wall) || place_meeting(x - 10, y, object_Gate)) && hspeed < 0)
|| ((x + sprite_width >= right_bound || place_meeting(x + 10, y, object_Wall) || place_meeting(x + 10, y, object_Gate)) && hspeed > 0){
    hspeed = 0;
}


// Hit top platform
if ((place_meeting(x, y - 10, object_Top)) && vspeed < 0) {vspeed = 0;}


// Fall
if (!place_meeting(x, y + 1, object_Platform) && !place_meeting(x, y, object_Platform_Flat) && !place_meeting(x, y, object_Flashing_Platform)
&& !place_meeting(x, y, object_Ladder) && !place_meeting(x, y, object_Rising_Platform)) {
    if (vspeed < sonic_speed) {vspeed += 1;}
    if (vspeed > sonic_speed) {vspeed -= 1;}
} else {
    vspeed = 0;
    jump = false;
}


// Jump
if (keyboard_check(ord("A")) || keyboard_check(ord("D")) || keyboard_check(vk_space)) {
    if (place_meeting(x, y + 1, object_Platform) || place_meeting(x, y, object_Platform_Flat) || place_meeting(x, y, object_Flashing_Platform)) {
        vspeed = -20;
        if (!jump) {sound_play(sound_jump);}
        spin = false;
        jump = true;
    }
}


// Spring
if (place_meeting(x, y, object_Spring)) {
    vspeed = -35;
    if (!spring_sound_playing){
        sound_play(sound_spring);
        spring_sound_playing = true;
        spring_sound_time = time;
    }
}
if (place_meeting(x, y, object_Spring_Weak)) {
    vspeed = -25;
    if (!spring_sound_playing){
        sound_play(sound_spring);
        spring_sound_playing = true;
        spring_sound_time = time;
    }
}
if (place_meeting(x, y, object_Spring_Left)) {
    hspeed = -35;
    if (!spring_sound_playing){
        sound_play(sound_spring);
        spring_sound_playing = true;
        spring_sound_time = time;
    }
}
if (place_meeting(x, y, object_Spring_Right)) {
    hspeed = 35;
    if (!spring_sound_playing){
        sound_play(sound_spring);
        spring_sound_playing = true;
        spring_sound_time = time;
    }
}
if (spring_sound_playing) {
    if (time - spring_sound_time > 1) {spring_sound_playing = false;}
}


// Stay on platform
if (place_meeting(x, y, object_Platform) || place_meeting(x, y, object_Rising_Platform)|| place_meeting(x, y, object_Balloon)) {
    y -= floor(sqrt(sqr(hspeed))); 
}
if (place_meeting(x, y, object_Balloon)) {
    vspeed = -5;
}


// Spin/ Crouch
if ((keyboard_check(vk_down) || keyboard_check(ord("S"))) && !place_meeting(x, y, object_Spring_Woosh)) {
    if (!spin and hspeed != 0) {sound_play(sound_spin);}
    spin = hspeed != 0;
    crouch = hspeed == 0;    
} else {
    crouch = false;
}


// Look up
look_up = (keyboard_check(vk_up) || keyboard_check(ord("W"))) && hspeed == 0 && vspeed == 0 && !place_meeting(x, y, object_Ladder) && !place_meeting(x, y, object_Spring_Woosh);


// Ladder
if (place_meeting(x, y, object_Ladder) && (keyboard_check(vk_up) || keyboard_check(ord("W")))) {y -= 10;}


// Time
if (time < 599 || showing_bonuses) {
    time += 1 / 30;
} else {
    script_execute(script_die);
}
if (minutes < 9) {
    time_color = c_yellow;
} else {
    time_color = c_red;
}
if (!showing_bonuses && !game_over && !dead) {
    minutes = floor(time / 60);
    seconds = floor(time mod 60);
    if (seconds < 10) {seconds = "0" + string(seconds);}
}
steps += 1;


// Rings 
if (place_meeting(x, y, object_TV_Ring) && (spin || jump)) {
    with (object_TV_Ring){
        if (place_meeting(x, y, other)) {
            other.rings += 10;
            instance_change(object_TV_Got, false);
        }
    }
    if (rings mod 2 > 0) {
            sound_play(sound_ring_left);
        } else {
            sound_play(sound_ring_right);
        }
    ring_sound_playing = true;
    ring_sound_time = time;
}
if (place_meeting(x, y, object_Ring)) {
    with (object_Ring) {
        if (place_meeting(x, y, other)) {
            other.rings += 1;
            if (lost_ring) {
                instance_destroy();
            } else { 
                instance_change(object_Ring_Got, false);
            }
        }
    }
    if (!ring_sound_playing){
        if (rings mod 2 > 0) {
            sound_play(sound_ring_left);
        } else {
            sound_play(sound_ring_right);
        }
        ring_sound_playing = true;
        ring_sound_time = time;
    }
}
if (ring_sound_playing) {
    if (time - ring_sound_time > 0.5) {ring_sound_playing = false;}
}
if (rings > 0) {
    rings_color = c_yellow;
} else {
    rings_color = c_red;
}


// Shield
if (place_meeting(x, y, object_TV_Shield) && (spin || jump)) {
    with (object_TV_Shield) {
        if (place_meeting(x, y, other)) {instance_change(object_TV_Got, false);}
    }
    shield = true;
    sound_play(sound_shield);
}


// Super Sonic 
if (place_meeting(x, y, object_TV_Super_Sonic) && (spin || jump)) {
    with (object_TV_Super_Sonic) {
        if (place_meeting(x, y, other)) {instance_change(object_TV_Got, false);}
    }
    super_sonic = true;
    super_sonic_time = time;
}
if (time - super_sonic_time > 20) {super_sonic = false;}


// Extra Life
if (place_meeting(x, y, object_TV_Sonic) && (spin || jump)) {
    with (object_TV_Sonic){
        if (place_meeting(x, y, other)) {
            instance_change(object_TV_Got, false);
            with (other) {script_extra_life();}
        }
    }
}
if (rings >= 200 && !got_life_from_200_rings) {
    got_life_from_200_rings = true;
    script_execute(script_extra_life);
} else if (rings >= 100 && !got_life_from_100_rings) {
    got_life_from_100_rings = true;
    script_execute(script_extra_life);
}
if (keyboard_check(ord("E")) && !got_life_from_key) {
    got_life_from_key = true;
    script_execute(script_extra_life);
}
if (!keyboard_check(ord("E"))) {
    got_life_from_key = false;
}
if (rings < 100) {
    got_life_from_100_rings = false;
    got_life_from_200_rings = false;
}
if (just_got_extra_life) {
    if (time - extra_life_time > 4) {just_got_extra_life = false;}
}


// Game Restart
if (keyboard_check(ord("R"))) {game_restart();}


// Fall off the edge
if (y > bottom_bound || y > room_height) {script_execute(script_die);}


// Lamp Post
if (place_meeting(x, y, object_Lamp_Post)) {
    with (object_Lamp_Post){
        if (place_meeting(x, y, other)) {instance_change(object_Lamp_Post_Got, false);}
    }
    x = round(x);
    y = round(y);
    bind_x = x;
    bind_y = y;
    bind_time = time;
    sound_play(sound_lamp_post);
}


// Spikes
if (place_meeting(x, y, object_Spikes)) {
    if (place_meeting(x, y, object_Spikes_Upsidedown)) {
        vspeed = 15;
    } else if (place_meeting(x, y, object_Spikes_Right)) {
        hspeed = 15;
    } else if (place_meeting(x, y, object_Spikes_Left)) {
        hspeed = -15;
    } else {
        vspeed = -15;
    }
    script_execute(script_hit);
}


// Danger
if (place_meeting(x, y, object_Danger)) {
    script_execute(script_hit);
}


// Stop Flashing
if (flashing && time - flash_start > 2) {
    flashing = false;
}


// Mobs 
if (place_meeting(x, y, object_Mob) && !dead) {
    if (spin || jump || super_sonic) {
        with (object_Mob){
            if (place_meeting(x, y, other)) {
                if (mob_id == 1 && yellow) {
                    with (other) {script_execute(script_hit);}
                } else {
                    instance_change(object_Mod_Exploding, false);
                    score += 100;
                    sound_play(sound_mob_kill);
                }
            }
        }
    } else {
        script_execute(script_hit);
    }
}


// End TV
if (place_meeting(x, y, object_End_TV)) {
    with (object_End_TV){
        if (place_meeting(x, y, other)) {instance_change(object_End_TV_Got, false);}
    }
    if (zone == 1 && act == 1) {
        var i;
        for (i = 704; i < 880; i += 32) {instance_create(9776, i, object_Wall);}
    }
    if (time < 30) {
        time_bonus = 50000;
    } else if (time < 45) {
        time_bonus = 10000;
    } else if (time < 60) {
        time_bonus = 5000;
    } else if (time < 90) {
        time_bonus = 4000;
    } else if (time < 120) {
        time_bonus = 3000;
    } else if (time < 180) {
        time_bonus = 2000;
    } else if (time < 240) {
        time_bonus = 1000;
    } else if (time < 300) {
        time_bonus = 500;
    } else {
        time_bonus = 0;
    } 
    ring_bonus = rings * 100;
    showing_bonuses = true;
    bonuses_time = time;
}
if (showing_bonuses && time - bonuses_time > 6) {
    showing_bonuses = false;
    super_sonic = false;
    shield = false;
    time = 0;
    rings = 0;
    bind_time = time;
    showing_title = true;
    title_time = time;
    room_goto_next();
    x = round(x);
    y = round(y);
    if (zone == 1) {
        if (act == 1) {
            x -= 9808;
        } else {
            x -= 9088;
        }
    } else if (zone == 2) {
        if (act == 1) {
            x -= 10560;
            bg = 0;
        } else {
            x -= 9648;
        } 
    } else if (zone == 3) {
        x -= 4992;
    } 
    if (act == 2) {
        zone += 1;
        act = 1;
    } else {
        act += 1;
    }
    alarm[0] = 1;
    bind_x = 640;
    bind_y = y;
    left_bound = 0;
} else if (showing_bonuses && time - bonuses_time > 4) {
    score += time_bonus + ring_bonus;
    time_bonus = 0;
    ring_bonus = 0;
}
if (showing_title && time - title_time > 3) {showing_title = false;}
if (showing_bonuses && zone == 2 && act == 2) {
    if (bg < 1) {    
        bg += 1 / 120;
        background_color = merge_color($DFAEE3, make_color_rgb(140, 74, 176), bg);
    }
}


// Music
if (game_over) {
    if (!sound_isplaying(sound_game_over)) {sound_play(sound_game_over);}
} else if (showing_bonuses) {
    if (time - bonuses_time < 4) {
        if (!sound_isplaying(sound_level_complete)) {sound_play(sound_level_complete);}
    } else if (time - bonuses_time < 5){
        if (!sound_isplaying(sound_score_add)) {sound_play(sound_score_add);}
    }
} else if (just_got_extra_life) {
    if (!sound_isplaying(sound_extra_life)) {sound_play(sound_extra_life);}
} else if (boss) {
    if (!sound_isplaying(sound_boss)) {sound_play(sound_boss);}
} else if (super_sonic) {
    if (!sound_isplaying(sound_super_sonic)) {sound_play(sound_super_sonic);}
} else if (zone == 1) {
    if (!sound_isplaying(sound_extra_terrestrial)) {sound_play(sound_extra_terrestrial);} 
} else if (zone == 2) {
    if (!sound_isplaying(sound_martian)) {sound_play(sound_martian);} 
} else if (zone == 3) {
    if (!sound_isplaying(sound_pinball)) {sound_play(sound_pinball);} 
}


// Boss
if (x > room_width - 1280 && !boss_done_extra_terrestrial && zone == 1 && act = 2) {
    boss = true;
    left_bound = room_width - 1280;
    right_bound = 10400;
    top_bound = object_Dr_Robonic.y - 360;
    bottom_bound = object_Dr_Robonic.y + 360;
} else if (x > 8624 && x < 9648 && y < 2672 && !boss_done_martian && zone == 2 && act == 2) {
    boss = true;
    left_bound = 8368;
    right_bound = 9648;
    top_bound = 0;
    bottom_bound = room_height;
} else if (x > 6016 && !boss_done_pinball && zone == 3 && act == 2) {
    boss = true;
    left_bound = 6016;
    right_bound = 6912;
    top_bound = 0;
    bottom_bound = room_height;
}

if (boss) {
    if (place_meeting(x, y, object_Dr_Robonic) && !boss_hitting && !dead && !game_over) {
        boss_hit_time = time;
        boss_hit += 1;
        boss_hitting = true;
        if (zone == 1) {vspeed *= -1;}
        sound_play(sound_boss_hit);
    }
    if (zone == 3) {
        if (time - boss_hit_time > 1) {boss_hitting = false;}
    } else {
        if (time - boss_hit_time > 0.7) {boss_hitting = false;}
    }
} else {
    boss_hitting = false;
}

if (y > 1440 && boss_done_extra_terrestrial && zone == 1 && act == 2) {
    if (bg < 1) {    
        bg += 1 / 60;
        background_color = merge_color($000000, $DFAEE3, bg);
    }
}


// Pause
if (keyboard_check(vk_enter)) {
    sound_stop_all();
    message_alpha(0);
    show_message("");
}


// Kill
if (keyboard_check(ord("K")) && !been_killed) {
    been_killed = true;
    script_execute(script_die);
}
if (!keyboard_check(ord("K"))) {
    been_killed = false;
}


// Star
if ((place_meeting(x, y, object_Star) || place_meeting(x, y, object_Bouncer)) && !dead && !game_over) {
    with (object_Star) {
        if (place_meeting(x, y, other)) {instance_change(object_Star_Hit, true);}
    }
    with (object_Bouncer_Green) {
        if (place_meeting(x, y, other)) {instance_change(object_Bouncer_Lime, true);}
    }    
    with (object_Bouncer_Yellow) {
        if (place_meeting(x, y, other)) {instance_change(object_Bouncer_Orange, true);}
    }  
    with (object_Bouncer_Red) {
        if (place_meeting(x, y, other)) {instance_change(object_Bouncer_Gone, true);}
    }      
    hspeed *= -1;
    vspeed *= -1;
    score += 10;
    sound_play(sound_star);
} 


// Tornado
if (place_meeting(x, y, object_Tornado) && !dead && !game_over) {
    y -= 60;
}


// Destructible Block
if (place_meeting(x, y, object_Destructible_Block)) {
    if (spin) {
        sound_play(sound_boss_hit);
        with (object_Destructible_Block) {
            if (place_meeting(x, y, other)) {instance_change(object_Destructible_Block_Destroyed, false);}
        }
        facing = 1;
        if (zone == 2 && act == 1) {
            path_start(path_tunnel_martian_act_1, 20, 0, true);
        } else if (zone == 2 && act == 2) {
            path_start(path_tunnel_martian_act_2, 20, 0, true);
        }
    }
}


// Game Over
if (game_over) {
    game_over_time += 1 / 30;
    hspeed = 0;
    vspeed = 0;
}
if (game_over_time > 12) {game_restart();}


// Dead
if (dead) {
    dead_time += 1 / 30;
    hspeed = 0;
    vspeed = 0;
    if (dead_sonic_y < -300) {
        dead_sonic_speed += 5;
    }
    dead_sonic_y += dead_sonic_speed;
}
if (dead_time > 2) {script_dead();}


// Spring Woosh
if (place_meeting(x, y, object_Spring_Woosh)) {
    hspeed = 0;
    vspeed = 0;
    with (object_Spring_Woosh) {
        if (place_meeting(x, y, other)) {other.x = x + 24; other.y = y - 34;}
    }
    if (keyboard_check(vk_down) || keyboard_check(ord("S")) || keyboard_check(ord("A")) || keyboard_check(ord("D")) || keyboard_check(vk_space)) {
        with (object_Spring_Woosh) {
            if (place_meeting(x, y, other)) {
                if (other.woosh < 64) {
                    other.y += 1;
                    other.woosh += 1;
                }
            }
        }
    } else if (woosh > 0) {
        if (place_meeting(x, y, object_Tunnle_Pinball_Act1_T1)) {
            if (woosh > 16) {
                path_start(path_tunnle_pinball_act_1_t1, woosh, 0, true);
            } else {
                y -= 90;
            }
        } else if (place_meeting(x, y, object_Tunnle_Pinball_Act1_T3)) {
            if (woosh > 16) {
                path_start(path_tunnle_pinball_act_1_t3, woosh, 0, true);
            } else {
                y -= 90;
            }
        } else if (place_meeting(x, y, object_Tunnle_Pinball_Act2_T1)) {
            if (keyboard_check(vk_right)) {
                if (woosh > 16) {
                    path_start(path_tunnle_pinball_act_2_t1_p2, woosh, 0, true);
                } else {
                    y -= 90;
                }
            } else {
                if (woosh > 16) {
                    path_start(path_tunnle_pinball_act_2_t1_p3, woosh, 0, true);
                } else {
                    y -= 90;
                }
            }
        } else if (place_meeting(x, y, object_Tunnle_Pinball_Act2_T2)) {
            if (woosh > 24) {
                path_start(path_tunnle_pinball_act_2_t2_p2, woosh, 0, true);
            } else {
                y -= 90;
            }
        } else if (place_meeting(x, y, object_Tunnle_Pinball_Act2_T4)) {
            if (woosh > 16) {
                path_start(path_tunnle_pinball_act_2_t4, woosh, 0, true);
            } else {
                y -= 90;
            }
        } else if (act == 1 && y > 2016) {
            if (woosh < 40) {
                y -= 90;
                vspeed = -woosh;
            } else {
                path_start(path_tunnle_pinball_act_1_t2, woosh, 0, true);
            }
        } else {
            y -= 90;
            vspeed = -woosh;
        }
        woosh = 0;
        sound_play(sound_woosh);
    }    
}


// Tunnles
if (zone == 3 && act == 2) {
    if (path_index == -1) {
        if (x > 1280 && x < 1408 && y > 1888 && y < 1904) {
            path_start(path_tunnle_pinball_act_2_t1_p1, sonic_speed, 0, true);
        } else if (x > 2048 && x < 2176 && y > 2096 && y < 2160) {
            path_start(path_tunnle_pinball_act_2_t1_p4, sonic_speed, 0, true);
        } else if (x > 2272 && x < 2304 && y > 2144 && y < 2272) {
            path_start(path_tunnle_pinball_act_2_t1_p5, sonic_speed, 0, true);
        } else if (x > 1648 && x < 1664 && y > 2656 && y < 2748) {
            path_start(path_tunnle_pinball_act_2_t1_p6, sonic_speed, 0, true);
        } else if (x > 3088 && x < 3104 && y > 3024 && y < 3184) {
            path_start(path_tunnle_pinball_act_2_t2_p1, sonic_speed, 0, true);
        } else if (x > 3456 && x < 3584 && y > 2528 && y < 2544) {
            path_start(path_tunnle_pinball_act_2_t3_p1, sonic_speed, 0, true);
        } else if (x > 3968 && x < 4096 && y > 2528 && y < 2672) {
            path_start(path_tunnle_pinball_act_2_t3_p2, sonic_speed, 0, true);
        }
    }
}


// Credits
if (zone == 3 && act == 2 && x > 6576 && y > 2480) {
    depth = -80;
    fade_to_credits = (576 - (7152 - x)) / 576;
    if (fade_to_credits >= 1 || fade_to_credits < 0) {
        with (object_UI) {instance_destroy();}
        with (object_View) {instance_destroy();}
        room_goto(room_credits);
        instance_destroy();
    }
}


// Spiral
if (place_meeting(x, y, object_Spiral_Start)) {
    if (hspeed > 0 && path_index == -1) {
        with (object_Spiral) {
            if (place_meeting(x, y, other)) {
                other.x = x + 128;
                other.y = y + 480;
            }
        }
        path_start(path_spiral, 20, 0, false);
    }
} else if (place_meeting(x, y, object_Spiral_End)) {
    if (hspeed < 0 && path_index == -1) {
        with (object_Spiral) {
            if (place_meeting(x, y, other)) {
                other.x = x + 416;
                other.y = y + 480;
            }
        }
        path_start(path_spiral_reverse, 20, 0, false);
    }
}