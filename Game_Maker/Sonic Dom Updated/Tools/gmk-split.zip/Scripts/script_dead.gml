// script_dead
// Stefan Grace
// Created: 2021-03-10
// Modifed: 2024-06-20


if (lives > 0) { 
    dead = false;
    dead_time = 0;
    dead_sonic_speed = -20;
    dead_sonic_y = 0;
    depth = -20;
    x = bind_x;
    y = bind_y;
    hspeed = 0;
    vspeed = 0;
    rings = 0;
    shield = false;
    super_sonic = false;
    time = bind_time;
    drowning_timer = 0;
    just_got_extra_life = false;
    boss_hit_time = 0;
    flashing = false;
    if (lava_rising || lava_risen) {
        lava_rising = false;
        lava_risen = false;
        lava_level = 0;
        with (object_Lava) {
            if (x > 19136 && x < 20272 && y < 3184) {instance_destroy();}
        }   
        with (object_Lava_Stream) {instance_destroy();}
        with (object_Lava_Fall) {instance_destroy();}
        with (object_Platform_Rising_Lava) {instance_destroy();}
    }
    if ((water_rising || water_risen) && bind_x < 20128) {
        water_rising = false;
        water_risen = false;
        water_level = 0;
        with (object_Water) {
            if (x >= 18080 && x < 21824 && y < 4032) {instance_destroy();}
        }
    }   
    
    
    with (object_TV_Got) {
        if (tv_type == 1) {
            instance_change(object_TV_Ring, false);
        } else if (tv_type == 2) {
            instance_change(object_TV_Shield, false);
        } else if (tv_type == 3) {
            instance_change(object_TV_Super_Sonic, false);
        } else if (tv_type == 4) {
            instance_change(object_TV_Sonic, false);
        }
    }
    with (object_Ring) {instance_change(object_Ring_Got, false);}
    with (object_Ring_Got) {instance_change(object_Ring, false);}
    with (object_Mob_Dead) {
        switch (mob_id){
            case 5: instance_change(object_Rat, false); break;
            case 6: instance_change(object_Rat_Right, false); break;
            default: instance_change(object_Mob, false); break;
        }    
    }
    with (object_Destructible_Block_Destroyed) {instance_change(object_Destructible_Block, true);}
    with (object_Falling_Platform_Fallen) {instance_change(object_Falling_Platform, true);}
    with (object_Gate_Open) {instance_change(object_Gate, false);}
    with (object_Gate_Open_Horizontal) {instance_change(object_Gate_Horizontal, false);}
    with (object_Rising_Platform_Volcanic) {y = ystart;}
    with (object_Lava_Boat_Left) {x = xstart; y = ystart;}
    object_Falling_Platform.alarm[0] = -1;
    if (x < 20176) {fire_has_happend = false;}
    with (object_Fire) {instance_destroy();}
    if (zone == 1) {
        sound_play(sound_mystic_forest);
    } else if (zone == 2) {
        sound_play(sound_arctic);
    } else if (zone == 3) {
        sound_play(sound_volcanic);
    } else if (zone == 4) {
        sound_play(sound_dungeon);
    } else if (zone == 5) {
        sound_play(sound_seabed);
    } else if (zone == 6) {
        sound_play(sound_rainbow);
        object_Moving_Cloud.y = 736;
    } else if (zone == 7) {
        sound_play(sound_future);
    }
    with (object_Boulder) {
        x = xstart; 
        y = ystart;
    }
    with (object_Lava_Boat) {
        x = xstart; 
        y = ystart;
        moving = false;
    }
    with (object_Movable_Block) {
        x = 11235; 
        y = ystart;
    }
    with (object_Movable_Block_2) {
        x = 20258;
        y = ystart;
    }
    with (object_Floating_Block) {
        rising = false;
        falling = false;
        water_level = ystart + sprite_height;
        y = ystart;
    }
    if (zone == 4 && act == 1) {
        with (object_Water) {instance_destroy();}
    }
    
    with (object_Weighted_Platform) {
        x = xstart;
        x = xstart;
        angle = start_angle;
    }
    with (object_Weighted_Block) {
        x = xstart;
        x = xstart;
        angle = start_angle;
    }
    
    showing_title = true;
    title_time = time;
    boss = false;
    boss_hit = 0;
    if (zone == 1 && act == 3) {
        left_bound = 13616;
        bottom_bound = room_height;
        top_bound = 0;
    } else if (zone == 2 && act == 3) {
        left_bound = 17584;
        bottom_bound = room_height;
        top_bound = 0;
    } else if (zone == 3 && act == 3) {
        left_bound = 13776;
        bottom_bound = room_height;
        top_bound = 0;
    } else if (zone == 4 && act == 3) {
        left_bound = 12848;
        bottom_bound = room_height;
        top_bound = 0;
    } else if (zone == 5 && act == 3) {
        left_bound = 15104;
        bottom_bound = room_height;
        top_bound = 0;
    }else if (zone == 6 && act == 3) {
        left_bound = 20560;
        bottom_bound = room_height;
        top_bound = 0;
    }

} else {
    game_over = true;
}