// script_draw_ui
// Stefan Grace
// Created: 2021-03-10
// Modifed: 2021-03-10

/* Draws the UI at a shallower depth than the sonic by using a separate object,
so that foreground objects that appear in front of Sonic don't appear in front of UI */


var rings time minutes seconds time_color rings_color time_bonus ring_bonus zones zone act showing_bonuses showing_title;
rings = object_Sonic.rings;
time = object_Sonic.time;
minutes = object_Sonic.minutes;
seconds = object_Sonic.seconds;
time_color = object_Sonic.time_color;
rings_color = object_Sonic.rings_color;
time_bonus = object_Sonic.time_bonus;
ring_bonus = object_Sonic.ring_bonus;
zone = object_Sonic.zone;
act = object_Sonic.act;
showing_bonuses = object_Sonic.showing_bonuses;
showing_title = object_Sonic.showing_title;


// Display
draw_set_font(font_display);
draw_set_halign(fa_left);
draw_text_color(view_xview[0] + 50,view_yview[0] + 10, "Score: ", c_yellow, c_yellow, c_black, c_black, 1);
draw_text_color(view_xview[0] + 50,view_yview[0] + 40, "Time: ", time_color, time_color, c_black, c_black, 1);
draw_text_color(view_xview[0] + 50,view_yview[0] + 70, "Rings: ", rings_color, rings_color, c_black, c_black, 1);
draw_set_halign(fa_right);
draw_text_color(view_xview[0] + 240,view_yview[0] + 10, score, c_white, c_white, c_black, c_black, 1);
draw_text_color(view_xview[0] + 200,view_yview[0] + 40, string(minutes) + ":" + string(seconds), c_white, c_white, c_black, c_black, 1);
draw_text_color(view_xview[0] + 200,view_yview[0] + 70, rings, c_white, c_white, c_black, c_black, 1);
draw_sprite(sprite_lives,0,view_xview[0] + 50,view_yview[0] + 680);
draw_set_font(font_lives);
draw_set_halign(fa_left);
draw_text_color(view_xview[0] + 85,view_yview[0] + 680, "Sonic", c_yellow, c_yellow, c_black, c_black, 1);
draw_text_color(view_xview[0] + 85,view_yview[0] + 698, "x", c_white, c_white, c_black, c_black, 1);
draw_set_halign(fa_right);
draw_text_color(view_xview[0] + 130,view_yview[0] + 698, lives, c_white, c_white, c_black, c_black, 1);

// Bonuses
if (showing_bonuses) {
    draw_set_halign(fa_left);
    draw_set_font(font_title);
    draw_text_color(view_xview[0] + 300, view_yview[0] + 100, "Sonic Has Passed Act " + string(act), c_white, c_white, c_black, c_black, 1);
    draw_set_font(font_display);
    draw_text_color(view_xview[0] + 300,view_yview[0] + 250, "Score: ", c_yellow, c_yellow, c_black, c_black, 1);
    draw_text_color(view_xview[0] + 300,view_yview[0] + 300, "Time Bonus: ", c_yellow, c_yellow, c_black, c_black, 1);
    draw_text_color(view_xview[0] + 300,view_yview[0] + 350, "Ring Bonus: ", c_yellow, c_yellow, c_black, c_black, 1);
    draw_set_halign(fa_right);
    draw_text_color(view_xview[0] + 550,view_yview[0] + 250, score, c_white, c_white, c_black, c_black, 1);
    draw_text_color(view_xview[0] + 550,view_yview[0] + 300, time_bonus, c_white, c_white, c_black, c_black, 1);
    draw_text_color(view_xview[0] + 550,view_yview[0] + 350, ring_bonus, c_white, c_white, c_black, c_black, 1);
}

// Title
if (showing_title) {
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_font(font_title);
    draw_text_color(view_xview[0] + 640, view_yview[0] + 360, string(object_Sonic.zones[zone]) + "#Zone Act " + string(act), c_white, c_white, c_black, c_black, 1);
    draw_set_valign(0);
}