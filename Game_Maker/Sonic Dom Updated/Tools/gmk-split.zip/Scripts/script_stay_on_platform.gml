// script_stay_on_platform
// Stefan Grace
// Created: 2021-01-19
// Modified: 2021-03-18
// Makes Sonic stay on moving platforms


var x_move y_move;
x_move = x - last_x;
y_move = y - last_y;

if (place_meeting(x, y - 8, object_Sonic)) {
    if (!object_Sonic.jump) {
        object_Sonic.x += x_move;
        object_Sonic.y += y_move;
    }
}

last_x = x;
last_y = y;