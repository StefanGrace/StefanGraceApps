// script_die
// Stefan Grace
// Created: 2018-01-07
// Modifed: 2021-03-10

if (lives > 0 && !dead) {lives -= 1;}

if (!sound_isplaying(sound_die) && !dead && drowning_timer < 30) {sound_play(sound_die);}

depth = -80;

dead = true;

spin = 0;
jump = 0;