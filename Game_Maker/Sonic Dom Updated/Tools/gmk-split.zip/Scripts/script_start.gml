// script_start
// Stefan Grace
// Created: 2018-01-09
// Modifed: 2024-07-02


zones[1] = "Mystic Forest";
zones[2] = "Artic";
zones[3] = "Volcanic ";
zones[4] = "Dungeon";
zones[5] = "Seabed";
zones[6] = "Rainbow";
zones[7] = "Future";

zone = global.zone_select + 1;
act = global.act_select + 1;
right_bound = 8440;
bottom_bound = room_height;
alarm[2] = 1;
if (zone == 1) {
    if (act == 2) {
        room_goto(room_mystic_forest_act2);
        right_bound = 14940;
        left_bound = 7120;
        x = 7760;
        y = 2992;
    } else if (act == 3) {
        room_goto(room_mystic_forest_act3);
        left_bound = 13616;
        right_bound = 23792;
        x = 14256;
        y = 2960;
    }
} else if (zone == 2) {
    if (act == 1) {
        room_goto(room_arctic_act1);
        right_bound = 11216;
        left_bound = 22528 - 21600;
        x = 23168 - 21600;
        y = 3280;
    } else if (act == 2) {
        room_goto(room_arctic_act2);
        right_bound = 18864;
        left_bound = 31536 - 21600;
        x = 32176 - 21600;
        y = 2992;
    } else if (act == 3) {
        room_goto(room_arctic_act3);
        right_bound = 25968;
        left_bound = 17584;
        x = 18224;
        y = 2672;
    }
} else if (zone == 3) {
    if (act == 1) {
        room_goto(room_volcanic_act1);
        right_bound = 9888;
        left_bound = 736;
        x = 1376;
        y = 3600;
    } else if (act == 2) {
        room_goto(room_volcanic_act2);
        right_bound = 15056;
        left_bound = 8608;
        x = 9248;
        y = 3200;
    } else if (act == 3) {
        room_goto(room_volcanic_act3);
        right_bound = 23680;
        left_bound = 13776;
        x = 14416;
        y = 2416;
    }
} else if (zone == 4) {
    if (act == 1) {
        room_goto(room_dungeon_act1);
        right_bound = room_width;
        left_bound = 0;
        x = 1024;
        y = 1168;
    } else if (act == 2) {
        room_goto(room_dungeon_act2);
        right_bound = 14128;
        left_bound = 7376;
        x = 8016;
        y = 2720;
    } else if (act == 3) {
        room_goto(room_dungeon_act3);
        right_bound = 22144;
        left_bound = 12848;
        x = 13488;
        y = 3024;
    }
} else if (zone == 5) {
    if (act == 1) {
        room_goto(room_seabed_act1);
        right_bound = 9696;
        left_bound = 0;
        x = 1792;
        y = 3376;
    } else if (act == 2) {
        room_goto(room_seabed_act2);
        right_bound = 16384;
        left_bound = 8416;
        x = 9056;
        y = 3360;
    } else if (act == 3) {
        room_goto(room_seabed_act3);
        right_bound = 999999;
        left_bound = 15104;
        x = 15744;
        y = 2976;
    }
} else if (zone == 6) {
    if (act == 1) {
        room_goto(room_rainbow_act1);
        right_bound = 11168;
        left_bound = 0;
        x = 1152;
        y = 1728;
    } else if (act == 2) {
        room_goto(room_rainbow_act2);
        right_bound = 21840;
        left_bound = 9888;
        x = 10528;
        y = 512;
    } else if (act == 3) {
        room_goto(room_rainbow_act3);
        right_bound = 32592;
        left_bound = 20560;
        x = 21200;
        y = 1168;
    }
} else if (zone == 7) {
    if (act == 1) {
        room_goto(room_future_act1);
        right_bound = 9472;
        left_bound = 0;
        x = 640;
        y = 1552;
    } else if (act == 2) {
        room_goto(room_future_act2);
        right_bound = 18144;
        left_bound = 8192;
        x = 8832;
        y = 1040;
    } else if (act == 3) {
        room_goto(room_future_act3);
        right_bound = 999999;
        left_bound = 16864;
        x = 17504;
        y = 5664;
    }
}
instance_create(x, y, object_View);
instance_create(0, 0, object_UI);
facing = 1;
lives = 3;
bind_x = x;
bind_y = y;
bind_time = time;
showing_title = true;
title_time = time;
dead_sonic_speed = -20;
