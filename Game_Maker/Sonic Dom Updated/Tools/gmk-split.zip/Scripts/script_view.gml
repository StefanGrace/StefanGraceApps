// script_view
// Stefan Grace
// Created: 2018-01-07
// Modifed: 2024-01-30


if (object_Sonic.showing_bonuses) {
    with (object_End_TV_Got) {
        if (abs(x - object_Sonic.x) < 1280) {
            other.x = x + 48;
        }
    }
} else if (object_Sonic.boss) {
    if (object_Sonic.zone == 1) {
        x = 21360;
        y = 3088;
    } else if (object_Sonic.zone == 2) {
        x = 24432;
        y = 2992;
    } else if (object_Sonic.zone == 3) {
        x = 21744;
        y = 840;
    } else if (object_Sonic.zone == 4) {
        x = 20256;
        y = object_Sonic.y;
    } else if (object_Sonic.zone == 5) {
        x = 22624;
        y = 2976;
    } else if (object_Sonic.zone == 6) {
        x = 29200;
        y = 784;
    } else if (object_Sonic.zone == 7) {
        x = 24288;
        y = 1304;
    }
} else {
    x = object_Sonic.x;
    if (object_Sonic.crouch){
        if (y < object_Sonic.y + 300) {y += 5;}
    } else if (object_Sonic.look_up){
        if (y > object_Sonic.y - 300) {y -= 5;}
    } else {
        y = object_Sonic.y;
    }
}
